runhugs -h16M -c1000 -98 -P/usr/mfn/work/york-lava/modules/: Main.hs $@
