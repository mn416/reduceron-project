Top-level .vhd and .ucf files that basically connect the reduceron to
the LEDs and switches on the XUPV5 board (also known as ML509).
