#!/bin/sh

rm -f *.ycr *.hbc *.hi
