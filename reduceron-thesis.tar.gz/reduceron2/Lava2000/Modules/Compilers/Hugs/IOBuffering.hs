module IOBuffering where

noBuffering :: IO ()
noBuffering = return () -- is default
