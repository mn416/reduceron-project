module Main where

import Lava
import Patterns
import Arithmetic
import SequentialCircuits

-- this is a dummy module that is used to compile all modules

main :: IO ()
main = putStrLn "Lava Main"
