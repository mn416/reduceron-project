#!/bin/sh

gcc -O3 interp.c -o interp
