#!/bin/sh

rm -f interp a.out
