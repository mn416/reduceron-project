#!/bin/sh

rm -f *.hi *.o *.vhd *.vhd-1 *.vhd-2 *.vhd-3 *.red reduceron

cd Compiler
rm -f *.hi *.o

cd ../CircLib
rm -f *.hi *.o

cd ../MemTest
rm -f *.hi *.o

cd ../Red1
rm -f *.hi *.o

cd ../Red2
rm -f *.hi *.o

cd ../Red3
rm -f *.hi *.o

cd ../Red4
rm -f *.hi *.o

cd ../Red5
rm -f *.hi *.o

cd ../Red6
rm -f *.hi *.o

cd ../Red7
rm -f *.hi *.o

cd ../Red8
rm -f *.hi *.o

cd ../Red9
rm -f *.hi *.o

cd ../Red10
rm -f *.hi *.o

cd ../Red11
rm -f *.hi *.o

cd ../Red12
rm -f *.hi *.o

cd ../Red13
rm -f *.hi *.o

cd ../Red14
rm -f *.hi *.o

cd ../Red15
rm -f *.hi *.o

cd ../Red16
rm -f *.hi *.o

cd ../../Lava2000/Modules
rm -f *.hi *.o

cd Compilers/Ghc
rm -f *.hi *.o
