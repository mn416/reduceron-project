rm -f *.red
