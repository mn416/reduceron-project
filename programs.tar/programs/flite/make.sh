ls *.hs | xargs -i compile.sh {}
