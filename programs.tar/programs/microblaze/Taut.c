#include <stdio.h>
#include <stdlib.h>
typedef unsigned int Atom;
#define isPTR(a)   (((a)&3) == 0)
#define isCTR(a)   (((a)&3) == 1)
#define isINT(a)   (((a)&3) == 2)
#define isFUN(a)   (((a)&3) == 3)
#define getPTR(a)  ((Atom*) (a))
#define getCTR(a)  ((a) >> 2)
#define getINT(a)  ((int) (((int) (a)) >> 2))
#define getFUN(a)  ((void*) (((unsigned int) (a)) & (~3)))
#define makePTR(x) ((Atom) (x))
#define makeCTR(x) ((Atom) (((x) << 2) | 1))
#define makeINT(x) ((Atom) ((((unsigned int) (x)) << 2) | 2))
#define makeFUN(x) ((Atom) (((unsigned int) (x)) | 3))
#define HEAP_SIZE 22000
#define STACK_SIZE 3000
typedef struct {
  Atom* current;
  void* returnAddress;
} Frame;
#define L_POP(n) L_sp-=n; L_top = L_sp[-1];
#define L_PUSH(a) L_top = a; L_sp[0] = L_top; L_sp++;
#define R_POP \
  R_sp++;\
  R_top_returnAddress = R_sp[1].returnAddress;\
  R_top_current = R_sp[1].current;
#define R_PUSH(ra, cur) \
  R_top_returnAddress = R_sp[0].returnAddress = ra; \
  R_top_current = R_sp[0].current = cur; \
  R_sp--;
#define makeHDR(x)        ((x) << 1)
#define VISITED           1
#define size(x)           ((x) >> 1)
#define C_False 0
#define C_True 1
#define C_Cons 0
#define C_Nil 1
#define C_Pair 0
#define C_And 0
#define C_Const 1
#define C_Implies 2
#define C_Not 3
#define C_Var 4


int main() {
register Atom* L_sp;
Atom* L_base;
register Atom L_top;
register Frame* R_sp;
Frame* R_base;
register void* R_top_returnAddress;
register Atom* R_top_current;
register Atom* hp;
register Atom* heapEnd;
register Atom atom;
register Atom* app;
register int res;
Atom* fromSpace;
Atom* toSpace;
Atom* fromSpaceEnd;
Atom* toSpaceEnd;
Atom* scan;
Atom* free;
Atom* p;
Atom* from;
Frame* frame;
void* gc_copy_ret;
void* gc_ret;
void* eval_ret_addr;
int i;
int j;
int n;
int m;
L_base = L_sp = malloc(sizeof(Atom) * STACK_SIZE);
R_base = R_sp = (Frame*) &L_sp[STACK_SIZE-1];
fromSpace = hp = malloc(sizeof(Atom) * HEAP_SIZE);
heapEnd = fromSpaceEnd = &fromSpace[HEAP_SIZE-1000];
toSpace = malloc(sizeof(Atom) * HEAP_SIZE);
toSpaceEnd = &toSpace[HEAP_SIZE-1000];
print("S");
atom = makePTR(hp);
*hp++ = makeHDR(1); *hp++ =  makeFUN(&&F_main);
L_PUSH(atom);
eval_ret_addr = &&LABEL_253;
goto EVAL;
LABEL_253:
putnum(getINT(L_top));
return 0;
EVAL:
if (isPTR(atom)) {
  app = getPTR(atom);
  EVAL_APP:
  if (isFUN(app[1])) {
    L_PUSH(makePTR(app));
    R_PUSH(eval_ret_addr, app);
    goto *getFUN(app[1]);
    EVAL_RET:
    if (R_top_current) {
      R_top_current[0] = makeHDR(1);
      R_top_current[1] = L_top;
    }
    eval_ret_addr = R_top_returnAddress;
    R_POP;
    goto *eval_ret_addr;
  }
  else if (isCTR(app[1])) {
    L_PUSH(makePTR(app)); res = getCTR(app[1]);
    goto *eval_ret_addr;
  }
  else if (isPTR(app[1])) {
    app = getPTR(app[1]);
    goto EVAL_APP;
  }
  else {
    L_PUSH(app[1]); res = getINT(app[1]);
    goto *eval_ret_addr;
  }
} else {
  L_PUSH(atom);
  res = getINT(atom);
  goto *eval_ret_addr;
}
TAIL_EVAL:
if (isPTR(atom)) {
  app = getPTR(atom);
  TAIL_EVAL_APP:
  if (isFUN(app[1])) {
    L_PUSH(makePTR(app));
    if (R_top_current) {
      R_top_current[0] = makeHDR(1);
      R_top_current[1] = makePTR(app);
    }
    R_top_current = R_sp[1].current = app;
    goto *getFUN(app[1]);
  }
  else if (isPTR(app[1])) {
    app = getPTR(app[1]);
    goto TAIL_EVAL_APP;
  }
  else if (isINT(app[1])) {
    L_PUSH(app[1]); res = getINT(app[1]);
    goto EVAL_RET;
  }
  else {
    L_PUSH(makePTR(app)); res = getCTR(app[1]);
    goto EVAL_RET;
  }
} else {
  L_PUSH(atom);
  res = getINT(atom);
  goto EVAL_RET;
}
F_main:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_254;
  goto GC_COLLECT;
}
  GC_RET_254:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = makeINT(112);
hp[3] = makeCTR(C_Nil);
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = makeINT(111);
hp[7] = makePTR(hp+0);
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makeINT(110);
hp[11] = makePTR(hp+4);
hp[12] = makeHDR(3);
hp[13] = makeCTR(C_Cons);
hp[14] = makeINT(109);
hp[15] = makePTR(hp+8);
hp[16] = makeHDR(3);
hp[17] = makeCTR(C_Cons);
hp[18] = makeINT(108);
hp[19] = makePTR(hp+12);
hp[20] = makeHDR(3);
hp[21] = makeCTR(C_Cons);
hp[22] = makeINT(107);
hp[23] = makePTR(hp+16);
hp[24] = makeHDR(3);
hp[25] = makeCTR(C_Cons);
hp[26] = makeINT(106);
hp[27] = makePTR(hp+20);
hp[28] = makeHDR(3);
hp[29] = makeCTR(C_Cons);
hp[30] = makeINT(105);
hp[31] = makePTR(hp+24);
hp[32] = makeHDR(3);
hp[33] = makeCTR(C_Cons);
hp[34] = makeINT(104);
hp[35] = makePTR(hp+28);
hp[36] = makeHDR(3);
hp[37] = makeCTR(C_Cons);
hp[38] = makeINT(103);
hp[39] = makePTR(hp+32);
hp[40] = makeHDR(3);
hp[41] = makeCTR(C_Cons);
hp[42] = makeINT(102);
hp[43] = makePTR(hp+36);
hp[44] = makeHDR(3);
hp[45] = makeCTR(C_Cons);
hp[46] = makeINT(101);
hp[47] = makePTR(hp+40);
hp[48] = makeHDR(3);
hp[49] = makeCTR(C_Cons);
hp[50] = makeINT(100);
hp[51] = makePTR(hp+44);
hp[52] = makeHDR(3);
hp[53] = makeCTR(C_Cons);
hp[54] = makeINT(99);
hp[55] = makePTR(hp+48);
hp[56] = makeHDR(3);
hp[57] = makeCTR(C_Cons);
hp[58] = makeINT(98);
hp[59] = makePTR(hp+52);
hp[60] = makeHDR(3);
hp[61] = makeCTR(C_Cons);
hp[62] = makeINT(97);
hp[63] = makePTR(hp+56);
hp[64] = makeHDR(2);
hp[65] = makeFUN(&&F_main___0);
hp[66] = makePTR(hp+60);
atom = makePTR(hp+64);
hp += 67;
L_POP(1);
L_PUSH(atom);
goto F_main___0;
F_main___0:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_270;
  goto GC_COLLECT;
}
  GC_RET_270:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_mapImp);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = makeHDR(2);
hp[4] = makeFUN(&&F_conj);
hp[5] = makePTR(hp+0);
hp[6] = makeHDR(2);
hp[7] = makeCTR(C_Var);
hp[8] = makeINT(113);
hp[9] = makeHDR(2);
hp[10] = makeFUN(&&F_mapVar);
hp[11] = getPTR(L_sp[-1])[2];
hp[12] = makeHDR(2);
hp[13] = makeFUN(&&F_conj);
hp[14] = makePTR(hp+9);
hp[15] = makeHDR(3);
hp[16] = makeCTR(C_Implies);
hp[17] = makePTR(hp+6);
hp[18] = makePTR(hp+12);
hp[19] = makeHDR(3);
hp[20] = makeCTR(C_Implies);
hp[21] = makePTR(hp+3);
hp[22] = makePTR(hp+15);
hp[23] = makeHDR(2);
hp[24] = makeFUN(&&F_isTaut);
hp[25] = makePTR(hp+19);
atom = makePTR(hp+23);
hp += 26;
eval_ret_addr = &&LABEL_278;
goto EVAL;
LABEL_278:
switch (res) {
case C_True:
L_POP(2);
L_PUSH(makeINT(1));
res = 1;
goto EVAL_RET;
case C_False:
L_POP(2);
L_PUSH(makeINT(0));
res = 0;
goto EVAL_RET;
}
F_find:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_279;
  goto GC_COLLECT;
}
  GC_RET_279:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_280;
goto EVAL;
LABEL_280:
switch (res) {
case C_Cons:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_281;
goto EVAL;
LABEL_281:
switch (res) {
case C_Pair:
atom = getPTR(L_sp[-3])[2];
eval_ret_addr = &&LABEL_282;
goto EVAL;
LABEL_282:
atom = getPTR(L_sp[-2])[2];
eval_ret_addr = &&LABEL_283;
goto EVAL;
LABEL_283:
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(1);
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
atom = getPTR(L_sp[-2])[3];
L_POP(4);
goto TAIL_EVAL;
goto EVAL_RET;
case C_False:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_find);
hp[2] = getPTR(L_sp[-4])[2];
hp[3] = getPTR(L_sp[-3])[3];
atom = makePTR(hp+0);
hp += 4;
L_POP(4);
L_PUSH(atom);
goto F_find;
}
}
}
F_eval:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_284;
  goto GC_COLLECT;
}
  GC_RET_284:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_285;
goto EVAL;
LABEL_285:
switch (res) {
case C_Const:
atom = getPTR(L_sp[-1])[2];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
case C_Var:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_find);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-2])[2];
atom = makePTR(hp+0);
hp += 4;
L_POP(2);
L_PUSH(atom);
goto F_find;
case C_Not:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_eval);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_286;
goto EVAL;
LABEL_286:
switch (res) {
case C_True:
L_POP(3);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
case C_False:
L_POP(3);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
}
case C_And:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_eval);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_287;
goto EVAL;
LABEL_287:
switch (res) {
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_eval);
hp[2] = getPTR(L_sp[-3])[2];
hp[3] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+0);
hp += 4;
L_POP(3);
L_PUSH(atom);
goto F_eval;
case C_False:
L_POP(3);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
}
case C_Implies:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_eval);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_288;
goto EVAL;
LABEL_288:
switch (res) {
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_eval);
hp[2] = getPTR(L_sp[-3])[2];
hp[3] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+0);
hp += 4;
L_POP(3);
L_PUSH(atom);
goto F_eval;
case C_False:
L_POP(3);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
}
}
F_vars:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_289;
  goto GC_COLLECT;
}
  GC_RET_289:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_290;
goto EVAL;
LABEL_290:
switch (res) {
case C_Const:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Var:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = makeCTR(C_Nil);
atom = makePTR(hp+0);
hp += 4;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
case C_Not:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_vars);
hp[2] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+0);
hp += 3;
L_POP(2);
L_PUSH(atom);
goto F_vars;
case C_And:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_vars);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = makeHDR(2);
hp[4] = makeFUN(&&F_vars);
hp[5] = getPTR(L_sp[-1])[3];
hp[6] = makeHDR(3);
hp[7] = makeFUN(&&F_append);
hp[8] = makePTR(hp+0);
hp[9] = makePTR(hp+3);
atom = makePTR(hp+6);
hp += 10;
L_POP(2);
L_PUSH(atom);
goto F_append;
case C_Implies:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_vars);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = makeHDR(2);
hp[4] = makeFUN(&&F_vars);
hp[5] = getPTR(L_sp[-1])[3];
hp[6] = makeHDR(3);
hp[7] = makeFUN(&&F_append);
hp[8] = makePTR(hp+0);
hp[9] = makePTR(hp+3);
atom = makePTR(hp+6);
hp += 10;
L_POP(2);
L_PUSH(atom);
goto F_append;
}
F_bools:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_295;
  goto GC_COLLECT;
}
  GC_RET_295:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_296;
goto EVAL;
LABEL_296:
L_PUSH(makeINT(0));
res = 0;
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(1);
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = makeCTR(C_Nil);
hp[3] = makeCTR(C_Nil);
atom = makePTR(hp+0);
hp += 4;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
case C_False:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&P_SUB);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = makeINT(1);
hp[4] = makeHDR(2);
hp[5] = makeFUN(&&F_bools);
hp[6] = makePTR(hp+0);
hp[7] = makeHDR(3);
hp[8] = makeFUN(&&F_mapCons);
hp[9] = makeCTR(C_False);
hp[10] = makePTR(hp+4);
hp[11] = makeHDR(2);
hp[12] = makeFUN(&&F_bools);
hp[13] = makePTR(hp+0);
hp[14] = makeHDR(3);
hp[15] = makeFUN(&&F_mapCons);
hp[16] = makeCTR(C_True);
hp[17] = makePTR(hp+11);
hp[18] = makeHDR(3);
hp[19] = makeFUN(&&F_append);
hp[20] = makePTR(hp+7);
hp[21] = makePTR(hp+14);
atom = makePTR(hp+18);
hp += 22;
L_POP(2);
L_PUSH(atom);
goto F_append;
}
F_mapCons:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_301;
  goto GC_COLLECT;
}
  GC_RET_301:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_302;
goto EVAL;
LABEL_302:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_mapCons);
hp[6] = getPTR(L_sp[-2])[2];
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
F_rmdups:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_305;
  goto GC_COLLECT;
}
  GC_RET_305:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_306;
goto EVAL;
LABEL_306:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_filterNeq);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-1])[3];
hp[4] = makeHDR(2);
hp[5] = makeFUN(&&F_rmdups);
hp[6] = makePTR(hp+0);
hp[7] = makeHDR(3);
hp[8] = makeCTR(C_Cons);
hp[9] = getPTR(L_sp[-1])[2];
hp[10] = makePTR(hp+4);
atom = makePTR(hp+7);
hp += 11;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
F_substs:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_309;
  goto GC_COLLECT;
}
  GC_RET_309:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_vars);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = makeHDR(2);
hp[4] = makeFUN(&&F_rmdups);
hp[5] = makePTR(hp+0);
hp[6] = makeHDR(2);
hp[7] = makeFUN(&&F_length);
hp[8] = makePTR(hp+3);
hp[9] = makeHDR(2);
hp[10] = makeFUN(&&F_bools);
hp[11] = makePTR(hp+6);
hp[12] = makeHDR(3);
hp[13] = makeFUN(&&F_mapZip);
hp[14] = makePTR(hp+3);
hp[15] = makePTR(hp+9);
atom = makePTR(hp+12);
hp += 16;
L_POP(1);
L_PUSH(atom);
goto F_mapZip;
F_mapZip:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_313;
  goto GC_COLLECT;
}
  GC_RET_313:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_314;
goto EVAL;
LABEL_314:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_zip);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_mapZip);
hp[6] = getPTR(L_sp[-2])[2];
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
F_isTaut:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_317;
  goto GC_COLLECT;
}
  GC_RET_317:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_substs);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = makeHDR(3);
hp[4] = makeFUN(&&F_mapEval);
hp[5] = getPTR(L_sp[-1])[2];
hp[6] = makePTR(hp+0);
hp[7] = makeHDR(2);
hp[8] = makeFUN(&&F_and);
hp[9] = makePTR(hp+3);
atom = makePTR(hp+7);
hp += 10;
L_POP(1);
L_PUSH(atom);
goto F_and;
F_mapEval:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_320;
  goto GC_COLLECT;
}
  GC_RET_320:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_321;
goto EVAL;
LABEL_321:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_eval);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-2])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_mapEval);
hp[6] = getPTR(L_sp[-2])[2];
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
F_length:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_324;
  goto GC_COLLECT;
}
  GC_RET_324:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_325;
goto EVAL;
LABEL_325:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeINT(0));
res = 0;
goto EVAL_RET;
case C_Cons:
L_PUSH(makeINT(1));
res = 1;
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_length);
hp[2] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+0);
hp += 3;
eval_ret_addr = &&LABEL_326;
goto EVAL;
LABEL_326:
L_POP(1);
res = getINT(L_top) + res;
L_POP(3);
L_PUSH(makeINT(res));
goto EVAL_RET;
}
F_append:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_327;
  goto GC_COLLECT;
}
  GC_RET_327:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_328;
goto EVAL;
LABEL_328:
switch (res) {
case C_Nil:
atom = getPTR(L_sp[-2])[3];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_append);
hp[2] = getPTR(L_sp[-1])[3];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = getPTR(L_sp[-1])[2];
hp[7] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 8;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
F_and:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_330;
  goto GC_COLLECT;
}
  GC_RET_330:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_331;
goto EVAL;
LABEL_331:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
case C_Cons:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_332;
goto EVAL;
LABEL_332:
switch (res) {
case C_True:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_and);
hp[2] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+0);
hp += 3;
L_POP(3);
L_PUSH(atom);
goto F_and;
case C_False:
L_POP(3);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
}
}
F_filterNeq:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_333;
  goto GC_COLLECT;
}
  GC_RET_333:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_334;
goto EVAL;
LABEL_334:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
atom = getPTR(L_sp[-2])[2];
eval_ret_addr = &&LABEL_335;
goto EVAL;
LABEL_335:
atom = getPTR(L_sp[-2])[2];
eval_ret_addr = &&LABEL_336;
goto EVAL;
LABEL_336:
L_POP(1);
res = getINT(L_top) != res ? C_True : C_False;
L_POP(1);
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_filterNeq);
hp[2] = getPTR(L_sp[-3])[2];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = getPTR(L_sp[-2])[2];
hp[7] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 8;
L_POP(3);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
case C_False:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_filterNeq);
hp[2] = getPTR(L_sp[-3])[2];
hp[3] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+0);
hp += 4;
L_POP(3);
L_PUSH(atom);
goto F_filterNeq;
}
}
F_null:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_338;
  goto GC_COLLECT;
}
  GC_RET_338:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_339;
goto EVAL;
LABEL_339:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
case C_Cons:
L_POP(2);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
}
F_zip:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_340;
  goto GC_COLLECT;
}
  GC_RET_340:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_341;
goto EVAL;
LABEL_341:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
atom = getPTR(L_sp[-2])[3];
getPTR(L_sp[-2])[3] = makeINT(0);
eval_ret_addr = &&LABEL_342;
goto EVAL;
LABEL_342:
switch (res) {
case C_Nil:
L_POP(3);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Pair);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_zip);
hp[6] = getPTR(L_sp[-2])[3];
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(3);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
}
F_conj:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_345;
  goto GC_COLLECT;
}
  GC_RET_345:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_346;
goto EVAL;
LABEL_346:
switch (res) {
case C_Cons:
atom = getPTR(L_sp[-1])[3];
eval_ret_addr = &&LABEL_347;
goto EVAL;
LABEL_347:
switch (res) {
case C_Nil:
atom = getPTR(L_sp[-2])[2];
L_POP(3);
goto TAIL_EVAL;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_conj);
hp[2] = getPTR(L_sp[-2])[3];
hp[3] = makeHDR(3);
hp[4] = makeCTR(C_And);
hp[5] = getPTR(L_sp[-2])[2];
hp[6] = makePTR(hp+0);
atom = makePTR(hp+3);
hp += 7;
L_POP(3);
L_PUSH(atom);
res = C_And;
goto EVAL_RET;
}
}
F_imp:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_349;
  goto GC_COLLECT;
}
  GC_RET_349:
hp[0] = makeHDR(2);
hp[1] = makeCTR(C_Var);
hp[2] = makeINT(113);
hp[3] = makeHDR(2);
hp[4] = makeCTR(C_Var);
hp[5] = getPTR(L_sp[-1])[2];
hp[6] = makeHDR(3);
hp[7] = makeCTR(C_Implies);
hp[8] = makePTR(hp+0);
hp[9] = makePTR(hp+3);
atom = makePTR(hp+6);
hp += 10;
L_POP(1);
L_PUSH(atom);
res = C_Implies;
goto EVAL_RET;
F_mapVar:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_352;
  goto GC_COLLECT;
}
  GC_RET_352:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_353;
goto EVAL;
LABEL_353:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(2);
hp[1] = makeCTR(C_Var);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = makeHDR(2);
hp[4] = makeFUN(&&F_mapVar);
hp[5] = getPTR(L_sp[-1])[3];
hp[6] = makeHDR(3);
hp[7] = makeCTR(C_Cons);
hp[8] = makePTR(hp+0);
hp[9] = makePTR(hp+3);
atom = makePTR(hp+6);
hp += 10;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
F_mapImp:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_356;
  goto GC_COLLECT;
}
  GC_RET_356:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_357;
goto EVAL;
LABEL_357:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(2);
hp[1] = makeCTR(C_Var);
hp[2] = makeINT(113);
hp[3] = makeHDR(2);
hp[4] = makeCTR(C_Var);
hp[5] = getPTR(L_sp[-1])[2];
hp[6] = makeHDR(3);
hp[7] = makeCTR(C_Implies);
hp[8] = makePTR(hp+0);
hp[9] = makePTR(hp+3);
hp[10] = makeHDR(2);
hp[11] = makeFUN(&&F_mapImp);
hp[12] = getPTR(L_sp[-1])[3];
hp[13] = makeHDR(3);
hp[14] = makeCTR(C_Cons);
hp[15] = makePTR(hp+6);
hp[16] = makePTR(hp+10);
atom = makePTR(hp+13);
hp += 17;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
P_ADD:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_362;
  goto GC_COLLECT;
}
  GC_RET_362:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_363;
goto EVAL;
LABEL_363:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_364;
goto EVAL;
LABEL_364:
L_POP(1);
res = getINT(L_top) + res;
L_POP(2);
L_PUSH(makeINT(res));
goto EVAL_RET;
P_SUB:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_365;
  goto GC_COLLECT;
}
  GC_RET_365:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_366;
goto EVAL;
LABEL_366:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_367;
goto EVAL;
LABEL_367:
L_POP(1);
res = getINT(L_top) - res;
L_POP(2);
L_PUSH(makeINT(res));
goto EVAL_RET;
P_EQ:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_368;
  goto GC_COLLECT;
}
  GC_RET_368:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_369;
goto EVAL;
LABEL_369:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_370;
goto EVAL;
LABEL_370:
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(2);
L_PUSH(makeCTR(res));
goto EVAL_RET;
P_NEQ:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_371;
  goto GC_COLLECT;
}
  GC_RET_371:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_372;
goto EVAL;
LABEL_372:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_373;
goto EVAL;
LABEL_373:
L_POP(1);
res = getINT(L_top) != res ? C_True : C_False;
L_POP(2);
L_PUSH(makeCTR(res));
goto EVAL_RET;
P_LEQ:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_374;
  goto GC_COLLECT;
}
  GC_RET_374:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_375;
goto EVAL;
LABEL_375:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_376;
goto EVAL;
LABEL_376:
L_POP(1);
res = getINT(L_top) <= res ? C_True : C_False;
L_POP(2);
L_PUSH(makeCTR(res));
goto EVAL_RET;
GC_COPY:
if (from[0] == VISITED) {
  atom = from[1];
  goto *gc_copy_ret;
}
if (isPTR(from[1])) { from = getPTR(from[1]); goto GC_COPY; }
if (size(from[0]) == 1) { atom = from[1]; }
else {
  n = size(from[0]) + 1;
  //printf("Copy (%i);\n", n-1);
  atom = makePTR(free);
  for (i = 0; i < n; i++)
    { *free = from[i]; free++; }
  from[0] = VISITED;
  from[1] = atom;
}
goto *gc_copy_ret;
GC_COLLECT:
//printf("GC invoked (%i);\n", hp - fromSpace);
scan = toSpace;
free = toSpace;
for (p = L_base; p < L_sp; p++) {
  if (isPTR(*p)) {
    from = getPTR(*p);
    gc_copy_ret = &&GC_COPY_RET1; goto GC_COPY; GC_COPY_RET1:
    *p = atom;
  }
}
while (scan < free) {
  m = size(*scan); scan++;
  //printf("Scan (%i);\n", m);
  for (j = 0; j < m; j++) {
    if (isPTR(*scan)) {
      from = getPTR(*scan);
      gc_copy_ret = &&GC_COPY_RET2; goto GC_COPY; GC_COPY_RET2:
      *scan = atom;
    }
    scan++;
  }
}
for (frame = R_base; frame > R_sp; frame--) {
  p = frame->current;
  frame->current = 0;
  while (p && p[0] != VISITED && isPTR(p[1])) p = getPTR(p[1]);
  if (p && p[0] == VISITED) {
    if (isPTR(p[1])) frame->current = getPTR(p[1]);
  }
}
hp = free;
p = fromSpace; fromSpace = toSpace; toSpace = p;
p = fromSpaceEnd; fromSpaceEnd = toSpaceEnd; toSpaceEnd = p;
heapEnd = fromSpaceEnd;
L_top = L_sp[-1];
R_top_returnAddress = R_sp[1].returnAddress;
R_top_current = R_sp[1].current;
//printf("GC finished (%i);\n", hp - fromSpace);
goto *gc_ret;
}



