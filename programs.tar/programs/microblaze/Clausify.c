#include <stdio.h>
#include <stdlib.h>
typedef unsigned int Atom;
#define isPTR(a)   (((a)&3) == 0)
#define isCTR(a)   (((a)&3) == 1)
#define isINT(a)   (((a)&3) == 2)
#define isFUN(a)   (((a)&3) == 3)
#define getPTR(a)  ((Atom*) (a))
#define getCTR(a)  ((a) >> 2)
#define getINT(a)  ((int) (((int) (a)) >> 2))
#define getFUN(a)  ((void*) (((unsigned int) (a)) & (~3)))
#define makePTR(x) ((Atom) (x))
#define makeCTR(x) ((Atom) (((x) << 2) | 1))
#define makeINT(x) ((Atom) ((((unsigned int) (x)) << 2) | 2))
#define makeFUN(x) ((Atom) (((unsigned int) (x)) | 3))
#define HEAP_SIZE 22000
#define STACK_SIZE 3000
typedef struct {
  Atom* current;
  void* returnAddress;
} Frame;
#define L_POP(n) L_sp-=n; L_top = L_sp[-1];
#define L_PUSH(a) L_top = a; L_sp[0] = L_top; L_sp++;
#define R_POP \
  R_sp++;\
  R_top_returnAddress = R_sp[1].returnAddress;\
  R_top_current = R_sp[1].current;
#define R_PUSH(ra, cur) \
  R_top_returnAddress = R_sp[0].returnAddress = ra; \
  R_top_current = R_sp[0].current = cur; \
  R_sp--;
#define makeHDR(x)        ((x) << 1)
#define VISITED           1
#define size(x)           ((x) >> 1)
#define C_False 0
#define C_True 1
#define C_Cons 0
#define C_Nil 1
#define C_Pair 0
#define C_Con 0
#define C_Dis 1
#define C_Neg 2
#define C_Sym 3


int main() {
register Atom* L_sp;
Atom* L_base;
register Atom L_top;
register Frame* R_sp;
Frame* R_base;
register void* R_top_returnAddress;
register Atom* R_top_current;
register Atom* hp;
register Atom* heapEnd;
register Atom atom;
register Atom* app;
register int res;
Atom* fromSpace;
Atom* toSpace;
Atom* fromSpaceEnd;
Atom* toSpaceEnd;
Atom* scan;
Atom* free;
Atom* p;
Atom* from;
Frame* frame;
void* gc_copy_ret;
void* gc_ret;
void* eval_ret_addr;
int i;
int j;
int n;
int m;
L_base = L_sp = malloc(sizeof(Atom) * STACK_SIZE);
R_base = R_sp = (Frame*) &L_sp[STACK_SIZE-1];
fromSpace = hp = malloc(sizeof(Atom) * HEAP_SIZE);
heapEnd = fromSpaceEnd = &fromSpace[HEAP_SIZE-1000];
toSpace = malloc(sizeof(Atom) * HEAP_SIZE);
toSpaceEnd = &toSpace[HEAP_SIZE-1000];
print("S");
atom = makePTR(hp);
*hp++ = makeHDR(1); *hp++ =  makeFUN(&&F_main);
L_PUSH(atom);
eval_ret_addr = &&LABEL_446;
goto EVAL;
LABEL_446:
putnum(getINT(L_top));
return 0;
EVAL:
if (isPTR(atom)) {
  app = getPTR(atom);
  EVAL_APP:
  if (isFUN(app[1])) {
    L_PUSH(makePTR(app));
    R_PUSH(eval_ret_addr, app);
    goto *getFUN(app[1]);
    EVAL_RET:
    if (R_top_current) {
      R_top_current[0] = makeHDR(1);
      R_top_current[1] = L_top;
    }
    eval_ret_addr = R_top_returnAddress;
    R_POP;
    goto *eval_ret_addr;
  }
  else if (isCTR(app[1])) {
    L_PUSH(makePTR(app)); res = getCTR(app[1]);
    goto *eval_ret_addr;
  }
  else if (isPTR(app[1])) {
    app = getPTR(app[1]);
    goto EVAL_APP;
  }
  else {
    L_PUSH(app[1]); res = getINT(app[1]);
    goto *eval_ret_addr;
  }
} else {
  L_PUSH(atom);
  res = getINT(atom);
  goto *eval_ret_addr;
}
TAIL_EVAL:
if (isPTR(atom)) {
  app = getPTR(atom);
  TAIL_EVAL_APP:
  if (isFUN(app[1])) {
    L_PUSH(makePTR(app));
    if (R_top_current) {
      R_top_current[0] = makeHDR(1);
      R_top_current[1] = makePTR(app);
    }
    R_top_current = R_sp[1].current = app;
    goto *getFUN(app[1]);
  }
  else if (isPTR(app[1])) {
    app = getPTR(app[1]);
    goto TAIL_EVAL_APP;
  }
  else if (isINT(app[1])) {
    L_PUSH(app[1]); res = getINT(app[1]);
    goto EVAL_RET;
  }
  else {
    L_PUSH(makePTR(app)); res = getCTR(app[1]);
    goto EVAL_RET;
  }
} else {
  L_PUSH(atom);
  res = getINT(atom);
  goto EVAL_RET;
}
F_main:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_447;
  goto GC_COLLECT;
}
  GC_RET_447:
hp[0] = makeHDR(2);
hp[1] = makeCTR(C_Sym);
hp[2] = makeINT(0);
hp[3] = makeHDR(3);
hp[4] = makeFUN(&&F_eqv);
hp[5] = makePTR(hp+0);
hp[6] = makePTR(hp+0);
hp[7] = makeHDR(3);
hp[8] = makeFUN(&&F_eqv);
hp[9] = makePTR(hp+0);
hp[10] = makePTR(hp+3);
hp[11] = makeHDR(3);
hp[12] = makeFUN(&&F_eqv);
hp[13] = makePTR(hp+0);
hp[14] = makePTR(hp+0);
hp[15] = makeHDR(3);
hp[16] = makeFUN(&&F_eqv);
hp[17] = makePTR(hp+0);
hp[18] = makePTR(hp+11);
hp[19] = makeHDR(3);
hp[20] = makeFUN(&&F_eqv);
hp[21] = makePTR(hp+0);
hp[22] = makePTR(hp+0);
hp[23] = makeHDR(3);
hp[24] = makeFUN(&&F_eqv);
hp[25] = makePTR(hp+0);
hp[26] = makePTR(hp+19);
hp[27] = makeHDR(3);
hp[28] = makeFUN(&&F_eqv);
hp[29] = makePTR(hp+15);
hp[30] = makePTR(hp+23);
hp[31] = makeHDR(3);
hp[32] = makeFUN(&&F_eqv);
hp[33] = makePTR(hp+7);
hp[34] = makePTR(hp+27);
hp[35] = makeHDR(3);
hp[36] = makeFUN(&&F_replicate);
hp[37] = makeINT(80);
hp[38] = makePTR(hp+31);
hp[39] = makeHDR(3);
hp[40] = makeFUN(&&F_foldCon);
hp[41] = makePTR(hp+0);
hp[42] = makePTR(hp+35);
hp[43] = makeHDR(2);
hp[44] = makeFUN(&&F_clausify);
hp[45] = makePTR(hp+39);
hp[46] = makeHDR(2);
hp[47] = makeFUN(&&F_display);
hp[48] = makePTR(hp+43);
atom = makePTR(hp+46);
hp += 49;
L_POP(1);
L_PUSH(atom);
goto F_display;
F_mapClauses:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_459;
  goto GC_COLLECT;
}
  GC_RET_459:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_460;
goto EVAL;
LABEL_460:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_clause);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_mapClauses);
hp[6] = getPTR(L_sp[-2])[2];
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
F_clauses:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_463;
  goto GC_COLLECT;
}
  GC_RET_463:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Pair);
hp[2] = makeCTR(C_Nil);
hp[3] = makeCTR(C_Nil);
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_mapClauses);
hp[6] = makePTR(hp+0);
hp[7] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+4);
hp += 8;
L_POP(1);
L_PUSH(atom);
goto F_mapClauses;
F_clause:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_465;
  goto GC_COLLECT;
}
  GC_RET_465:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_466;
goto EVAL;
LABEL_466:
switch (res) {
case C_Pair:
atom = getPTR(L_sp[-2])[3];
getPTR(L_sp[-2])[3] = makeINT(0);
eval_ret_addr = &&LABEL_467;
goto EVAL;
LABEL_467:
switch (res) {
case C_Dis:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Pair);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_clause);
hp[6] = makePTR(hp+0);
hp[7] = getPTR(L_sp[-1])[2];
hp[8] = makeHDR(3);
hp[9] = makeFUN(&&F_clause);
hp[10] = makePTR(hp+4);
hp[11] = getPTR(L_sp[-1])[3];
atom = makePTR(hp+8);
hp += 12;
L_POP(3);
L_PUSH(atom);
goto F_clause;
case C_Sym:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_ins);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-2])[2];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Pair);
hp[6] = makePTR(hp+0);
hp[7] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+4);
hp += 8;
L_POP(3);
L_PUSH(atom);
res = C_Pair;
goto EVAL_RET;
case C_Neg:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_471;
goto EVAL;
LABEL_471:
switch (res) {
case C_Sym:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_ins);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-3])[3];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Pair);
hp[6] = getPTR(L_sp[-3])[2];
hp[7] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 8;
L_POP(4);
L_PUSH(atom);
res = C_Pair;
goto EVAL_RET;
}
}
}
F_or:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_473;
  goto GC_COLLECT;
}
  GC_RET_473:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_474;
goto EVAL;
LABEL_474:
switch (res) {
case C_False:
atom = getPTR(L_sp[-2])[3];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
case C_True:
L_POP(2);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
}
F_containsEq:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_475;
  goto GC_COLLECT;
}
  GC_RET_475:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_476;
goto EVAL;
LABEL_476:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
case C_Cons:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_477;
goto EVAL;
LABEL_477:
atom = getPTR(L_sp[-3])[3];
eval_ret_addr = &&LABEL_478;
goto EVAL;
LABEL_478:
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(1);
L_PUSH(makeCTR(res));
switch (res) {
case C_False:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_containsEq);
hp[2] = getPTR(L_sp[-2])[3];
hp[3] = getPTR(L_sp[-3])[3];
atom = makePTR(hp+0);
hp += 4;
L_POP(3);
L_PUSH(atom);
goto F_containsEq;
case C_True:
L_POP(3);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
}
}
F_containsEqClause:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_479;
  goto GC_COLLECT;
}
  GC_RET_479:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_480;
goto EVAL;
LABEL_480:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
case C_Cons:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_481;
goto EVAL;
LABEL_481:
switch (res) {
case C_Pair:
atom = getPTR(L_sp[-3])[3];
getPTR(L_sp[-3])[3] = makeINT(0);
eval_ret_addr = &&LABEL_482;
goto EVAL;
LABEL_482:
switch (res) {
case C_Pair:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_eqList);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_483;
goto EVAL;
LABEL_483:
switch (res) {
case C_False:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_containsEqClause);
hp[2] = getPTR(L_sp[-4])[3];
hp[3] = getPTR(L_sp[-5])[3];
atom = makePTR(hp+0);
hp += 4;
L_POP(5);
L_PUSH(atom);
goto F_containsEqClause;
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_eqList);
hp[2] = getPTR(L_sp[-3])[3];
hp[3] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_484;
goto EVAL;
LABEL_484:
switch (res) {
case C_False:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_containsEqClause);
hp[2] = getPTR(L_sp[-5])[3];
hp[3] = getPTR(L_sp[-6])[3];
atom = makePTR(hp+0);
hp += 4;
L_POP(6);
L_PUSH(atom);
goto F_containsEqClause;
case C_True:
L_POP(6);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
}
}
}
}
}
F_disin:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_485;
  goto GC_COLLECT;
}
  GC_RET_485:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_486;
goto EVAL;
LABEL_486:
switch (res) {
case C_Sym:
hp[0] = makeHDR(2);
hp[1] = makeCTR(C_Sym);
hp[2] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+0);
hp += 3;
L_POP(2);
L_PUSH(atom);
res = C_Sym;
goto EVAL_RET;
case C_Neg:
hp[0] = makeHDR(2);
hp[1] = makeCTR(C_Neg);
hp[2] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+0);
hp += 3;
L_POP(2);
L_PUSH(atom);
res = C_Neg;
goto EVAL_RET;
case C_Con:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_disin);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = makeHDR(2);
hp[4] = makeFUN(&&F_disin);
hp[5] = getPTR(L_sp[-1])[3];
hp[6] = makeHDR(3);
hp[7] = makeCTR(C_Con);
hp[8] = makePTR(hp+0);
hp[9] = makePTR(hp+3);
atom = makePTR(hp+6);
hp += 10;
L_POP(2);
L_PUSH(atom);
res = C_Con;
goto EVAL_RET;
case C_Dis:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_disin);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = makeHDR(2);
hp[4] = makeFUN(&&F_disin);
hp[5] = getPTR(L_sp[-1])[3];
hp[6] = makeHDR(3);
hp[7] = makeFUN(&&F_din);
hp[8] = makePTR(hp+0);
hp[9] = makePTR(hp+3);
atom = makePTR(hp+6);
hp += 10;
L_POP(2);
L_PUSH(atom);
goto F_din;
}
F_din:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_491;
  goto GC_COLLECT;
}
  GC_RET_491:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_492;
goto EVAL;
LABEL_492:
switch (res) {
case C_Con:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_din);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_din);
hp[6] = getPTR(L_sp[-1])[3];
hp[7] = getPTR(L_sp[-2])[3];
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Con);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(2);
L_PUSH(atom);
res = C_Con;
goto EVAL_RET;
case C_Dis:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Dis);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-1])[3];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_din2);
hp[6] = makePTR(hp+0);
hp[7] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+4);
hp += 8;
L_POP(2);
L_PUSH(atom);
goto F_din2;
case C_Neg:
hp[0] = makeHDR(2);
hp[1] = makeCTR(C_Neg);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = makeHDR(3);
hp[4] = makeFUN(&&F_din2);
hp[5] = makePTR(hp+0);
hp[6] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+3);
hp += 7;
L_POP(2);
L_PUSH(atom);
goto F_din2;
case C_Sym:
hp[0] = makeHDR(2);
hp[1] = makeCTR(C_Sym);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = makeHDR(3);
hp[4] = makeFUN(&&F_din2);
hp[5] = makePTR(hp+0);
hp[6] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+3);
hp += 7;
L_POP(2);
L_PUSH(atom);
goto F_din2;
}
F_din2:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_498;
  goto GC_COLLECT;
}
  GC_RET_498:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_499;
goto EVAL;
LABEL_499:
switch (res) {
case C_Con:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_din);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_din);
hp[6] = getPTR(L_sp[-2])[2];
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Con);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(2);
L_PUSH(atom);
res = C_Con;
goto EVAL_RET;
case C_Dis:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Dis);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-1])[3];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Dis);
hp[6] = getPTR(L_sp[-2])[2];
hp[7] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 8;
L_POP(2);
L_PUSH(atom);
res = C_Dis;
goto EVAL_RET;
case C_Neg:
hp[0] = makeHDR(2);
hp[1] = makeCTR(C_Neg);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = makeHDR(3);
hp[4] = makeCTR(C_Dis);
hp[5] = getPTR(L_sp[-2])[2];
hp[6] = makePTR(hp+0);
atom = makePTR(hp+3);
hp += 7;
L_POP(2);
L_PUSH(atom);
res = C_Dis;
goto EVAL_RET;
case C_Sym:
hp[0] = makeHDR(2);
hp[1] = makeCTR(C_Sym);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = makeHDR(3);
hp[4] = makeCTR(C_Dis);
hp[5] = getPTR(L_sp[-2])[2];
hp[6] = makePTR(hp+0);
atom = makePTR(hp+3);
hp += 7;
L_POP(2);
L_PUSH(atom);
res = C_Dis;
goto EVAL_RET;
}
F_ins:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_505;
  goto GC_COLLECT;
}
  GC_RET_505:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_506;
goto EVAL;
LABEL_506:
switch (res) {
case C_Nil:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = makeCTR(C_Nil);
atom = makePTR(hp+0);
hp += 4;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
case C_Cons:
atom = getPTR(L_sp[-2])[2];
eval_ret_addr = &&LABEL_507;
goto EVAL;
LABEL_507:
atom = getPTR(L_sp[-2])[2];
eval_ret_addr = &&LABEL_508;
goto EVAL;
LABEL_508:
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(1);
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+0);
hp += 4;
L_POP(3);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
case C_False:
atom = getPTR(L_sp[-3])[2];
eval_ret_addr = &&LABEL_509;
goto EVAL;
LABEL_509:
atom = getPTR(L_sp[-3])[2];
eval_ret_addr = &&LABEL_510;
goto EVAL;
LABEL_510:
L_POP(1);
res = getINT(L_top) <= res ? C_True : C_False;
L_POP(1);
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = getPTR(L_sp[-3])[2];
hp[3] = getPTR(L_sp[-3])[3];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = getPTR(L_sp[-4])[2];
hp[7] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 8;
L_POP(4);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
case C_False:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_ins);
hp[2] = getPTR(L_sp[-4])[2];
hp[3] = getPTR(L_sp[-3])[3];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = getPTR(L_sp[-3])[2];
hp[7] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 8;
L_POP(4);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
}
}
F_filterConEq:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_513;
  goto GC_COLLECT;
}
  GC_RET_513:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_514;
goto EVAL;
LABEL_514:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_containsEq);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_515;
goto EVAL;
LABEL_515:
switch (res) {
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_filterConEq);
hp[2] = getPTR(L_sp[-3])[2];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = getPTR(L_sp[-2])[2];
hp[7] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 8;
L_POP(3);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
case C_False:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_filterConEq);
hp[2] = getPTR(L_sp[-3])[2];
hp[3] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+0);
hp += 4;
L_POP(3);
L_PUSH(atom);
goto F_filterConEq;
}
}
F_filterNotTaut:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_517;
  goto GC_COLLECT;
}
  GC_RET_517:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_518;
goto EVAL;
LABEL_518:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_519;
goto EVAL;
LABEL_519:
switch (res) {
case C_Pair:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_filterConEq);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-1])[3];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_520;
goto EVAL;
LABEL_520:
switch (res) {
case C_Nil:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_filterNotTaut);
hp[2] = getPTR(L_sp[-3])[3];
hp[3] = makeHDR(3);
hp[4] = makeCTR(C_Cons);
hp[5] = getPTR(L_sp[-3])[2];
hp[6] = makePTR(hp+0);
atom = makePTR(hp+3);
hp += 7;
L_POP(4);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_filterNotTaut);
hp[2] = getPTR(L_sp[-3])[3];
atom = makePTR(hp+0);
hp += 3;
L_POP(4);
L_PUSH(atom);
goto F_filterNotTaut;
}
}
}
F_filterCompNot:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_522;
  goto GC_COLLECT;
}
  GC_RET_522:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_523;
goto EVAL;
LABEL_523:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_containsEqClause);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_524;
goto EVAL;
LABEL_524:
switch (res) {
case C_False:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_filterCompNot);
hp[2] = getPTR(L_sp[-3])[2];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = getPTR(L_sp[-2])[2];
hp[7] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 8;
L_POP(3);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_filterCompNot);
hp[2] = getPTR(L_sp[-3])[2];
hp[3] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+0);
hp += 4;
L_POP(3);
L_PUSH(atom);
goto F_filterCompNot;
}
}
F_inter:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_526;
  goto GC_COLLECT;
}
  GC_RET_526:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_filterConEq);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-1])[3];
atom = makePTR(hp+0);
hp += 4;
L_POP(1);
L_PUSH(atom);
goto F_filterConEq;
F_negin:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_527;
  goto GC_COLLECT;
}
  GC_RET_527:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_528;
goto EVAL;
LABEL_528:
switch (res) {
case C_Neg:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_529;
goto EVAL;
LABEL_529:
switch (res) {
case C_Con:
hp[0] = makeHDR(2);
hp[1] = makeCTR(C_Neg);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = makeHDR(2);
hp[4] = makeFUN(&&F_negin);
hp[5] = makePTR(hp+0);
hp[6] = makeHDR(2);
hp[7] = makeCTR(C_Neg);
hp[8] = getPTR(L_sp[-1])[3];
hp[9] = makeHDR(2);
hp[10] = makeFUN(&&F_negin);
hp[11] = makePTR(hp+6);
hp[12] = makeHDR(3);
hp[13] = makeCTR(C_Dis);
hp[14] = makePTR(hp+3);
hp[15] = makePTR(hp+9);
atom = makePTR(hp+12);
hp += 16;
L_POP(3);
L_PUSH(atom);
res = C_Dis;
goto EVAL_RET;
case C_Dis:
hp[0] = makeHDR(2);
hp[1] = makeCTR(C_Neg);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = makeHDR(2);
hp[4] = makeFUN(&&F_negin);
hp[5] = makePTR(hp+0);
hp[6] = makeHDR(2);
hp[7] = makeCTR(C_Neg);
hp[8] = getPTR(L_sp[-1])[3];
hp[9] = makeHDR(2);
hp[10] = makeFUN(&&F_negin);
hp[11] = makePTR(hp+6);
hp[12] = makeHDR(3);
hp[13] = makeCTR(C_Con);
hp[14] = makePTR(hp+3);
hp[15] = makePTR(hp+9);
atom = makePTR(hp+12);
hp += 16;
L_POP(3);
L_PUSH(atom);
res = C_Con;
goto EVAL_RET;
case C_Neg:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_negin);
hp[2] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+0);
hp += 3;
L_POP(3);
L_PUSH(atom);
goto F_negin;
case C_Sym:
hp[0] = makeHDR(2);
hp[1] = makeCTR(C_Sym);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = makeHDR(2);
hp[4] = makeCTR(C_Neg);
hp[5] = makePTR(hp+0);
atom = makePTR(hp+3);
hp += 6;
L_POP(3);
L_PUSH(atom);
res = C_Neg;
goto EVAL_RET;
}
case C_Dis:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_negin);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = makeHDR(2);
hp[4] = makeFUN(&&F_negin);
hp[5] = getPTR(L_sp[-1])[3];
hp[6] = makeHDR(3);
hp[7] = makeCTR(C_Dis);
hp[8] = makePTR(hp+0);
hp[9] = makePTR(hp+3);
atom = makePTR(hp+6);
hp += 10;
L_POP(2);
L_PUSH(atom);
res = C_Dis;
goto EVAL_RET;
case C_Con:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_negin);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = makeHDR(2);
hp[4] = makeFUN(&&F_negin);
hp[5] = getPTR(L_sp[-1])[3];
hp[6] = makeHDR(3);
hp[7] = makeCTR(C_Con);
hp[8] = makePTR(hp+0);
hp[9] = makePTR(hp+3);
atom = makePTR(hp+6);
hp += 10;
L_POP(2);
L_PUSH(atom);
res = C_Con;
goto EVAL_RET;
case C_Sym:
hp[0] = makeHDR(2);
hp[1] = makeCTR(C_Sym);
hp[2] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+0);
hp += 3;
L_POP(2);
L_PUSH(atom);
res = C_Sym;
goto EVAL_RET;
}
F_nonTaut:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_543;
  goto GC_COLLECT;
}
  GC_RET_543:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_filterNotTaut);
hp[2] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+0);
hp += 3;
L_POP(1);
L_PUSH(atom);
goto F_filterNotTaut;
F_and:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_544;
  goto GC_COLLECT;
}
  GC_RET_544:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_545;
goto EVAL;
LABEL_545:
switch (res) {
case C_False:
L_POP(2);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
case C_True:
atom = getPTR(L_sp[-2])[3];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
}
F_eqList:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_546;
  goto GC_COLLECT;
}
  GC_RET_546:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_547;
goto EVAL;
LABEL_547:
switch (res) {
case C_Nil:
atom = getPTR(L_sp[-2])[3];
getPTR(L_sp[-2])[3] = makeINT(0);
eval_ret_addr = &&LABEL_548;
goto EVAL;
LABEL_548:
switch (res) {
case C_Nil:
L_POP(3);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
case C_Cons:
L_POP(3);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
}
case C_Cons:
atom = getPTR(L_sp[-2])[3];
getPTR(L_sp[-2])[3] = makeINT(0);
eval_ret_addr = &&LABEL_549;
goto EVAL;
LABEL_549:
switch (res) {
case C_Nil:
L_POP(3);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
case C_Cons:
atom = getPTR(L_sp[-2])[2];
eval_ret_addr = &&LABEL_550;
goto EVAL;
LABEL_550:
atom = getPTR(L_sp[-2])[2];
eval_ret_addr = &&LABEL_551;
goto EVAL;
LABEL_551:
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(1);
L_PUSH(makeCTR(res));
switch (res) {
case C_False:
L_POP(4);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_eqList);
hp[2] = getPTR(L_sp[-3])[3];
hp[3] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+0);
hp += 4;
L_POP(4);
L_PUSH(atom);
goto F_eqList;
}
}
}
F_eqClause:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_552;
  goto GC_COLLECT;
}
  GC_RET_552:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_553;
goto EVAL;
LABEL_553:
switch (res) {
case C_Pair:
atom = getPTR(L_sp[-2])[3];
getPTR(L_sp[-2])[3] = makeINT(0);
eval_ret_addr = &&LABEL_554;
goto EVAL;
LABEL_554:
switch (res) {
case C_Pair:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_eqList);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_555;
goto EVAL;
LABEL_555:
switch (res) {
case C_False:
L_POP(4);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_eqList);
hp[2] = getPTR(L_sp[-3])[3];
hp[3] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+0);
hp += 4;
L_POP(4);
L_PUSH(atom);
goto F_eqList;
}
}
}
F_null:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_556;
  goto GC_COLLECT;
}
  GC_RET_556:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_557;
goto EVAL;
LABEL_557:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
case C_Cons:
L_POP(2);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
}
F_notTaut:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_558;
  goto GC_COLLECT;
}
  GC_RET_558:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_559;
goto EVAL;
LABEL_559:
switch (res) {
case C_Pair:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_filterConEq);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-1])[3];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_560;
goto EVAL;
LABEL_560:
switch (res) {
case C_Nil:
L_POP(3);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
case C_Cons:
L_POP(3);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
}
}
F_clausify:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_561;
  goto GC_COLLECT;
}
  GC_RET_561:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Pair);
hp[2] = makeCTR(C_Nil);
hp[3] = makeCTR(C_Nil);
hp[4] = makeHDR(2);
hp[5] = makeFUN(&&F_negin);
hp[6] = getPTR(L_sp[-1])[2];
hp[7] = makeHDR(2);
hp[8] = makeFUN(&&F_disin);
hp[9] = makePTR(hp+4);
hp[10] = makeHDR(3);
hp[11] = makeFUN(&&F_spl);
hp[12] = makeCTR(C_Nil);
hp[13] = makePTR(hp+7);
hp[14] = makeHDR(3);
hp[15] = makeFUN(&&F_mapClauses);
hp[16] = makePTR(hp+0);
hp[17] = makePTR(hp+10);
hp[18] = makeHDR(2);
hp[19] = makeFUN(&&F_filterNotTaut);
hp[20] = makePTR(hp+14);
hp[21] = makeHDR(2);
hp[22] = makeFUN(&&F_uniq);
hp[23] = makePTR(hp+18);
atom = makePTR(hp+21);
hp += 24;
L_POP(1);
L_PUSH(atom);
goto F_uniq;
F_split:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_568;
  goto GC_COLLECT;
}
  GC_RET_568:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_spl);
hp[2] = makeCTR(C_Nil);
hp[3] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+0);
hp += 4;
L_POP(1);
L_PUSH(atom);
goto F_spl;
F_spl:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_569;
  goto GC_COLLECT;
}
  GC_RET_569:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_570;
goto EVAL;
LABEL_570:
switch (res) {
case C_Con:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_spl);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_spl);
hp[6] = makePTR(hp+0);
hp[7] = getPTR(L_sp[-1])[3];
atom = makePTR(hp+4);
hp += 8;
L_POP(2);
L_PUSH(atom);
goto F_spl;
case C_Dis:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Dis);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-1])[3];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = makePTR(hp+0);
hp[7] = getPTR(L_sp[-2])[2];
atom = makePTR(hp+4);
hp += 8;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
case C_Neg:
hp[0] = makeHDR(2);
hp[1] = makeCTR(C_Neg);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = makeHDR(3);
hp[4] = makeCTR(C_Cons);
hp[5] = makePTR(hp+0);
hp[6] = getPTR(L_sp[-2])[2];
atom = makePTR(hp+3);
hp += 7;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
case C_Sym:
hp[0] = makeHDR(2);
hp[1] = makeCTR(C_Sym);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = makeHDR(3);
hp[4] = makeCTR(C_Cons);
hp[5] = makePTR(hp+0);
hp[6] = getPTR(L_sp[-2])[2];
atom = makePTR(hp+3);
hp += 7;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
F_append:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_575;
  goto GC_COLLECT;
}
  GC_RET_575:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_576;
goto EVAL;
LABEL_576:
switch (res) {
case C_Nil:
atom = getPTR(L_sp[-2])[3];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_append);
hp[2] = getPTR(L_sp[-1])[3];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = getPTR(L_sp[-1])[2];
hp[7] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 8;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
F_not:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_578;
  goto GC_COLLECT;
}
  GC_RET_578:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_579;
goto EVAL;
LABEL_579:
switch (res) {
case C_False:
L_POP(2);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
case C_True:
L_POP(2);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
}
F_union:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_580;
  goto GC_COLLECT;
}
  GC_RET_580:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_filterCompNot);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-1])[3];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_append);
hp[6] = getPTR(L_sp[-1])[2];
hp[7] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 8;
L_POP(1);
L_PUSH(atom);
goto F_append;
F_singleton:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_582;
  goto GC_COLLECT;
}
  GC_RET_582:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = makeCTR(C_Nil);
atom = makePTR(hp+0);
hp += 4;
L_POP(1);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
F_foldCon:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_583;
  goto GC_COLLECT;
}
  GC_RET_583:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_584;
goto EVAL;
LABEL_584:
switch (res) {
case C_Nil:
atom = getPTR(L_sp[-2])[2];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_foldCon);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[3];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Con);
hp[6] = getPTR(L_sp[-1])[2];
hp[7] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 8;
L_POP(2);
L_PUSH(atom);
res = C_Con;
goto EVAL_RET;
}
F_uniq:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_586;
  goto GC_COLLECT;
}
  GC_RET_586:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_587;
goto EVAL;
LABEL_587:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = makeCTR(C_Nil);
hp[4] = makeHDR(2);
hp[5] = makeFUN(&&F_uniq);
hp[6] = getPTR(L_sp[-1])[3];
hp[7] = makeHDR(3);
hp[8] = makeFUN(&&F_union);
hp[9] = makePTR(hp+0);
hp[10] = makePTR(hp+4);
atom = makePTR(hp+7);
hp += 11;
L_POP(2);
L_PUSH(atom);
goto F_union;
}
F_display:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_590;
  goto GC_COLLECT;
}
  GC_RET_590:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_591;
goto EVAL;
LABEL_591:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeINT(0));
res = 0;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_display___0);
hp[2] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+0);
hp += 3;
eval_ret_addr = &&LABEL_592;
goto EVAL;
LABEL_592:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_display);
hp[2] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+0);
hp += 3;
eval_ret_addr = &&LABEL_593;
goto EVAL;
LABEL_593:
L_POP(1);
res = getINT(L_top) + res;
L_POP(3);
L_PUSH(makeINT(res));
goto EVAL_RET;
}
F_display___0:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_594;
  goto GC_COLLECT;
}
  GC_RET_594:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_595;
goto EVAL;
LABEL_595:
switch (res) {
case C_Pair:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_sum);
hp[2] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+0);
hp += 3;
eval_ret_addr = &&LABEL_596;
goto EVAL;
LABEL_596:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_sum);
hp[2] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+0);
hp += 3;
eval_ret_addr = &&LABEL_597;
goto EVAL;
LABEL_597:
L_POP(1);
res = getINT(L_top) + res;
L_POP(3);
L_PUSH(makeINT(res));
goto EVAL_RET;
}
F_emitClause:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_598;
  goto GC_COLLECT;
}
  GC_RET_598:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_599;
goto EVAL;
LABEL_599:
switch (res) {
case C_Pair:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_sum);
hp[2] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+0);
hp += 3;
eval_ret_addr = &&LABEL_600;
goto EVAL;
LABEL_600:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_sum);
hp[2] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+0);
hp += 3;
eval_ret_addr = &&LABEL_601;
goto EVAL;
LABEL_601:
L_POP(1);
res = getINT(L_top) + res;
L_POP(3);
L_PUSH(makeINT(res));
goto EVAL_RET;
}
F_sum:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_602;
  goto GC_COLLECT;
}
  GC_RET_602:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_603;
goto EVAL;
LABEL_603:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeINT(0));
res = 0;
goto EVAL_RET;
case C_Cons:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_604;
goto EVAL;
LABEL_604:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_sum);
hp[2] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+0);
hp += 3;
eval_ret_addr = &&LABEL_605;
goto EVAL;
LABEL_605:
L_POP(1);
res = getINT(L_top) + res;
L_POP(3);
L_PUSH(makeINT(res));
goto EVAL_RET;
}
F_eqv:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_606;
  goto GC_COLLECT;
}
  GC_RET_606:
hp[0] = makeHDR(2);
hp[1] = makeCTR(C_Neg);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = makeHDR(3);
hp[4] = makeCTR(C_Dis);
hp[5] = makePTR(hp+0);
hp[6] = getPTR(L_sp[-1])[3];
hp[7] = makeHDR(2);
hp[8] = makeCTR(C_Neg);
hp[9] = getPTR(L_sp[-1])[3];
hp[10] = makeHDR(3);
hp[11] = makeCTR(C_Dis);
hp[12] = makePTR(hp+7);
hp[13] = getPTR(L_sp[-1])[2];
hp[14] = makeHDR(3);
hp[15] = makeCTR(C_Con);
hp[16] = makePTR(hp+3);
hp[17] = makePTR(hp+10);
atom = makePTR(hp+14);
hp += 18;
L_POP(1);
L_PUSH(atom);
res = C_Con;
goto EVAL_RET;
F_replicate:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_611;
  goto GC_COLLECT;
}
  GC_RET_611:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_612;
goto EVAL;
LABEL_612:
L_PUSH(makeINT(0));
res = 0;
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(1);
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_False:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&P_SUB);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = makeINT(1);
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_replicate);
hp[6] = makePTR(hp+0);
hp[7] = getPTR(L_sp[-2])[3];
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = getPTR(L_sp[-2])[3];
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
P_ADD:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_615;
  goto GC_COLLECT;
}
  GC_RET_615:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_616;
goto EVAL;
LABEL_616:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_617;
goto EVAL;
LABEL_617:
L_POP(1);
res = getINT(L_top) + res;
L_POP(2);
L_PUSH(makeINT(res));
goto EVAL_RET;
P_SUB:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_618;
  goto GC_COLLECT;
}
  GC_RET_618:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_619;
goto EVAL;
LABEL_619:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_620;
goto EVAL;
LABEL_620:
L_POP(1);
res = getINT(L_top) - res;
L_POP(2);
L_PUSH(makeINT(res));
goto EVAL_RET;
P_EQ:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_621;
  goto GC_COLLECT;
}
  GC_RET_621:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_622;
goto EVAL;
LABEL_622:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_623;
goto EVAL;
LABEL_623:
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(2);
L_PUSH(makeCTR(res));
goto EVAL_RET;
P_NEQ:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_624;
  goto GC_COLLECT;
}
  GC_RET_624:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_625;
goto EVAL;
LABEL_625:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_626;
goto EVAL;
LABEL_626:
L_POP(1);
res = getINT(L_top) != res ? C_True : C_False;
L_POP(2);
L_PUSH(makeCTR(res));
goto EVAL_RET;
P_LEQ:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_627;
  goto GC_COLLECT;
}
  GC_RET_627:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_628;
goto EVAL;
LABEL_628:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_629;
goto EVAL;
LABEL_629:
L_POP(1);
res = getINT(L_top) <= res ? C_True : C_False;
L_POP(2);
L_PUSH(makeCTR(res));
goto EVAL_RET;
GC_COPY:
if (from[0] == VISITED) {
  atom = from[1];
  goto *gc_copy_ret;
}
if (isPTR(from[1])) { from = getPTR(from[1]); goto GC_COPY; }
if (size(from[0]) == 1) { atom = from[1]; }
else {
  n = size(from[0]) + 1;
  //printf("Copy (%i);\n", n-1);
  atom = makePTR(free);
  for (i = 0; i < n; i++)
    { *free = from[i]; free++; }
  from[0] = VISITED;
  from[1] = atom;
}
goto *gc_copy_ret;
GC_COLLECT:
//printf("GC invoked (%i);\n", hp - fromSpace);
scan = toSpace;
free = toSpace;
for (p = L_base; p < L_sp; p++) {
  if (isPTR(*p)) {
    from = getPTR(*p);
    gc_copy_ret = &&GC_COPY_RET1; goto GC_COPY; GC_COPY_RET1:
    *p = atom;
  }
}
while (scan < free) {
  m = size(*scan); scan++;
  //printf("Scan (%i);\n", m);
  for (j = 0; j < m; j++) {
    if (isPTR(*scan)) {
      from = getPTR(*scan);
      gc_copy_ret = &&GC_COPY_RET2; goto GC_COPY; GC_COPY_RET2:
      *scan = atom;
    }
    scan++;
  }
}
for (frame = R_base; frame > R_sp; frame--) {
  p = frame->current;
  frame->current = 0;
  while (p && p[0] != VISITED && isPTR(p[1])) p = getPTR(p[1]);
  if (p && p[0] == VISITED) {
    if (isPTR(p[1])) frame->current = getPTR(p[1]);
  }
}
hp = free;
p = fromSpace; fromSpace = toSpace; toSpace = p;
p = fromSpaceEnd; fromSpaceEnd = toSpaceEnd; toSpaceEnd = p;
heapEnd = fromSpaceEnd;
L_top = L_sp[-1];
R_top_returnAddress = R_sp[1].returnAddress;
R_top_current = R_sp[1].current;
//printf("GC finished (%i);\n", hp - fromSpace);
goto *gc_ret;
}



