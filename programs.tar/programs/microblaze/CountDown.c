#include <stdio.h>
#include <stdlib.h>
typedef unsigned int Atom;
#define isPTR(a)   (((a)&3) == 0)
#define isCTR(a)   (((a)&3) == 1)
#define isINT(a)   (((a)&3) == 2)
#define isFUN(a)   (((a)&3) == 3)
#define getPTR(a)  ((Atom*) (a))
#define getCTR(a)  ((a) >> 2)
#define getINT(a)  ((int) (((int) (a)) >> 2))
#define getFUN(a)  ((void*) (((unsigned int) (a)) & (~3)))
#define makePTR(x) ((Atom) (x))
#define makeCTR(x) ((Atom) (((x) << 2) | 1))
#define makeINT(x) ((Atom) ((((unsigned int) (x)) << 2) | 2))
#define makeFUN(x) ((Atom) (((unsigned int) (x)) | 3))
#define HEAP_SIZE 22000
#define STACK_SIZE 3000
typedef struct {
  Atom* current;
  void* returnAddress;
} Frame;
#define L_POP(n) L_sp-=n; L_top = L_sp[-1];
#define L_PUSH(a) L_top = a; L_sp[0] = L_top; L_sp++;
#define R_POP \
  R_sp++;\
  R_top_returnAddress = R_sp[1].returnAddress;\
  R_top_current = R_sp[1].current;
#define R_PUSH(ra, cur) \
  R_top_returnAddress = R_sp[0].returnAddress = ra; \
  R_top_current = R_sp[0].current = cur; \
  R_sp--;
#define makeHDR(x)        ((x) << 1)
#define VISITED           1
#define size(x)           ((x) >> 1)
#define C_False 0
#define C_True 1
#define C_App 0
#define C_Val 1
#define C_Add 0
#define C_Div 1
#define C_Mul 2
#define C_Sub 3
#define C_Pair 0
#define C_Cons 0
#define C_Nil 1


int main() {
register Atom* L_sp;
Atom* L_base;
register Atom L_top;
register Frame* R_sp;
Frame* R_base;
register void* R_top_returnAddress;
register Atom* R_top_current;
register Atom* hp;
register Atom* heapEnd;
register Atom atom;
register Atom* app;
register int res;
Atom* fromSpace;
Atom* toSpace;
Atom* fromSpaceEnd;
Atom* toSpaceEnd;
Atom* scan;
Atom* free;
Atom* p;
Atom* from;
Frame* frame;
void* gc_copy_ret;
void* gc_ret;
void* eval_ret_addr;
int i;
int j;
int n;
int m;
L_base = L_sp = malloc(sizeof(Atom) * STACK_SIZE);
R_base = R_sp = (Frame*) &L_sp[STACK_SIZE-1];
fromSpace = hp = malloc(sizeof(Atom) * HEAP_SIZE);
heapEnd = fromSpaceEnd = &fromSpace[HEAP_SIZE-1000];
toSpace = malloc(sizeof(Atom) * HEAP_SIZE);
toSpaceEnd = &toSpace[HEAP_SIZE-1000];
print("S");
atom = makePTR(hp);
*hp++ = makeHDR(1); *hp++ =  makeFUN(&&F_main);
L_PUSH(atom);
eval_ret_addr = &&LABEL_391;
goto EVAL;
LABEL_391:
putnum(getINT(L_top));
return 0;
EVAL:
if (isPTR(atom)) {
  app = getPTR(atom);
  EVAL_APP:
  if (isFUN(app[1])) {
    L_PUSH(makePTR(app));
    R_PUSH(eval_ret_addr, app);
    goto *getFUN(app[1]);
    EVAL_RET:
    if (R_top_current) {
      R_top_current[0] = makeHDR(1);
      R_top_current[1] = L_top;
    }
    eval_ret_addr = R_top_returnAddress;
    R_POP;
    goto *eval_ret_addr;
  }
  else if (isCTR(app[1])) {
    L_PUSH(makePTR(app)); res = getCTR(app[1]);
    goto *eval_ret_addr;
  }
  else if (isPTR(app[1])) {
    app = getPTR(app[1]);
    goto EVAL_APP;
  }
  else {
    L_PUSH(app[1]); res = getINT(app[1]);
    goto *eval_ret_addr;
  }
} else {
  L_PUSH(atom);
  res = getINT(atom);
  goto *eval_ret_addr;
}
TAIL_EVAL:
if (isPTR(atom)) {
  app = getPTR(atom);
  TAIL_EVAL_APP:
  if (isFUN(app[1])) {
    L_PUSH(makePTR(app));
    if (R_top_current) {
      R_top_current[0] = makeHDR(1);
      R_top_current[1] = makePTR(app);
    }
    R_top_current = R_sp[1].current = app;
    goto *getFUN(app[1]);
  }
  else if (isPTR(app[1])) {
    app = getPTR(app[1]);
    goto TAIL_EVAL_APP;
  }
  else if (isINT(app[1])) {
    L_PUSH(app[1]); res = getINT(app[1]);
    goto EVAL_RET;
  }
  else {
    L_PUSH(makePTR(app)); res = getCTR(app[1]);
    goto EVAL_RET;
  }
} else {
  L_PUSH(atom);
  res = getINT(atom);
  goto EVAL_RET;
}
F_main:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_392;
  goto GC_COLLECT;
}
  GC_RET_392:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = makeINT(25);
hp[3] = makeCTR(C_Nil);
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = makeINT(10);
hp[7] = makePTR(hp+0);
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makeINT(7);
hp[11] = makePTR(hp+4);
hp[12] = makeHDR(3);
hp[13] = makeCTR(C_Cons);
hp[14] = makeINT(3);
hp[15] = makePTR(hp+8);
hp[16] = makeHDR(3);
hp[17] = makeCTR(C_Cons);
hp[18] = makeINT(1);
hp[19] = makePTR(hp+12);
hp[20] = makeHDR(2);
hp[21] = makeFUN(&&F_subs);
hp[22] = makePTR(hp+16);
hp[23] = makeHDR(2);
hp[24] = makeFUN(&&F_concatMapPerms);
hp[25] = makePTR(hp+20);
hp[26] = makeHDR(3);
hp[27] = makeFUN(&&F_concatMapSolns);
hp[28] = makeINT(765);
hp[29] = makePTR(hp+23);
hp[30] = makeHDR(2);
hp[31] = makeFUN(&&F_length);
hp[32] = makePTR(hp+26);
atom = makePTR(hp+30);
hp += 33;
L_POP(1);
L_PUSH(atom);
goto F_length;
F_size:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_401;
  goto GC_COLLECT;
}
  GC_RET_401:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_402;
goto EVAL;
LABEL_402:
switch (res) {
case C_Val:
L_POP(2);
L_PUSH(makeINT(1));
res = 1;
goto EVAL_RET;
case C_App:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_size);
hp[2] = getPTR(L_sp[-1])[3];
atom = makePTR(hp+0);
hp += 3;
eval_ret_addr = &&LABEL_403;
goto EVAL;
LABEL_403:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_size);
hp[2] = getPTR(L_sp[-2])[4];
atom = makePTR(hp+0);
hp += 3;
eval_ret_addr = &&LABEL_404;
goto EVAL;
LABEL_404:
L_POP(1);
res = getINT(L_top) + res;
L_POP(3);
L_PUSH(makeINT(res));
goto EVAL_RET;
}
F_valid:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_405;
  goto GC_COLLECT;
}
  GC_RET_405:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_406;
goto EVAL;
LABEL_406:
switch (res) {
case C_Add:
L_POP(2);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
case C_Sub:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_407;
goto EVAL;
LABEL_407:
atom = getPTR(L_sp[-3])[4];
eval_ret_addr = &&LABEL_408;
goto EVAL;
LABEL_408:
L_POP(1);
res = getINT(L_top) <= res ? C_True : C_False;
L_POP(1);
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
L_POP(3);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
case C_False:
L_POP(3);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
}
case C_Mul:
L_POP(2);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
case C_Div:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_valid___0);
hp[2] = getPTR(L_sp[-2])[3];
hp[3] = getPTR(L_sp[-2])[4];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_409;
goto EVAL;
LABEL_409:
L_PUSH(makeINT(0));
res = 0;
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(3);
L_PUSH(makeCTR(res));
goto EVAL_RET;
}
F_valid___0:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_410;
  goto GC_COLLECT;
}
  GC_RET_410:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_divMod);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-1])[3];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_411;
goto EVAL;
LABEL_411:
switch (res) {
case C_Pair:
atom = getPTR(L_sp[-1])[3];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
}
F_apply:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_412;
  goto GC_COLLECT;
}
  GC_RET_412:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_413;
goto EVAL;
LABEL_413:
switch (res) {
case C_Add:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_414;
goto EVAL;
LABEL_414:
atom = getPTR(L_sp[-3])[4];
eval_ret_addr = &&LABEL_415;
goto EVAL;
LABEL_415:
L_POP(1);
res = getINT(L_top) + res;
L_POP(3);
L_PUSH(makeINT(res));
goto EVAL_RET;
case C_Sub:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_416;
goto EVAL;
LABEL_416:
atom = getPTR(L_sp[-3])[4];
eval_ret_addr = &&LABEL_417;
goto EVAL;
LABEL_417:
L_POP(1);
res = getINT(L_top) - res;
L_POP(3);
L_PUSH(makeINT(res));
goto EVAL_RET;
case C_Mul:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_mul);
hp[2] = getPTR(L_sp[-2])[3];
hp[3] = getPTR(L_sp[-2])[4];
atom = makePTR(hp+0);
hp += 4;
L_POP(2);
L_PUSH(atom);
goto F_mul;
case C_Div:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_divMod);
hp[2] = getPTR(L_sp[-2])[3];
hp[3] = getPTR(L_sp[-2])[4];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_418;
goto EVAL;
LABEL_418:
switch (res) {
case C_Pair:
atom = getPTR(L_sp[-1])[2];
L_POP(3);
goto TAIL_EVAL;
goto EVAL_RET;
}
}
F_concatMap:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_419;
  goto GC_COLLECT;
}
  GC_RET_419:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_420;
goto EVAL;
LABEL_420:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(2);
hp[1] = getPTR(L_sp[-2])[2];
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = makeHDR(3);
hp[4] = makeFUN(&&F_concatMap);
hp[5] = getPTR(L_sp[-2])[2];
hp[6] = getPTR(L_sp[-1])[3];
hp[7] = makeHDR(3);
hp[8] = makeFUN(&&F_append);
hp[9] = makePTR(hp+0);
hp[10] = makePTR(hp+3);
atom = makePTR(hp+7);
hp += 11;
L_POP(2);
L_PUSH(atom);
goto F_append;
}
F_concatMapIlv:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_423;
  goto GC_COLLECT;
}
  GC_RET_423:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_424;
goto EVAL;
LABEL_424:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_interleave);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_concatMapIlv);
hp[6] = getPTR(L_sp[-2])[2];
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(3);
hp[9] = makeFUN(&&F_append);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(2);
L_PUSH(atom);
goto F_append;
}
F_concatMapPerms:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_427;
  goto GC_COLLECT;
}
  GC_RET_427:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_428;
goto EVAL;
LABEL_428:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_perms);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = makeHDR(2);
hp[4] = makeFUN(&&F_concatMapPerms);
hp[5] = getPTR(L_sp[-1])[3];
hp[6] = makeHDR(3);
hp[7] = makeFUN(&&F_append);
hp[8] = makePTR(hp+0);
hp[9] = makePTR(hp+3);
atom = makePTR(hp+6);
hp += 10;
L_POP(2);
L_PUSH(atom);
goto F_append;
}
F_concatMapCR:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_431;
  goto GC_COLLECT;
}
  GC_RET_431:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_432;
goto EVAL;
LABEL_432:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_combinedResults);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = makeHDR(2);
hp[4] = makeFUN(&&F_concatMapCR);
hp[5] = getPTR(L_sp[-1])[3];
hp[6] = makeHDR(3);
hp[7] = makeFUN(&&F_append);
hp[8] = makePTR(hp+0);
hp[9] = makePTR(hp+3);
atom = makePTR(hp+6);
hp += 10;
L_POP(2);
L_PUSH(atom);
goto F_append;
}
F_concatMapComb:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_435;
  goto GC_COLLECT;
}
  GC_RET_435:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_436;
goto EVAL;
LABEL_436:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_combine);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_concatMapComb);
hp[6] = getPTR(L_sp[-2])[2];
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(3);
hp[9] = makeFUN(&&F_append);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(2);
L_PUSH(atom);
goto F_append;
}
F_concatMapCombi:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_439;
  goto GC_COLLECT;
}
  GC_RET_439:
atom = getPTR(L_sp[-1])[6];
getPTR(L_sp[-1])[6] = makeINT(0);
eval_ret_addr = &&LABEL_440;
goto EVAL;
LABEL_440:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(6);
hp[1] = makeFUN(&&F_combi);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = getPTR(L_sp[-2])[4];
hp[5] = getPTR(L_sp[-2])[5];
hp[6] = getPTR(L_sp[-1])[2];
hp[7] = makeHDR(6);
hp[8] = makeFUN(&&F_concatMapCombi);
hp[9] = getPTR(L_sp[-2])[2];
hp[10] = getPTR(L_sp[-2])[3];
hp[11] = getPTR(L_sp[-2])[4];
hp[12] = getPTR(L_sp[-2])[5];
hp[13] = getPTR(L_sp[-1])[3];
hp[14] = makeHDR(3);
hp[15] = makeFUN(&&F_append);
hp[16] = makePTR(hp+0);
hp[17] = makePTR(hp+7);
atom = makePTR(hp+14);
hp += 18;
L_POP(2);
L_PUSH(atom);
goto F_append;
}
F_concatMapSolns:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_443;
  goto GC_COLLECT;
}
  GC_RET_443:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_444;
goto EVAL;
LABEL_444:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_solns);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_concatMapSolns);
hp[6] = getPTR(L_sp[-2])[2];
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(3);
hp[9] = makeFUN(&&F_append);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(2);
L_PUSH(atom);
goto F_append;
}
F_mapCons:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_447;
  goto GC_COLLECT;
}
  GC_RET_447:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_448;
goto EVAL;
LABEL_448:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_mapCons);
hp[6] = getPTR(L_sp[-2])[2];
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
F_mapCross:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_451;
  goto GC_COLLECT;
}
  GC_RET_451:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_452;
goto EVAL;
LABEL_452:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_mapCross___0);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-2])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_mapCross);
hp[6] = getPTR(L_sp[-2])[2];
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
F_mapCross___0:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_455;
  goto GC_COLLECT;
}
  GC_RET_455:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_456;
goto EVAL;
LABEL_456:
switch (res) {
case C_Pair:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = getPTR(L_sp[-2])[3];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Pair);
hp[6] = makePTR(hp+0);
hp[7] = getPTR(L_sp[-1])[3];
atom = makePTR(hp+4);
hp += 8;
L_POP(2);
L_PUSH(atom);
res = C_Pair;
goto EVAL_RET;
}
F_crossPair:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_458;
  goto GC_COLLECT;
}
  GC_RET_458:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_459;
goto EVAL;
LABEL_459:
switch (res) {
case C_Pair:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Pair);
hp[6] = makePTR(hp+0);
hp[7] = getPTR(L_sp[-1])[3];
atom = makePTR(hp+4);
hp += 8;
L_POP(2);
L_PUSH(atom);
res = C_Pair;
goto EVAL_RET;
}
F_subs:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_461;
  goto GC_COLLECT;
}
  GC_RET_461:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_462;
goto EVAL;
LABEL_462:
switch (res) {
case C_Nil:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = makeCTR(C_Nil);
hp[3] = makeCTR(C_Nil);
atom = makePTR(hp+0);
hp += 4;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_subs);
hp[2] = getPTR(L_sp[-1])[3];
hp[3] = makeHDR(3);
hp[4] = makeFUN(&&F_mapCons);
hp[5] = getPTR(L_sp[-1])[2];
hp[6] = makePTR(hp+0);
hp[7] = makeHDR(3);
hp[8] = makeFUN(&&F_append);
hp[9] = makePTR(hp+0);
hp[10] = makePTR(hp+3);
atom = makePTR(hp+7);
hp += 11;
L_POP(2);
L_PUSH(atom);
goto F_append;
}
F_interleave:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_464;
  goto GC_COLLECT;
}
  GC_RET_464:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_465;
goto EVAL;
LABEL_465:
switch (res) {
case C_Nil:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = makeCTR(C_Nil);
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = makePTR(hp+0);
hp[7] = makeCTR(C_Nil);
atom = makePTR(hp+4);
hp += 8;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-1])[3];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = getPTR(L_sp[-2])[2];
hp[7] = makePTR(hp+0);
hp[8] = makeHDR(3);
hp[9] = makeFUN(&&F_interleave);
hp[10] = getPTR(L_sp[-2])[2];
hp[11] = getPTR(L_sp[-1])[3];
hp[12] = makeHDR(3);
hp[13] = makeFUN(&&F_mapCons);
hp[14] = getPTR(L_sp[-1])[2];
hp[15] = makePTR(hp+8);
hp[16] = makeHDR(3);
hp[17] = makeCTR(C_Cons);
hp[18] = makePTR(hp+4);
hp[19] = makePTR(hp+12);
atom = makePTR(hp+16);
hp += 20;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
F_perms:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_471;
  goto GC_COLLECT;
}
  GC_RET_471:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_472;
goto EVAL;
LABEL_472:
switch (res) {
case C_Nil:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = makeCTR(C_Nil);
hp[3] = makeCTR(C_Nil);
atom = makePTR(hp+0);
hp += 4;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_perms);
hp[2] = getPTR(L_sp[-1])[3];
hp[3] = makeHDR(3);
hp[4] = makeFUN(&&F_concatMapIlv);
hp[5] = getPTR(L_sp[-1])[2];
hp[6] = makePTR(hp+0);
atom = makePTR(hp+3);
hp += 7;
L_POP(2);
L_PUSH(atom);
goto F_concatMapIlv;
}
F_choices:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_474;
  goto GC_COLLECT;
}
  GC_RET_474:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_subs);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = makeHDR(2);
hp[4] = makeFUN(&&F_concatMapPerms);
hp[5] = makePTR(hp+0);
atom = makePTR(hp+3);
hp += 6;
L_POP(1);
L_PUSH(atom);
goto F_concatMapPerms;
F_split:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_476;
  goto GC_COLLECT;
}
  GC_RET_476:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_477;
goto EVAL;
LABEL_477:
switch (res) {
case C_Cons:
atom = getPTR(L_sp[-1])[3];
eval_ret_addr = &&LABEL_478;
goto EVAL;
LABEL_478:
switch (res) {
case C_Nil:
L_POP(3);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = makeCTR(C_Nil);
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Pair);
hp[6] = makePTR(hp+0);
hp[7] = getPTR(L_sp[-2])[3];
hp[8] = makeHDR(2);
hp[9] = makeFUN(&&F_split);
hp[10] = getPTR(L_sp[-2])[3];
hp[11] = makeHDR(3);
hp[12] = makeFUN(&&F_mapCross);
hp[13] = getPTR(L_sp[-2])[2];
hp[14] = makePTR(hp+8);
hp[15] = makeHDR(3);
hp[16] = makeCTR(C_Cons);
hp[17] = makePTR(hp+4);
hp[18] = makePTR(hp+11);
atom = makePTR(hp+15);
hp += 19;
L_POP(3);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
}
F_results:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_483;
  goto GC_COLLECT;
}
  GC_RET_483:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_484;
goto EVAL;
LABEL_484:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
atom = getPTR(L_sp[-1])[3];
eval_ret_addr = &&LABEL_485;
goto EVAL;
LABEL_485:
switch (res) {
case C_Nil:
hp[0] = makeHDR(2);
hp[1] = makeCTR(C_Val);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = makeHDR(3);
hp[4] = makeCTR(C_Pair);
hp[5] = makePTR(hp+0);
hp[6] = getPTR(L_sp[-2])[2];
hp[7] = makeHDR(3);
hp[8] = makeCTR(C_Cons);
hp[9] = makePTR(hp+3);
hp[10] = makeCTR(C_Nil);
atom = makePTR(hp+7);
hp += 11;
L_POP(3);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = makeHDR(2);
hp[5] = makeFUN(&&F_split);
hp[6] = makePTR(hp+0);
hp[7] = makeHDR(2);
hp[8] = makeFUN(&&F_concatMapCR);
hp[9] = makePTR(hp+4);
atom = makePTR(hp+7);
hp += 10;
L_POP(3);
L_PUSH(atom);
goto F_concatMapCR;
}
}
F_combinedResults:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_490;
  goto GC_COLLECT;
}
  GC_RET_490:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_491;
goto EVAL;
LABEL_491:
switch (res) {
case C_Pair:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_results);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = makeHDR(2);
hp[4] = makeFUN(&&F_results);
hp[5] = getPTR(L_sp[-1])[3];
hp[6] = makeHDR(3);
hp[7] = makeFUN(&&F_concatProd);
hp[8] = makePTR(hp+0);
hp[9] = makePTR(hp+3);
atom = makePTR(hp+6);
hp += 10;
L_POP(2);
L_PUSH(atom);
goto F_concatProd;
}
F_concatProd:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_494;
  goto GC_COLLECT;
}
  GC_RET_494:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_495;
goto EVAL;
LABEL_495:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_concatMapComb);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_concatProd);
hp[6] = getPTR(L_sp[-1])[3];
hp[7] = getPTR(L_sp[-2])[3];
hp[8] = makeHDR(3);
hp[9] = makeFUN(&&F_append);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(2);
L_PUSH(atom);
goto F_append;
}
F_combine:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_498;
  goto GC_COLLECT;
}
  GC_RET_498:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_499;
goto EVAL;
LABEL_499:
switch (res) {
case C_Pair:
atom = getPTR(L_sp[-2])[3];
getPTR(L_sp[-2])[3] = makeINT(0);
eval_ret_addr = &&LABEL_500;
goto EVAL;
LABEL_500:
switch (res) {
case C_Pair:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = makeCTR(C_Div);
hp[3] = makeCTR(C_Nil);
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = makeCTR(C_Mul);
hp[7] = makePTR(hp+0);
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makeCTR(C_Sub);
hp[11] = makePTR(hp+4);
hp[12] = makeHDR(3);
hp[13] = makeCTR(C_Cons);
hp[14] = makeCTR(C_Add);
hp[15] = makePTR(hp+8);
hp[16] = makeHDR(6);
hp[17] = makeFUN(&&F_concatMapCombi);
hp[18] = getPTR(L_sp[-2])[2];
hp[19] = getPTR(L_sp[-2])[3];
hp[20] = getPTR(L_sp[-1])[2];
hp[21] = getPTR(L_sp[-1])[3];
hp[22] = makePTR(hp+12);
atom = makePTR(hp+16);
hp += 23;
L_POP(3);
L_PUSH(atom);
goto F_concatMapCombi;
}
}
F_combi:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_505;
  goto GC_COLLECT;
}
  GC_RET_505:
hp[0] = makeHDR(4);
hp[1] = makeFUN(&&F_valid);
hp[2] = getPTR(L_sp[-1])[6];
hp[3] = getPTR(L_sp[-1])[3];
hp[4] = getPTR(L_sp[-1])[5];
atom = makePTR(hp+0);
hp += 5;
eval_ret_addr = &&LABEL_506;
goto EVAL;
LABEL_506:
switch (res) {
case C_True:
hp[0] = makeHDR(4);
hp[1] = makeCTR(C_App);
hp[2] = getPTR(L_sp[-2])[6];
hp[3] = getPTR(L_sp[-2])[2];
hp[4] = getPTR(L_sp[-2])[4];
hp[5] = makeHDR(4);
hp[6] = makeFUN(&&F_apply);
hp[7] = getPTR(L_sp[-2])[6];
hp[8] = getPTR(L_sp[-2])[3];
hp[9] = getPTR(L_sp[-2])[5];
hp[10] = makeHDR(3);
hp[11] = makeCTR(C_Pair);
hp[12] = makePTR(hp+0);
hp[13] = makePTR(hp+5);
hp[14] = makeHDR(3);
hp[15] = makeCTR(C_Cons);
hp[16] = makePTR(hp+10);
hp[17] = makeCTR(C_Nil);
atom = makePTR(hp+14);
hp += 18;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
case C_False:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
}
F_solutions:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_510;
  goto GC_COLLECT;
}
  GC_RET_510:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_subs);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = makeHDR(2);
hp[4] = makeFUN(&&F_concatMapPerms);
hp[5] = makePTR(hp+0);
hp[6] = makeHDR(3);
hp[7] = makeFUN(&&F_concatMapSolns);
hp[8] = getPTR(L_sp[-1])[3];
hp[9] = makePTR(hp+3);
atom = makePTR(hp+6);
hp += 10;
L_POP(1);
L_PUSH(atom);
goto F_concatMapSolns;
F_solns:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_513;
  goto GC_COLLECT;
}
  GC_RET_513:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_results);
hp[2] = getPTR(L_sp[-1])[3];
hp[3] = makeHDR(3);
hp[4] = makeFUN(&&F_preImage);
hp[5] = getPTR(L_sp[-1])[2];
hp[6] = makePTR(hp+0);
atom = makePTR(hp+3);
hp += 7;
L_POP(1);
L_PUSH(atom);
goto F_preImage;
F_preImage:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_515;
  goto GC_COLLECT;
}
  GC_RET_515:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_516;
goto EVAL;
LABEL_516:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_517;
goto EVAL;
LABEL_517:
switch (res) {
case C_Pair:
atom = getPTR(L_sp[-1])[3];
eval_ret_addr = &&LABEL_518;
goto EVAL;
LABEL_518:
atom = getPTR(L_sp[-4])[2];
eval_ret_addr = &&LABEL_519;
goto EVAL;
LABEL_519:
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(1);
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_preImage);
hp[2] = getPTR(L_sp[-4])[2];
hp[3] = getPTR(L_sp[-3])[3];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = getPTR(L_sp[-2])[2];
hp[7] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 8;
L_POP(4);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
case C_False:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_preImage);
hp[2] = getPTR(L_sp[-4])[2];
hp[3] = getPTR(L_sp[-3])[3];
atom = makePTR(hp+0);
hp += 4;
L_POP(4);
L_PUSH(atom);
goto F_preImage;
}
}
}
F_not:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_521;
  goto GC_COLLECT;
}
  GC_RET_521:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_522;
goto EVAL;
LABEL_522:
switch (res) {
case C_True:
L_POP(2);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
case C_False:
L_POP(2);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
}
F_div:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_523;
  goto GC_COLLECT;
}
  GC_RET_523:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_divMod);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-1])[3];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_524;
goto EVAL;
LABEL_524:
switch (res) {
case C_Pair:
atom = getPTR(L_sp[-1])[2];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
}
F_mod:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_525;
  goto GC_COLLECT;
}
  GC_RET_525:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_divMod);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-1])[3];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_526;
goto EVAL;
LABEL_526:
switch (res) {
case C_Pair:
atom = getPTR(L_sp[-1])[3];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
}
F_divMod:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_527;
  goto GC_COLLECT;
}
  GC_RET_527:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&P_ADD);
hp[2] = getPTR(L_sp[-1])[3];
hp[3] = getPTR(L_sp[-1])[3];
hp[4] = makeHDR(4);
hp[5] = makeFUN(&&F_divMod___0);
hp[6] = makePTR(hp+0);
hp[7] = getPTR(L_sp[-1])[2];
hp[8] = getPTR(L_sp[-1])[3];
atom = makePTR(hp+4);
hp += 9;
L_POP(1);
L_PUSH(atom);
goto F_divMod___0;
F_divMod___0:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_528;
  goto GC_COLLECT;
}
  GC_RET_528:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_529;
goto EVAL;
LABEL_529:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_530;
goto EVAL;
LABEL_530:
L_POP(1);
res = getINT(L_top) <= res ? C_True : C_False;
L_POP(1);
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_divMod);
hp[2] = getPTR(L_sp[-2])[3];
hp[3] = getPTR(L_sp[-2])[2];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_531;
goto EVAL;
LABEL_531:
switch (res) {
case C_Pair:
atom = getPTR(L_sp[-3])[4];
eval_ret_addr = &&LABEL_532;
goto EVAL;
LABEL_532:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_533;
goto EVAL;
LABEL_533:
L_POP(1);
res = getINT(L_top) <= res ? C_True : C_False;
L_POP(1);
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&P_ADD);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-2])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&P_ADD);
hp[6] = makeINT(1);
hp[7] = makePTR(hp+0);
hp[8] = makeHDR(3);
hp[9] = makeFUN(&&P_SUB);
hp[10] = getPTR(L_sp[-2])[3];
hp[11] = getPTR(L_sp[-4])[4];
hp[12] = makeHDR(3);
hp[13] = makeCTR(C_Pair);
hp[14] = makePTR(hp+4);
hp[15] = makePTR(hp+8);
atom = makePTR(hp+12);
hp += 16;
L_POP(4);
L_PUSH(atom);
res = C_Pair;
goto EVAL_RET;
case C_False:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&P_ADD);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-2])[2];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Pair);
hp[6] = makePTR(hp+0);
hp[7] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+4);
hp += 8;
L_POP(4);
L_PUSH(atom);
res = C_Pair;
goto EVAL_RET;
}
}
case C_False:
atom = getPTR(L_sp[-2])[4];
eval_ret_addr = &&LABEL_538;
goto EVAL;
LABEL_538:
atom = getPTR(L_sp[-3])[3];
eval_ret_addr = &&LABEL_539;
goto EVAL;
LABEL_539:
L_POP(1);
res = getINT(L_top) <= res ? C_True : C_False;
L_POP(1);
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&P_SUB);
hp[2] = getPTR(L_sp[-3])[3];
hp[3] = getPTR(L_sp[-3])[4];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Pair);
hp[6] = makeINT(1);
hp[7] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 8;
L_POP(3);
L_PUSH(atom);
res = C_Pair;
goto EVAL_RET;
case C_False:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Pair);
hp[2] = makeINT(0);
hp[3] = getPTR(L_sp[-3])[3];
atom = makePTR(hp+0);
hp += 4;
L_POP(3);
L_PUSH(atom);
res = C_Pair;
goto EVAL_RET;
}
}
F_mul:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_541;
  goto GC_COLLECT;
}
  GC_RET_541:
atom = getPTR(L_sp[-1])[3];
eval_ret_addr = &&LABEL_542;
goto EVAL;
LABEL_542:
L_PUSH(makeINT(1));
res = 1;
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(1);
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
atom = getPTR(L_sp[-2])[2];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
case C_False:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_divMod);
hp[2] = getPTR(L_sp[-2])[3];
hp[3] = makeINT(2);
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_543;
goto EVAL;
LABEL_543:
switch (res) {
case C_Pair:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&P_ADD);
hp[2] = getPTR(L_sp[-3])[2];
hp[3] = getPTR(L_sp[-3])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_mul);
hp[6] = makePTR(hp+0);
hp[7] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+4);
hp += 8;
eval_ret_addr = &&LABEL_545;
goto EVAL;
LABEL_545:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_mul___0);
hp[2] = getPTR(L_sp[-2])[3];
hp[3] = getPTR(L_sp[-4])[2];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_546;
goto EVAL;
LABEL_546:
L_POP(1);
res = getINT(L_top) + res;
L_POP(4);
L_PUSH(makeINT(res));
goto EVAL_RET;
}
}
F_mul___0:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_547;
  goto GC_COLLECT;
}
  GC_RET_547:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_548;
goto EVAL;
LABEL_548:
L_PUSH(makeINT(0));
res = 0;
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(1);
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
L_POP(2);
L_PUSH(makeINT(0));
res = 0;
goto EVAL_RET;
case C_False:
atom = getPTR(L_sp[-2])[3];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
}
F_null:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_549;
  goto GC_COLLECT;
}
  GC_RET_549:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_550;
goto EVAL;
LABEL_550:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
case C_Cons:
L_POP(2);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
}
F_length:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_551;
  goto GC_COLLECT;
}
  GC_RET_551:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_552;
goto EVAL;
LABEL_552:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeINT(0));
res = 0;
goto EVAL_RET;
case C_Cons:
L_PUSH(makeINT(1));
res = 1;
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_length);
hp[2] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+0);
hp += 3;
eval_ret_addr = &&LABEL_553;
goto EVAL;
LABEL_553:
L_POP(1);
res = getINT(L_top) + res;
L_POP(3);
L_PUSH(makeINT(res));
goto EVAL_RET;
}
F_append:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_554;
  goto GC_COLLECT;
}
  GC_RET_554:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_555;
goto EVAL;
LABEL_555:
switch (res) {
case C_Nil:
atom = getPTR(L_sp[-2])[3];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_append);
hp[2] = getPTR(L_sp[-1])[3];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = getPTR(L_sp[-1])[2];
hp[7] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 8;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
P_ADD:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_557;
  goto GC_COLLECT;
}
  GC_RET_557:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_558;
goto EVAL;
LABEL_558:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_559;
goto EVAL;
LABEL_559:
L_POP(1);
res = getINT(L_top) + res;
L_POP(2);
L_PUSH(makeINT(res));
goto EVAL_RET;
P_SUB:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_560;
  goto GC_COLLECT;
}
  GC_RET_560:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_561;
goto EVAL;
LABEL_561:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_562;
goto EVAL;
LABEL_562:
L_POP(1);
res = getINT(L_top) - res;
L_POP(2);
L_PUSH(makeINT(res));
goto EVAL_RET;
P_EQ:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_563;
  goto GC_COLLECT;
}
  GC_RET_563:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_564;
goto EVAL;
LABEL_564:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_565;
goto EVAL;
LABEL_565:
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(2);
L_PUSH(makeCTR(res));
goto EVAL_RET;
P_NEQ:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_566;
  goto GC_COLLECT;
}
  GC_RET_566:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_567;
goto EVAL;
LABEL_567:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_568;
goto EVAL;
LABEL_568:
L_POP(1);
res = getINT(L_top) != res ? C_True : C_False;
L_POP(2);
L_PUSH(makeCTR(res));
goto EVAL_RET;
P_LEQ:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_569;
  goto GC_COLLECT;
}
  GC_RET_569:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_570;
goto EVAL;
LABEL_570:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_571;
goto EVAL;
LABEL_571:
L_POP(1);
res = getINT(L_top) <= res ? C_True : C_False;
L_POP(2);
L_PUSH(makeCTR(res));
goto EVAL_RET;
GC_COPY:
if (from[0] == VISITED) {
  atom = from[1];
  goto *gc_copy_ret;
}
if (isPTR(from[1])) { from = getPTR(from[1]); goto GC_COPY; }
if (size(from[0]) == 1) { atom = from[1]; }
else {
  n = size(from[0]) + 1;
  //printf("Copy (%i);\n", n-1);
  atom = makePTR(free);
  for (i = 0; i < n; i++)
    { *free = from[i]; free++; }
  from[0] = VISITED;
  from[1] = atom;
}
goto *gc_copy_ret;
GC_COLLECT:
//printf("GC invoked (%i);\n", hp - fromSpace);
scan = toSpace;
free = toSpace;
for (p = L_base; p < L_sp; p++) {
  if (isPTR(*p)) {
    from = getPTR(*p);
    gc_copy_ret = &&GC_COPY_RET1; goto GC_COPY; GC_COPY_RET1:
    *p = atom;
  }
}
while (scan < free) {
  m = size(*scan); scan++;
  //printf("Scan (%i);\n", m);
  for (j = 0; j < m; j++) {
    if (isPTR(*scan)) {
      from = getPTR(*scan);
      gc_copy_ret = &&GC_COPY_RET2; goto GC_COPY; GC_COPY_RET2:
      *scan = atom;
    }
    scan++;
  }
}
for (frame = R_base; frame > R_sp; frame--) {
  p = frame->current;
  frame->current = 0;
  while (p && p[0] != VISITED && isPTR(p[1])) p = getPTR(p[1]);
  if (p && p[0] == VISITED) {
    if (isPTR(p[1])) frame->current = getPTR(p[1]);
  }
}
hp = free;
p = fromSpace; fromSpace = toSpace; toSpace = p;
p = fromSpaceEnd; fromSpaceEnd = toSpaceEnd; toSpaceEnd = p;
heapEnd = fromSpaceEnd;
L_top = L_sp[-1];
R_top_returnAddress = R_sp[1].returnAddress;
R_top_current = R_sp[1].current;
//printf("GC finished (%i);\n", hp - fromSpace);
goto *gc_ret;
}



