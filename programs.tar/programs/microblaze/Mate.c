#include <stdio.h>
#include <stdlib.h>
typedef unsigned int Atom;
#define isPTR(a)   (((a)&3) == 0)
#define isCTR(a)   (((a)&3) == 1)
#define isINT(a)   (((a)&3) == 2)
#define isFUN(a)   (((a)&3) == 3)
#define getPTR(a)  ((Atom*) (a))
#define getCTR(a)  ((a) >> 2)
#define getINT(a)  ((int) (((int) (a)) >> 2))
#define getFUN(a)  ((void*) (((unsigned int) (a)) & (~3)))
#define makePTR(x) ((Atom) (x))
#define makeCTR(x) ((Atom) (((x) << 2) | 1))
#define makeINT(x) ((Atom) ((((unsigned int) (x)) << 2) | 2))
#define makeFUN(x) ((Atom) (((unsigned int) (x)) | 3))
#define HEAP_SIZE 22000
#define STACK_SIZE 3000
typedef struct {
  Atom* current;
  void* returnAddress;
} Frame;
#define L_POP(n) L_sp-=n; L_top = L_sp[-1];
#define L_PUSH(a) L_top = a; L_sp[0] = L_top; L_sp++;
#define R_POP \
  R_sp++;\
  R_top_returnAddress = R_sp[1].returnAddress;\
  R_top_current = R_sp[1].current;
#define R_PUSH(ra, cur) \
  R_top_returnAddress = R_sp[0].returnAddress = ra; \
  R_top_current = R_sp[0].current = cur; \
  R_sp--;
#define makeHDR(x)        ((x) << 1)
#define VISITED           1
#define size(x)           ((x) >> 1)
#define C_False 0
#define C_True 1
#define C_Pair 0
#define C_MoveInFull 0
#define C_Just 0
#define C_Nothing 1
#define C_Cons 0
#define C_Nil 1
#define C_Bishop 0
#define C_King 1
#define C_Knight 2
#define C_Pawn 3
#define C_Queen 4
#define C_Rook 5
#define C_Board 0
#define C_Black 0
#define C_White 1
#define C_Move 0
#define C_Minus 0
#define C_Plus 1
#define C_Solution 0


int main() {
register Atom* L_sp;
Atom* L_base;
register Atom L_top;
register Frame* R_sp;
Frame* R_base;
register void* R_top_returnAddress;
register Atom* R_top_current;
register Atom* hp;
register Atom* heapEnd;
register Atom atom;
register Atom* app;
register int res;
Atom* fromSpace;
Atom* toSpace;
Atom* fromSpaceEnd;
Atom* toSpaceEnd;
Atom* scan;
Atom* free;
Atom* p;
Atom* from;
Frame* frame;
void* gc_copy_ret;
void* gc_ret;
void* eval_ret_addr;
int i;
int j;
int n;
int m;
L_base = L_sp = malloc(sizeof(Atom) * STACK_SIZE);
R_base = R_sp = (Frame*) &L_sp[STACK_SIZE-1];
fromSpace = hp = malloc(sizeof(Atom) * HEAP_SIZE);
heapEnd = fromSpaceEnd = &fromSpace[HEAP_SIZE-1000];
toSpace = malloc(sizeof(Atom) * HEAP_SIZE);
toSpaceEnd = &toSpace[HEAP_SIZE-1000];
print("S");
atom = makePTR(hp);
*hp++ = makeHDR(1); *hp++ =  makeFUN(&&F_main);
L_PUSH(atom);
eval_ret_addr = &&LABEL_1038;
goto EVAL;
LABEL_1038:
putnum(getINT(L_top));
return 0;
EVAL:
if (isPTR(atom)) {
  app = getPTR(atom);
  EVAL_APP:
  if (isFUN(app[1])) {
    L_PUSH(makePTR(app));
    R_PUSH(eval_ret_addr, app);
    goto *getFUN(app[1]);
    EVAL_RET:
    if (R_top_current) {
      R_top_current[0] = makeHDR(1);
      R_top_current[1] = L_top;
    }
    eval_ret_addr = R_top_returnAddress;
    R_POP;
    goto *eval_ret_addr;
  }
  else if (isCTR(app[1])) {
    L_PUSH(makePTR(app)); res = getCTR(app[1]);
    goto *eval_ret_addr;
  }
  else if (isPTR(app[1])) {
    app = getPTR(app[1]);
    goto EVAL_APP;
  }
  else {
    L_PUSH(app[1]); res = getINT(app[1]);
    goto *eval_ret_addr;
  }
} else {
  L_PUSH(atom);
  res = getINT(atom);
  goto *eval_ret_addr;
}
TAIL_EVAL:
if (isPTR(atom)) {
  app = getPTR(atom);
  TAIL_EVAL_APP:
  if (isFUN(app[1])) {
    L_PUSH(makePTR(app));
    if (R_top_current) {
      R_top_current[0] = makeHDR(1);
      R_top_current[1] = makePTR(app);
    }
    R_top_current = R_sp[1].current = app;
    goto *getFUN(app[1]);
  }
  else if (isPTR(app[1])) {
    app = getPTR(app[1]);
    goto TAIL_EVAL_APP;
  }
  else if (isINT(app[1])) {
    L_PUSH(app[1]); res = getINT(app[1]);
    goto EVAL_RET;
  }
  else {
    L_PUSH(makePTR(app)); res = getCTR(app[1]);
    goto EVAL_RET;
  }
} else {
  L_PUSH(atom);
  res = getINT(atom);
  goto EVAL_RET;
}
F_main:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1039;
  goto GC_COLLECT;
}
  GC_RET_1039:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Pair);
hp[2] = makeINT(7);
hp[3] = makeINT(8);
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Pair);
hp[6] = makeCTR(C_Knight);
hp[7] = makePTR(hp+0);
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Pair);
hp[10] = makeINT(5);
hp[11] = makeINT(7);
hp[12] = makeHDR(3);
hp[13] = makeCTR(C_Pair);
hp[14] = makeCTR(C_Rook);
hp[15] = makePTR(hp+8);
hp[16] = makeHDR(3);
hp[17] = makeCTR(C_Pair);
hp[18] = makeINT(8);
hp[19] = makeINT(7);
hp[20] = makeHDR(3);
hp[21] = makeCTR(C_Pair);
hp[22] = makeCTR(C_King);
hp[23] = makePTR(hp+16);
hp[24] = makeHDR(3);
hp[25] = makeCTR(C_Pair);
hp[26] = makeINT(4);
hp[27] = makeINT(5);
hp[28] = makeHDR(3);
hp[29] = makeCTR(C_Pair);
hp[30] = makeCTR(C_Bishop);
hp[31] = makePTR(hp+24);
hp[32] = makeHDR(3);
hp[33] = makeCTR(C_Pair);
hp[34] = makeINT(8);
hp[35] = makeINT(4);
hp[36] = makeHDR(3);
hp[37] = makeCTR(C_Pair);
hp[38] = makeCTR(C_Pawn);
hp[39] = makePTR(hp+32);
hp[40] = makeHDR(3);
hp[41] = makeCTR(C_Pair);
hp[42] = makeINT(7);
hp[43] = makeINT(3);
hp[44] = makeHDR(3);
hp[45] = makeCTR(C_Pair);
hp[46] = makeCTR(C_Pawn);
hp[47] = makePTR(hp+40);
hp[48] = makeHDR(3);
hp[49] = makeCTR(C_Pair);
hp[50] = makeINT(5);
hp[51] = makeINT(2);
hp[52] = makeHDR(3);
hp[53] = makeCTR(C_Pair);
hp[54] = makeCTR(C_Pawn);
hp[55] = makePTR(hp+48);
hp[56] = makeHDR(3);
hp[57] = makeCTR(C_Pair);
hp[58] = makeINT(6);
hp[59] = makeINT(2);
hp[60] = makeHDR(3);
hp[61] = makeCTR(C_Pair);
hp[62] = makeCTR(C_Pawn);
hp[63] = makePTR(hp+56);
hp[64] = makeHDR(3);
hp[65] = makeCTR(C_Pair);
hp[66] = makeINT(5);
hp[67] = makeINT(1);
hp[68] = makeHDR(3);
hp[69] = makeCTR(C_Pair);
hp[70] = makeCTR(C_Queen);
hp[71] = makePTR(hp+64);
hp[72] = makeHDR(3);
hp[73] = makeCTR(C_Cons);
hp[74] = makePTR(hp+68);
hp[75] = makeCTR(C_Nil);
hp[76] = makeHDR(3);
hp[77] = makeCTR(C_Cons);
hp[78] = makePTR(hp+60);
hp[79] = makePTR(hp+72);
hp[80] = makeHDR(3);
hp[81] = makeCTR(C_Cons);
hp[82] = makePTR(hp+52);
hp[83] = makePTR(hp+76);
hp[84] = makeHDR(3);
hp[85] = makeCTR(C_Cons);
hp[86] = makePTR(hp+44);
hp[87] = makePTR(hp+80);
hp[88] = makeHDR(3);
hp[89] = makeCTR(C_Cons);
hp[90] = makePTR(hp+36);
hp[91] = makePTR(hp+84);
hp[92] = makeHDR(3);
hp[93] = makeCTR(C_Cons);
hp[94] = makePTR(hp+28);
hp[95] = makePTR(hp+88);
hp[96] = makeHDR(3);
hp[97] = makeCTR(C_Cons);
hp[98] = makePTR(hp+20);
hp[99] = makePTR(hp+92);
hp[100] = makeHDR(3);
hp[101] = makeCTR(C_Cons);
hp[102] = makePTR(hp+12);
hp[103] = makePTR(hp+96);
hp[104] = makeHDR(3);
hp[105] = makeCTR(C_Cons);
hp[106] = makePTR(hp+4);
hp[107] = makePTR(hp+100);
hp[108] = makeHDR(3);
hp[109] = makeCTR(C_Pair);
hp[110] = makeINT(2);
hp[111] = makeINT(8);
hp[112] = makeHDR(3);
hp[113] = makeCTR(C_Pair);
hp[114] = makeCTR(C_Knight);
hp[115] = makePTR(hp+108);
hp[116] = makeHDR(3);
hp[117] = makeCTR(C_Pair);
hp[118] = makeINT(7);
hp[119] = makeINT(7);
hp[120] = makeHDR(3);
hp[121] = makeCTR(C_Pair);
hp[122] = makeCTR(C_Pawn);
hp[123] = makePTR(hp+116);
hp[124] = makeHDR(3);
hp[125] = makeCTR(C_Pair);
hp[126] = makeINT(4);
hp[127] = makeINT(6);
hp[128] = makeHDR(3);
hp[129] = makeCTR(C_Pair);
hp[130] = makeCTR(C_Pawn);
hp[131] = makePTR(hp+124);
hp[132] = makeHDR(3);
hp[133] = makeCTR(C_Pair);
hp[134] = makeINT(3);
hp[135] = makeINT(5);
hp[136] = makeHDR(3);
hp[137] = makeCTR(C_Pair);
hp[138] = makeCTR(C_Pawn);
hp[139] = makePTR(hp+132);
hp[140] = makeHDR(3);
hp[141] = makeCTR(C_Pair);
hp[142] = makeINT(6);
hp[143] = makeINT(5);
hp[144] = makeHDR(3);
hp[145] = makeCTR(C_Pair);
hp[146] = makeCTR(C_King);
hp[147] = makePTR(hp+140);
hp[148] = makeHDR(3);
hp[149] = makeCTR(C_Pair);
hp[150] = makeINT(8);
hp[151] = makeINT(5);
hp[152] = makeHDR(3);
hp[153] = makeCTR(C_Pair);
hp[154] = makeCTR(C_Pawn);
hp[155] = makePTR(hp+148);
hp[156] = makeHDR(3);
hp[157] = makeCTR(C_Pair);
hp[158] = makeINT(4);
hp[159] = makeINT(4);
hp[160] = makeHDR(3);
hp[161] = makeCTR(C_Pair);
hp[162] = makeCTR(C_Pawn);
hp[163] = makePTR(hp+156);
hp[164] = makeHDR(3);
hp[165] = makeCTR(C_Pair);
hp[166] = makeINT(2);
hp[167] = makeINT(3);
hp[168] = makeHDR(3);
hp[169] = makeCTR(C_Pair);
hp[170] = makeCTR(C_Pawn);
hp[171] = makePTR(hp+164);
hp[172] = makeHDR(3);
hp[173] = makeCTR(C_Pair);
hp[174] = makeINT(5);
hp[175] = makeINT(3);
hp[176] = makeHDR(3);
hp[177] = makeCTR(C_Pair);
hp[178] = makeCTR(C_Pawn);
hp[179] = makePTR(hp+172);
hp[180] = makeHDR(3);
hp[181] = makeCTR(C_Pair);
hp[182] = makeINT(7);
hp[183] = makeINT(2);
hp[184] = makeHDR(3);
hp[185] = makeCTR(C_Pair);
hp[186] = makeCTR(C_Pawn);
hp[187] = makePTR(hp+180);
hp[188] = makeHDR(3);
hp[189] = makeCTR(C_Pair);
hp[190] = makeINT(1);
hp[191] = makeINT(1);
hp[192] = makeHDR(3);
hp[193] = makeCTR(C_Pair);
hp[194] = makeCTR(C_Queen);
hp[195] = makePTR(hp+188);
hp[196] = makeHDR(3);
hp[197] = makeCTR(C_Pair);
hp[198] = makeINT(2);
hp[199] = makeINT(1);
hp[200] = makeHDR(3);
hp[201] = makeCTR(C_Pair);
hp[202] = makeCTR(C_Knight);
hp[203] = makePTR(hp+196);
hp[204] = makeHDR(3);
hp[205] = makeCTR(C_Pair);
hp[206] = makeINT(8);
hp[207] = makeINT(1);
hp[208] = makeHDR(3);
hp[209] = makeCTR(C_Pair);
hp[210] = makeCTR(C_Bishop);
hp[211] = makePTR(hp+204);
hp[212] = makeHDR(3);
hp[213] = makeCTR(C_Cons);
hp[214] = makePTR(hp+208);
hp[215] = makeCTR(C_Nil);
hp[216] = makeHDR(3);
hp[217] = makeCTR(C_Cons);
hp[218] = makePTR(hp+200);
hp[219] = makePTR(hp+212);
hp[220] = makeHDR(3);
hp[221] = makeCTR(C_Cons);
hp[222] = makePTR(hp+192);
hp[223] = makePTR(hp+216);
hp[224] = makeHDR(3);
hp[225] = makeCTR(C_Cons);
hp[226] = makePTR(hp+184);
hp[227] = makePTR(hp+220);
hp[228] = makeHDR(3);
hp[229] = makeCTR(C_Cons);
hp[230] = makePTR(hp+176);
hp[231] = makePTR(hp+224);
hp[232] = makeHDR(3);
hp[233] = makeCTR(C_Cons);
hp[234] = makePTR(hp+168);
hp[235] = makePTR(hp+228);
hp[236] = makeHDR(3);
hp[237] = makeCTR(C_Cons);
hp[238] = makePTR(hp+160);
hp[239] = makePTR(hp+232);
hp[240] = makeHDR(3);
hp[241] = makeCTR(C_Cons);
hp[242] = makePTR(hp+152);
hp[243] = makePTR(hp+236);
hp[244] = makeHDR(3);
hp[245] = makeCTR(C_Cons);
hp[246] = makePTR(hp+144);
hp[247] = makePTR(hp+240);
hp[248] = makeHDR(3);
hp[249] = makeCTR(C_Cons);
hp[250] = makePTR(hp+136);
hp[251] = makePTR(hp+244);
hp[252] = makeHDR(3);
hp[253] = makeCTR(C_Cons);
hp[254] = makePTR(hp+128);
hp[255] = makePTR(hp+248);
hp[256] = makeHDR(3);
hp[257] = makeCTR(C_Cons);
hp[258] = makePTR(hp+120);
hp[259] = makePTR(hp+252);
hp[260] = makeHDR(3);
hp[261] = makeCTR(C_Cons);
hp[262] = makePTR(hp+112);
hp[263] = makePTR(hp+256);
hp[264] = makeHDR(3);
hp[265] = makeCTR(C_Board);
hp[266] = makePTR(hp+104);
hp[267] = makePTR(hp+260);
hp[268] = makeHDR(3);
hp[269] = makeCTR(C_Pair);
hp[270] = makeCTR(C_White);
hp[271] = makeINT(3);
hp[272] = makeHDR(3);
hp[273] = makeFUN(&&F_main___0);
hp[274] = makePTR(hp+268);
hp[275] = makePTR(hp+264);
atom = makePTR(hp+272);
hp += 276;
L_POP(1);
L_PUSH(atom);
goto F_main___0;
F_main___0:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1106;
  goto GC_COLLECT;
}
  GC_RET_1106:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_1107;
goto EVAL;
LABEL_1107:
switch (res) {
case C_Pair:
hp[0] = makeHDR(4);
hp[1] = makeFUN(&&F_solve);
hp[2] = getPTR(L_sp[-2])[3];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = getPTR(L_sp[-1])[3];
atom = makePTR(hp+0);
hp += 5;
L_POP(2);
L_PUSH(atom);
goto F_solve;
}
F_solveProblem:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1108;
  goto GC_COLLECT;
}
  GC_RET_1108:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_1109;
goto EVAL;
LABEL_1109:
switch (res) {
case C_Pair:
atom = getPTR(L_sp[-1])[3];
eval_ret_addr = &&LABEL_1110;
goto EVAL;
LABEL_1110:
switch (res) {
case C_Pair:
hp[0] = makeHDR(4);
hp[1] = makeFUN(&&F_solve);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = getPTR(L_sp[-1])[3];
atom = makePTR(hp+0);
hp += 5;
L_POP(3);
L_PUSH(atom);
goto F_solve;
}
}
F_moveInFull:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1111;
  goto GC_COLLECT;
}
  GC_RET_1111:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_1112;
goto EVAL;
LABEL_1112:
switch (res) {
case C_MoveInFull:
hp[0] = makeHDR(4);
hp[1] = makeCTR(C_MoveInFull);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-1])[3];
hp[4] = getPTR(L_sp[-1])[4];
atom = makePTR(hp+0);
hp += 5;
L_POP(2);
L_PUSH(atom);
res = C_MoveInFull;
goto EVAL_RET;
}
F_min:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1113;
  goto GC_COLLECT;
}
  GC_RET_1113:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_1114;
goto EVAL;
LABEL_1114:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_1115;
goto EVAL;
LABEL_1115:
L_POP(1);
res = getINT(L_top) <= res ? C_True : C_False;
L_POP(1);
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
atom = getPTR(L_sp[-2])[2];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
case C_False:
atom = getPTR(L_sp[-2])[3];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
}
F_max:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1116;
  goto GC_COLLECT;
}
  GC_RET_1116:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_1117;
goto EVAL;
LABEL_1117:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_1118;
goto EVAL;
LABEL_1118:
L_POP(1);
res = getINT(L_top) <= res ? C_True : C_False;
L_POP(1);
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
atom = getPTR(L_sp[-2])[3];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
case C_False:
atom = getPTR(L_sp[-2])[2];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
}
F_abs:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1119;
  goto GC_COLLECT;
}
  GC_RET_1119:
L_PUSH(makeINT(0));
res = 0;
atom = getPTR(L_sp[-2])[2];
eval_ret_addr = &&LABEL_1120;
goto EVAL;
LABEL_1120:
L_POP(1);
res = getINT(L_top) <= res ? C_True : C_False;
L_POP(1);
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
atom = getPTR(L_sp[-2])[2];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
case C_False:
L_PUSH(makeINT(0));
res = 0;
atom = getPTR(L_sp[-3])[2];
eval_ret_addr = &&LABEL_1121;
goto EVAL;
LABEL_1121:
L_POP(1);
res = getINT(L_top) - res;
L_POP(3);
L_PUSH(makeINT(res));
goto EVAL_RET;
}
F_no:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1122;
  goto GC_COLLECT;
}
  GC_RET_1122:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_1123;
goto EVAL;
LABEL_1123:
switch (res) {
case C_Nothing:
L_POP(2);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
case C_Just:
L_POP(2);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
}
F_maybeId:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1124;
  goto GC_COLLECT;
}
  GC_RET_1124:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_1125;
goto EVAL;
LABEL_1125:
switch (res) {
case C_Nothing:
atom = getPTR(L_sp[-2])[2];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
case C_Just:
atom = getPTR(L_sp[-1])[2];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
}
F_maybeConst:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1126;
  goto GC_COLLECT;
}
  GC_RET_1126:
atom = getPTR(L_sp[-1])[4];
getPTR(L_sp[-1])[4] = makeINT(0);
eval_ret_addr = &&LABEL_1127;
goto EVAL;
LABEL_1127:
switch (res) {
case C_Nothing:
atom = getPTR(L_sp[-2])[2];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
case C_Just:
atom = getPTR(L_sp[-2])[3];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
}
F_con:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1128;
  goto GC_COLLECT;
}
  GC_RET_1128:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_1129;
goto EVAL;
LABEL_1129:
switch (res) {
case C_True:
atom = getPTR(L_sp[-2])[3];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
case C_False:
L_POP(2);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
}
F_dis:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1130;
  goto GC_COLLECT;
}
  GC_RET_1130:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_1131;
goto EVAL;
LABEL_1131:
switch (res) {
case C_True:
L_POP(2);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
case C_False:
atom = getPTR(L_sp[-2])[3];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
}
F_fst:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1132;
  goto GC_COLLECT;
}
  GC_RET_1132:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_1133;
goto EVAL;
LABEL_1133:
switch (res) {
case C_Pair:
atom = getPTR(L_sp[-1])[2];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
}
F_snd:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1134;
  goto GC_COLLECT;
}
  GC_RET_1134:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_1135;
goto EVAL;
LABEL_1135:
switch (res) {
case C_Pair:
atom = getPTR(L_sp[-1])[3];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
}
F_null:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1136;
  goto GC_COLLECT;
}
  GC_RET_1136:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_1137;
goto EVAL;
LABEL_1137:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
case C_Cons:
L_POP(2);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
}
F_append:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1138;
  goto GC_COLLECT;
}
  GC_RET_1138:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_1139;
goto EVAL;
LABEL_1139:
switch (res) {
case C_Nil:
atom = getPTR(L_sp[-2])[3];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_append);
hp[2] = getPTR(L_sp[-1])[3];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = getPTR(L_sp[-1])[2];
hp[7] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 8;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
F_elemAt:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1141;
  goto GC_COLLECT;
}
  GC_RET_1141:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_1142;
goto EVAL;
LABEL_1142:
switch (res) {
case C_Cons:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_1143;
goto EVAL;
LABEL_1143:
L_PUSH(makeINT(0));
res = 0;
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(1);
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
atom = getPTR(L_sp[-2])[2];
L_POP(3);
goto TAIL_EVAL;
goto EVAL_RET;
case C_False:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&P_SUB);
hp[2] = getPTR(L_sp[-3])[3];
hp[3] = makeINT(1);
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_elemAt);
hp[6] = getPTR(L_sp[-2])[3];
hp[7] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 8;
L_POP(3);
L_PUSH(atom);
goto F_elemAt;
}
}
F_anyKICF:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1145;
  goto GC_COLLECT;
}
  GC_RET_1145:
atom = getPTR(L_sp[-1])[4];
getPTR(L_sp[-1])[4] = makeINT(0);
eval_ret_addr = &&LABEL_1146;
goto EVAL;
LABEL_1146:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(4);
hp[1] = makeFUN(&&F_kingInCheckFrom);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+0);
hp += 5;
eval_ret_addr = &&LABEL_1147;
goto EVAL;
LABEL_1147:
switch (res) {
case C_True:
L_POP(3);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
case C_False:
hp[0] = makeHDR(4);
hp[1] = makeFUN(&&F_anyKICF);
hp[2] = getPTR(L_sp[-3])[2];
hp[3] = getPTR(L_sp[-3])[3];
hp[4] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+0);
hp += 5;
L_POP(3);
L_PUSH(atom);
goto F_anyKICF;
}
}
F_sum:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1148;
  goto GC_COLLECT;
}
  GC_RET_1148:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_sumAcc);
hp[2] = makeINT(0);
hp[3] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+0);
hp += 4;
L_POP(1);
L_PUSH(atom);
goto F_sumAcc;
F_sumAcc:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1149;
  goto GC_COLLECT;
}
  GC_RET_1149:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_1150;
goto EVAL;
LABEL_1150:
switch (res) {
case C_Nil:
atom = getPTR(L_sp[-2])[2];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&P_ADD);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-2])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_sumAcc);
hp[6] = makePTR(hp+0);
hp[7] = getPTR(L_sp[-1])[3];
atom = makePTR(hp+4);
hp += 8;
L_POP(2);
L_PUSH(atom);
goto F_sumAcc;
}
F_unzip:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1152;
  goto GC_COLLECT;
}
  GC_RET_1152:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_1153;
goto EVAL;
LABEL_1153:
switch (res) {
case C_Nil:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Pair);
hp[2] = makeCTR(C_Nil);
hp[3] = makeCTR(C_Nil);
atom = makePTR(hp+0);
hp += 4;
L_POP(2);
L_PUSH(atom);
res = C_Pair;
goto EVAL_RET;
case C_Cons:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_1154;
goto EVAL;
LABEL_1154:
switch (res) {
case C_Pair:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_unzip);
hp[2] = getPTR(L_sp[-2])[3];
hp[3] = makeHDR(2);
hp[4] = makeFUN(&&F_unzip___0);
hp[5] = makePTR(hp+0);
hp[6] = makeHDR(3);
hp[7] = makeCTR(C_Cons);
hp[8] = getPTR(L_sp[-1])[2];
hp[9] = makePTR(hp+3);
hp[10] = makeHDR(2);
hp[11] = makeFUN(&&F_unzip___1);
hp[12] = makePTR(hp+0);
hp[13] = makeHDR(3);
hp[14] = makeCTR(C_Cons);
hp[15] = getPTR(L_sp[-1])[3];
hp[16] = makePTR(hp+10);
hp[17] = makeHDR(3);
hp[18] = makeCTR(C_Pair);
hp[19] = makePTR(hp+6);
hp[20] = makePTR(hp+13);
atom = makePTR(hp+17);
hp += 21;
L_POP(3);
L_PUSH(atom);
res = C_Pair;
goto EVAL_RET;
}
}
F_unzip___0:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1159;
  goto GC_COLLECT;
}
  GC_RET_1159:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_1160;
goto EVAL;
LABEL_1160:
switch (res) {
case C_Pair:
atom = getPTR(L_sp[-1])[2];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
}
F_unzip___1:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1161;
  goto GC_COLLECT;
}
  GC_RET_1161:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_1162;
goto EVAL;
LABEL_1162:
switch (res) {
case C_Pair:
atom = getPTR(L_sp[-1])[3];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
}
F_kindToChar:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1163;
  goto GC_COLLECT;
}
  GC_RET_1163:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_1164;
goto EVAL;
LABEL_1164:
switch (res) {
case C_King:
L_POP(2);
L_PUSH(makeINT(75));
res = 75;
goto EVAL_RET;
case C_Queen:
L_POP(2);
L_PUSH(makeINT(81));
res = 81;
goto EVAL_RET;
case C_Rook:
L_POP(2);
L_PUSH(makeINT(82));
res = 82;
goto EVAL_RET;
case C_Bishop:
L_POP(2);
L_PUSH(makeINT(66));
res = 66;
goto EVAL_RET;
case C_Knight:
L_POP(2);
L_PUSH(makeINT(78));
res = 78;
goto EVAL_RET;
case C_Pawn:
L_POP(2);
L_PUSH(makeINT(80));
res = 80;
goto EVAL_RET;
}
F_isKing:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1165;
  goto GC_COLLECT;
}
  GC_RET_1165:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_kindToChar);
hp[2] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+0);
hp += 3;
eval_ret_addr = &&LABEL_1166;
goto EVAL;
LABEL_1166:
L_PUSH(makeINT(75));
res = 75;
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(2);
L_PUSH(makeCTR(res));
goto EVAL_RET;
F_pieceAt:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1167;
  goto GC_COLLECT;
}
  GC_RET_1167:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_1168;
goto EVAL;
LABEL_1168:
switch (res) {
case C_Board:
hp[0] = makeHDR(5);
hp[1] = makeFUN(&&F_pieceAtWith);
hp[2] = getPTR(L_sp[-2])[3];
hp[3] = makeCTR(C_Black);
hp[4] = makeCTR(C_Nothing);
hp[5] = getPTR(L_sp[-1])[3];
hp[6] = makeHDR(5);
hp[7] = makeFUN(&&F_pieceAtWith);
hp[8] = getPTR(L_sp[-2])[3];
hp[9] = makeCTR(C_White);
hp[10] = makePTR(hp+0);
hp[11] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+6);
hp += 12;
L_POP(2);
L_PUSH(atom);
goto F_pieceAtWith;
}
F_pieceAtWith:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1170;
  goto GC_COLLECT;
}
  GC_RET_1170:
atom = getPTR(L_sp[-1])[5];
getPTR(L_sp[-1])[5] = makeINT(0);
eval_ret_addr = &&LABEL_1171;
goto EVAL;
LABEL_1171:
switch (res) {
case C_Nil:
atom = getPTR(L_sp[-2])[4];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
case C_Cons:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_1172;
goto EVAL;
LABEL_1172:
switch (res) {
case C_Pair:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_sameSquare);
hp[2] = getPTR(L_sp[-1])[3];
hp[3] = getPTR(L_sp[-3])[2];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_1173;
goto EVAL;
LABEL_1173:
switch (res) {
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Pair);
hp[2] = getPTR(L_sp[-4])[3];
hp[3] = getPTR(L_sp[-2])[2];
hp[4] = makeHDR(2);
hp[5] = makeCTR(C_Just);
hp[6] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 7;
L_POP(4);
L_PUSH(atom);
res = C_Just;
goto EVAL_RET;
case C_False:
hp[0] = makeHDR(5);
hp[1] = makeFUN(&&F_pieceAtWith);
hp[2] = getPTR(L_sp[-4])[2];
hp[3] = getPTR(L_sp[-4])[3];
hp[4] = getPTR(L_sp[-4])[4];
hp[5] = getPTR(L_sp[-3])[3];
atom = makePTR(hp+0);
hp += 6;
L_POP(4);
L_PUSH(atom);
goto F_pieceAtWith;
}
}
}
F_emptyAtAllFP:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1175;
  goto GC_COLLECT;
}
  GC_RET_1175:
atom = getPTR(L_sp[-1])[5];
getPTR(L_sp[-1])[5] = makeINT(0);
eval_ret_addr = &&LABEL_1176;
goto EVAL;
LABEL_1176:
switch (res) {
case C_Board:
hp[0] = makeHDR(6);
hp[1] = makeFUN(&&F_emptyAtAllAndFP);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = getPTR(L_sp[-2])[4];
hp[5] = makeCTR(C_True);
hp[6] = getPTR(L_sp[-1])[3];
hp[7] = makeHDR(6);
hp[8] = makeFUN(&&F_emptyAtAllAndFP);
hp[9] = getPTR(L_sp[-2])[2];
hp[10] = getPTR(L_sp[-2])[3];
hp[11] = getPTR(L_sp[-2])[4];
hp[12] = makePTR(hp+0);
hp[13] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+7);
hp += 14;
L_POP(2);
L_PUSH(atom);
goto F_emptyAtAllAndFP;
}
F_emptyAtAllAndFP:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1178;
  goto GC_COLLECT;
}
  GC_RET_1178:
atom = getPTR(L_sp[-1])[6];
getPTR(L_sp[-1])[6] = makeINT(0);
eval_ret_addr = &&LABEL_1179;
goto EVAL;
LABEL_1179:
switch (res) {
case C_Nil:
atom = getPTR(L_sp[-2])[5];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
case C_Cons:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_1180;
goto EVAL;
LABEL_1180:
switch (res) {
case C_Pair:
hp[0] = makeHDR(5);
hp[1] = makeFUN(&&F_filePath);
hp[2] = getPTR(L_sp[-3])[2];
hp[3] = getPTR(L_sp[-3])[3];
hp[4] = getPTR(L_sp[-3])[4];
hp[5] = getPTR(L_sp[-1])[3];
atom = makePTR(hp+0);
hp += 6;
eval_ret_addr = &&LABEL_1181;
goto EVAL;
LABEL_1181:
switch (res) {
case C_True:
L_POP(4);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
case C_False:
hp[0] = makeHDR(6);
hp[1] = makeFUN(&&F_emptyAtAllAndFP);
hp[2] = getPTR(L_sp[-4])[2];
hp[3] = getPTR(L_sp[-4])[3];
hp[4] = getPTR(L_sp[-4])[4];
hp[5] = getPTR(L_sp[-4])[5];
hp[6] = getPTR(L_sp[-3])[3];
atom = makePTR(hp+0);
hp += 7;
L_POP(4);
L_PUSH(atom);
goto F_emptyAtAllAndFP;
}
}
}
F_emptyAtAllRP:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1182;
  goto GC_COLLECT;
}
  GC_RET_1182:
atom = getPTR(L_sp[-1])[5];
getPTR(L_sp[-1])[5] = makeINT(0);
eval_ret_addr = &&LABEL_1183;
goto EVAL;
LABEL_1183:
switch (res) {
case C_Board:
hp[0] = makeHDR(6);
hp[1] = makeFUN(&&F_emptyAtAllAndRP);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = getPTR(L_sp[-2])[4];
hp[5] = makeCTR(C_True);
hp[6] = getPTR(L_sp[-1])[3];
hp[7] = makeHDR(6);
hp[8] = makeFUN(&&F_emptyAtAllAndRP);
hp[9] = getPTR(L_sp[-2])[2];
hp[10] = getPTR(L_sp[-2])[3];
hp[11] = getPTR(L_sp[-2])[4];
hp[12] = makePTR(hp+0);
hp[13] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+7);
hp += 14;
L_POP(2);
L_PUSH(atom);
goto F_emptyAtAllAndRP;
}
F_emptyAtAllAndRP:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1185;
  goto GC_COLLECT;
}
  GC_RET_1185:
atom = getPTR(L_sp[-1])[6];
getPTR(L_sp[-1])[6] = makeINT(0);
eval_ret_addr = &&LABEL_1186;
goto EVAL;
LABEL_1186:
switch (res) {
case C_Nil:
atom = getPTR(L_sp[-2])[5];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
case C_Cons:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_1187;
goto EVAL;
LABEL_1187:
switch (res) {
case C_Pair:
hp[0] = makeHDR(5);
hp[1] = makeFUN(&&F_rankPath);
hp[2] = getPTR(L_sp[-3])[2];
hp[3] = getPTR(L_sp[-3])[3];
hp[4] = getPTR(L_sp[-3])[4];
hp[5] = getPTR(L_sp[-1])[3];
atom = makePTR(hp+0);
hp += 6;
eval_ret_addr = &&LABEL_1188;
goto EVAL;
LABEL_1188:
switch (res) {
case C_True:
L_POP(4);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
case C_False:
hp[0] = makeHDR(6);
hp[1] = makeFUN(&&F_emptyAtAllAndRP);
hp[2] = getPTR(L_sp[-4])[2];
hp[3] = getPTR(L_sp[-4])[3];
hp[4] = getPTR(L_sp[-4])[4];
hp[5] = getPTR(L_sp[-4])[5];
hp[6] = getPTR(L_sp[-3])[3];
atom = makePTR(hp+0);
hp += 7;
L_POP(4);
L_PUSH(atom);
goto F_emptyAtAllAndRP;
}
}
}
F_emptyAtAllDP:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1189;
  goto GC_COLLECT;
}
  GC_RET_1189:
atom = getPTR(L_sp[-1])[6];
getPTR(L_sp[-1])[6] = makeINT(0);
eval_ret_addr = &&LABEL_1190;
goto EVAL;
LABEL_1190:
switch (res) {
case C_Board:
hp[0] = makeHDR(7);
hp[1] = makeFUN(&&F_emptyAtAllAndDP);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = getPTR(L_sp[-2])[4];
hp[5] = getPTR(L_sp[-2])[5];
hp[6] = makeCTR(C_True);
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(7);
hp[9] = makeFUN(&&F_emptyAtAllAndDP);
hp[10] = getPTR(L_sp[-2])[2];
hp[11] = getPTR(L_sp[-2])[3];
hp[12] = getPTR(L_sp[-2])[4];
hp[13] = getPTR(L_sp[-2])[5];
hp[14] = makePTR(hp+0);
hp[15] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+8);
hp += 16;
L_POP(2);
L_PUSH(atom);
goto F_emptyAtAllAndDP;
}
F_emptyAtAllAndDP:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1192;
  goto GC_COLLECT;
}
  GC_RET_1192:
atom = getPTR(L_sp[-1])[7];
getPTR(L_sp[-1])[7] = makeINT(0);
eval_ret_addr = &&LABEL_1193;
goto EVAL;
LABEL_1193:
switch (res) {
case C_Nil:
atom = getPTR(L_sp[-2])[6];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
case C_Cons:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_1194;
goto EVAL;
LABEL_1194:
switch (res) {
case C_Pair:
hp[0] = makeHDR(6);
hp[1] = makeFUN(&&F_diagPath);
hp[2] = getPTR(L_sp[-3])[2];
hp[3] = getPTR(L_sp[-3])[3];
hp[4] = getPTR(L_sp[-3])[4];
hp[5] = getPTR(L_sp[-3])[5];
hp[6] = getPTR(L_sp[-1])[3];
atom = makePTR(hp+0);
hp += 7;
eval_ret_addr = &&LABEL_1195;
goto EVAL;
LABEL_1195:
switch (res) {
case C_True:
L_POP(4);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
case C_False:
hp[0] = makeHDR(7);
hp[1] = makeFUN(&&F_emptyAtAllAndDP);
hp[2] = getPTR(L_sp[-4])[2];
hp[3] = getPTR(L_sp[-4])[3];
hp[4] = getPTR(L_sp[-4])[4];
hp[5] = getPTR(L_sp[-4])[5];
hp[6] = getPTR(L_sp[-4])[6];
hp[7] = getPTR(L_sp[-3])[3];
atom = makePTR(hp+0);
hp += 8;
L_POP(4);
L_PUSH(atom);
goto F_emptyAtAllAndDP;
}
}
}
F_rmPieceAt:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1196;
  goto GC_COLLECT;
}
  GC_RET_1196:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_1197;
goto EVAL;
LABEL_1197:
switch (res) {
case C_White:
atom = getPTR(L_sp[-2])[4];
getPTR(L_sp[-2])[4] = makeINT(0);
eval_ret_addr = &&LABEL_1198;
goto EVAL;
LABEL_1198:
switch (res) {
case C_Board:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_rPa);
hp[2] = getPTR(L_sp[-3])[3];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Board);
hp[6] = makePTR(hp+0);
hp[7] = getPTR(L_sp[-1])[3];
atom = makePTR(hp+4);
hp += 8;
L_POP(3);
L_PUSH(atom);
res = C_Board;
goto EVAL_RET;
}
case C_Black:
atom = getPTR(L_sp[-2])[4];
getPTR(L_sp[-2])[4] = makeINT(0);
eval_ret_addr = &&LABEL_1200;
goto EVAL;
LABEL_1200:
switch (res) {
case C_Board:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_rPa);
hp[2] = getPTR(L_sp[-3])[3];
hp[3] = getPTR(L_sp[-1])[3];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Board);
hp[6] = getPTR(L_sp[-1])[2];
hp[7] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 8;
L_POP(3);
L_PUSH(atom);
res = C_Board;
goto EVAL_RET;
}
}
F_rPa:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1202;
  goto GC_COLLECT;
}
  GC_RET_1202:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_1203;
goto EVAL;
LABEL_1203:
switch (res) {
case C_Cons:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_1204;
goto EVAL;
LABEL_1204:
switch (res) {
case C_Pair:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_sameSquare);
hp[2] = getPTR(L_sp[-1])[3];
hp[3] = getPTR(L_sp[-3])[2];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_1205;
goto EVAL;
LABEL_1205:
switch (res) {
case C_True:
atom = getPTR(L_sp[-3])[3];
L_POP(4);
goto TAIL_EVAL;
goto EVAL_RET;
case C_False:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_rPa);
hp[2] = getPTR(L_sp[-4])[2];
hp[3] = getPTR(L_sp[-3])[3];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = getPTR(L_sp[-3])[2];
hp[7] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 8;
L_POP(4);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
}
}
F_putPieceAt:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1207;
  goto GC_COLLECT;
}
  GC_RET_1207:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_1208;
goto EVAL;
LABEL_1208:
switch (res) {
case C_Pair:
atom = getPTR(L_sp[-2])[4];
getPTR(L_sp[-2])[4] = makeINT(0);
eval_ret_addr = &&LABEL_1209;
goto EVAL;
LABEL_1209:
switch (res) {
case C_Board:
atom = getPTR(L_sp[-2])[2];
eval_ret_addr = &&LABEL_1210;
goto EVAL;
LABEL_1210:
switch (res) {
case C_White:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Pair);
hp[2] = getPTR(L_sp[-3])[3];
hp[3] = getPTR(L_sp[-4])[2];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = makePTR(hp+0);
hp[7] = getPTR(L_sp[-2])[2];
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Board);
hp[10] = makePTR(hp+4);
hp[11] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+8);
hp += 12;
L_POP(4);
L_PUSH(atom);
res = C_Board;
goto EVAL_RET;
case C_Black:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Pair);
hp[2] = getPTR(L_sp[-3])[3];
hp[3] = getPTR(L_sp[-4])[2];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = makePTR(hp+0);
hp[7] = getPTR(L_sp[-2])[3];
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Board);
hp[10] = getPTR(L_sp[-2])[2];
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(4);
L_PUSH(atom);
res = C_Board;
goto EVAL_RET;
}
}
}
F_kingSquare:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1215;
  goto GC_COLLECT;
}
  GC_RET_1215:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_forcesColoured);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-1])[3];
hp[4] = makeHDR(2);
hp[5] = makeFUN(&&F_kSq);
hp[6] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 7;
L_POP(1);
L_PUSH(atom);
goto F_kSq;
F_kSq:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1217;
  goto GC_COLLECT;
}
  GC_RET_1217:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_1218;
goto EVAL;
LABEL_1218:
switch (res) {
case C_Cons:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_1219;
goto EVAL;
LABEL_1219:
switch (res) {
case C_Pair:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_kindToChar);
hp[2] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+0);
hp += 3;
eval_ret_addr = &&LABEL_1220;
goto EVAL;
LABEL_1220:
L_PUSH(makeINT(75));
res = 75;
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(1);
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
atom = getPTR(L_sp[-2])[3];
L_POP(4);
goto TAIL_EVAL;
goto EVAL_RET;
case C_False:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_kSq);
hp[2] = getPTR(L_sp[-3])[3];
atom = makePTR(hp+0);
hp += 3;
L_POP(4);
L_PUSH(atom);
goto F_kSq;
}
}
}
F_opponent:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1221;
  goto GC_COLLECT;
}
  GC_RET_1221:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_1222;
goto EVAL;
LABEL_1222:
switch (res) {
case C_Black:
L_POP(2);
L_PUSH(makeCTR(C_White));
res = C_White;
goto EVAL_RET;
case C_White:
L_POP(2);
L_PUSH(makeCTR(C_Black));
res = C_Black;
goto EVAL_RET;
}
F_colourOf:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1223;
  goto GC_COLLECT;
}
  GC_RET_1223:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_1224;
goto EVAL;
LABEL_1224:
switch (res) {
case C_Pair:
atom = getPTR(L_sp[-1])[2];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
}
F_kindOf:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1225;
  goto GC_COLLECT;
}
  GC_RET_1225:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_1226;
goto EVAL;
LABEL_1226:
switch (res) {
case C_Pair:
atom = getPTR(L_sp[-1])[3];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
}
F_sameColour:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1227;
  goto GC_COLLECT;
}
  GC_RET_1227:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_1228;
goto EVAL;
LABEL_1228:
switch (res) {
case C_White:
atom = getPTR(L_sp[-2])[3];
getPTR(L_sp[-2])[3] = makeINT(0);
eval_ret_addr = &&LABEL_1229;
goto EVAL;
LABEL_1229:
switch (res) {
case C_White:
L_POP(3);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
case C_Black:
L_POP(3);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
}
case C_Black:
atom = getPTR(L_sp[-2])[3];
getPTR(L_sp[-2])[3] = makeINT(0);
eval_ret_addr = &&LABEL_1230;
goto EVAL;
LABEL_1230:
switch (res) {
case C_White:
L_POP(3);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
case C_Black:
L_POP(3);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
}
}
F_rank:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1231;
  goto GC_COLLECT;
}
  GC_RET_1231:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_1232;
goto EVAL;
LABEL_1232:
switch (res) {
case C_Pair:
atom = getPTR(L_sp[-1])[3];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
}
F_file:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1233;
  goto GC_COLLECT;
}
  GC_RET_1233:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_1234;
goto EVAL;
LABEL_1234:
switch (res) {
case C_Pair:
atom = getPTR(L_sp[-1])[2];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
}
F_sameSquare:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1235;
  goto GC_COLLECT;
}
  GC_RET_1235:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_1236;
goto EVAL;
LABEL_1236:
switch (res) {
case C_Pair:
atom = getPTR(L_sp[-2])[3];
getPTR(L_sp[-2])[3] = makeINT(0);
eval_ret_addr = &&LABEL_1237;
goto EVAL;
LABEL_1237:
switch (res) {
case C_Pair:
atom = getPTR(L_sp[-2])[2];
eval_ret_addr = &&LABEL_1238;
goto EVAL;
LABEL_1238:
atom = getPTR(L_sp[-2])[2];
eval_ret_addr = &&LABEL_1239;
goto EVAL;
LABEL_1239:
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(1);
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
atom = getPTR(L_sp[-3])[3];
eval_ret_addr = &&LABEL_1240;
goto EVAL;
LABEL_1240:
atom = getPTR(L_sp[-3])[3];
eval_ret_addr = &&LABEL_1241;
goto EVAL;
LABEL_1241:
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(5);
L_PUSH(makeCTR(res));
goto EVAL_RET;
case C_False:
L_POP(4);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
}
}
}
F_onboard:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1242;
  goto GC_COLLECT;
}
  GC_RET_1242:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_1243;
goto EVAL;
LABEL_1243:
switch (res) {
case C_Pair:
L_PUSH(makeINT(1));
res = 1;
atom = getPTR(L_sp[-2])[2];
eval_ret_addr = &&LABEL_1244;
goto EVAL;
LABEL_1244:
L_POP(1);
res = getINT(L_top) <= res ? C_True : C_False;
L_POP(1);
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
atom = getPTR(L_sp[-2])[2];
eval_ret_addr = &&LABEL_1245;
goto EVAL;
LABEL_1245:
L_PUSH(makeINT(8));
res = 8;
L_POP(1);
res = getINT(L_top) <= res ? C_True : C_False;
L_POP(1);
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
L_PUSH(makeINT(1));
res = 1;
atom = getPTR(L_sp[-4])[3];
eval_ret_addr = &&LABEL_1246;
goto EVAL;
LABEL_1246:
L_POP(1);
res = getINT(L_top) <= res ? C_True : C_False;
L_POP(1);
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
atom = getPTR(L_sp[-4])[3];
eval_ret_addr = &&LABEL_1247;
goto EVAL;
LABEL_1247:
L_PUSH(makeINT(8));
res = 8;
L_POP(1);
res = getINT(L_top) <= res ? C_True : C_False;
L_POP(6);
L_PUSH(makeCTR(res));
goto EVAL_RET;
case C_False:
L_POP(5);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
}
case C_False:
L_POP(4);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
}
case C_False:
L_POP(3);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
}
}
F_forcesColoured:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1248;
  goto GC_COLLECT;
}
  GC_RET_1248:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_1249;
goto EVAL;
LABEL_1249:
switch (res) {
case C_White:
atom = getPTR(L_sp[-2])[3];
getPTR(L_sp[-2])[3] = makeINT(0);
eval_ret_addr = &&LABEL_1250;
goto EVAL;
LABEL_1250:
switch (res) {
case C_Board:
atom = getPTR(L_sp[-1])[2];
L_POP(3);
goto TAIL_EVAL;
goto EVAL_RET;
}
case C_Black:
atom = getPTR(L_sp[-2])[3];
getPTR(L_sp[-2])[3] = makeINT(0);
eval_ret_addr = &&LABEL_1251;
goto EVAL;
LABEL_1251:
switch (res) {
case C_Board:
atom = getPTR(L_sp[-1])[3];
L_POP(3);
goto TAIL_EVAL;
goto EVAL_RET;
}
}
F_concatMapMFP:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1252;
  goto GC_COLLECT;
}
  GC_RET_1252:
atom = getPTR(L_sp[-1])[4];
getPTR(L_sp[-1])[4] = makeINT(0);
eval_ret_addr = &&LABEL_1253;
goto EVAL;
LABEL_1253:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(4);
hp[1] = makeFUN(&&F_movesForPiece);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = getPTR(L_sp[-1])[2];
hp[5] = makeHDR(4);
hp[6] = makeFUN(&&F_concatMapMFP);
hp[7] = getPTR(L_sp[-2])[2];
hp[8] = getPTR(L_sp[-2])[3];
hp[9] = getPTR(L_sp[-1])[3];
hp[10] = makeHDR(3);
hp[11] = makeFUN(&&F_append);
hp[12] = makePTR(hp+0);
hp[13] = makePTR(hp+5);
atom = makePTR(hp+10);
hp += 14;
L_POP(2);
L_PUSH(atom);
goto F_append;
}
F_concatMapTM:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1256;
  goto GC_COLLECT;
}
  GC_RET_1256:
atom = getPTR(L_sp[-1])[5];
getPTR(L_sp[-1])[5] = makeINT(0);
eval_ret_addr = &&LABEL_1257;
goto EVAL;
LABEL_1257:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(5);
hp[1] = makeFUN(&&F_tryMove);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = getPTR(L_sp[-2])[4];
hp[5] = getPTR(L_sp[-1])[2];
hp[6] = makeHDR(5);
hp[7] = makeFUN(&&F_concatMapTM);
hp[8] = getPTR(L_sp[-2])[2];
hp[9] = getPTR(L_sp[-2])[3];
hp[10] = getPTR(L_sp[-2])[4];
hp[11] = getPTR(L_sp[-1])[3];
hp[12] = makeHDR(3);
hp[13] = makeFUN(&&F_append);
hp[14] = makePTR(hp+0);
hp[15] = makePTR(hp+6);
atom = makePTR(hp+12);
hp += 16;
L_POP(2);
L_PUSH(atom);
goto F_append;
}
F_moveDetailsFor:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1260;
  goto GC_COLLECT;
}
  GC_RET_1260:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_forcesColoured);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-1])[3];
hp[4] = makeHDR(4);
hp[5] = makeFUN(&&F_concatMapMFP);
hp[6] = getPTR(L_sp[-1])[2];
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 9;
L_POP(1);
L_PUSH(atom);
goto F_concatMapMFP;
F_movesForPiece:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1262;
  goto GC_COLLECT;
}
  GC_RET_1262:
hp[0] = makeHDR(4);
hp[1] = makeFUN(&&F_rawmoves);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-1])[4];
hp[4] = getPTR(L_sp[-1])[3];
hp[5] = makeHDR(5);
hp[6] = makeFUN(&&F_concatMapTM);
hp[7] = getPTR(L_sp[-1])[2];
hp[8] = getPTR(L_sp[-1])[3];
hp[9] = getPTR(L_sp[-1])[4];
hp[10] = makePTR(hp+0);
atom = makePTR(hp+5);
hp += 11;
L_POP(1);
L_PUSH(atom);
goto F_concatMapTM;
F_tryMove:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1264;
  goto GC_COLLECT;
}
  GC_RET_1264:
atom = getPTR(L_sp[-1])[4];
getPTR(L_sp[-1])[4] = makeINT(0);
eval_ret_addr = &&LABEL_1265;
goto EVAL;
LABEL_1265:
switch (res) {
case C_Pair:
atom = getPTR(L_sp[-2])[5];
getPTR(L_sp[-2])[5] = makeINT(0);
eval_ret_addr = &&LABEL_1266;
goto EVAL;
LABEL_1266:
switch (res) {
case C_Move:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Pair);
hp[2] = getPTR(L_sp[-3])[2];
hp[3] = getPTR(L_sp[-2])[2];
hp[4] = makeHDR(4);
hp[5] = makeFUN(&&F_rmPieceAt);
hp[6] = getPTR(L_sp[-3])[2];
hp[7] = getPTR(L_sp[-2])[3];
hp[8] = getPTR(L_sp[-3])[3];
hp[9] = makeHDR(3);
hp[10] = makeFUN(&&F_tryMove___0);
hp[11] = getPTR(L_sp[-1])[4];
hp[12] = makePTR(hp+0);
hp[13] = makeHDR(6);
hp[14] = makeFUN(&&F_tryMove___1);
hp[15] = getPTR(L_sp[-1])[3];
hp[16] = getPTR(L_sp[-1])[2];
hp[17] = makePTR(hp+9);
hp[18] = makePTR(hp+4);
hp[19] = getPTR(L_sp[-3])[2];
hp[20] = makeHDR(8);
hp[21] = makeFUN(&&F_tryMove___3);
hp[22] = getPTR(L_sp[-3])[2];
hp[23] = makePTR(hp+13);
hp[24] = makePTR(hp+0);
hp[25] = getPTR(L_sp[-2])[3];
hp[26] = getPTR(L_sp[-1])[2];
hp[27] = getPTR(L_sp[-1])[3];
hp[28] = getPTR(L_sp[-1])[4];
atom = makePTR(hp+20);
hp += 29;
L_POP(3);
L_PUSH(atom);
goto F_tryMove___3;
}
}
F_tryMove___0:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1267;
  goto GC_COLLECT;
}
  GC_RET_1267:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_1268;
goto EVAL;
LABEL_1268:
switch (res) {
case C_Nothing:
atom = getPTR(L_sp[-2])[3];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
case C_Just:
atom = getPTR(L_sp[-1])[2];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
}
F_tryMove___2:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1269;
  goto GC_COLLECT;
}
  GC_RET_1269:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_1270;
goto EVAL;
LABEL_1270:
switch (res) {
case C_Black:
L_POP(2);
L_PUSH(makeCTR(C_White));
res = C_White;
goto EVAL_RET;
case C_White:
L_POP(2);
L_PUSH(makeCTR(C_Black));
res = C_Black;
goto EVAL_RET;
}
F_tryMove___1:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1271;
  goto GC_COLLECT;
}
  GC_RET_1271:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_1272;
goto EVAL;
LABEL_1272:
switch (res) {
case C_Nothing:
hp[0] = makeHDR(4);
hp[1] = makeFUN(&&F_putPieceAt);
hp[2] = getPTR(L_sp[-2])[3];
hp[3] = getPTR(L_sp[-2])[4];
hp[4] = getPTR(L_sp[-2])[5];
atom = makePTR(hp+0);
hp += 5;
L_POP(2);
L_PUSH(atom);
goto F_putPieceAt;
case C_Just:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_tryMove___2);
hp[2] = getPTR(L_sp[-2])[6];
hp[3] = makeHDR(4);
hp[4] = makeFUN(&&F_rmPieceAt);
hp[5] = makePTR(hp+0);
hp[6] = getPTR(L_sp[-2])[3];
hp[7] = getPTR(L_sp[-2])[5];
hp[8] = makeHDR(4);
hp[9] = makeFUN(&&F_putPieceAt);
hp[10] = getPTR(L_sp[-2])[3];
hp[11] = getPTR(L_sp[-2])[4];
hp[12] = makePTR(hp+3);
atom = makePTR(hp+8);
hp += 13;
L_POP(2);
L_PUSH(atom);
goto F_putPieceAt;
}
F_tryMove___3:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1275;
  goto GC_COLLECT;
}
  GC_RET_1275:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_kingincheck);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-1])[3];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_1276;
goto EVAL;
LABEL_1276:
switch (res) {
case C_False:
hp[0] = makeHDR(4);
hp[1] = makeCTR(C_Move);
hp[2] = getPTR(L_sp[-2])[6];
hp[3] = getPTR(L_sp[-2])[7];
hp[4] = getPTR(L_sp[-2])[8];
hp[5] = makeHDR(4);
hp[6] = makeCTR(C_MoveInFull);
hp[7] = getPTR(L_sp[-2])[4];
hp[8] = getPTR(L_sp[-2])[5];
hp[9] = makePTR(hp+0);
hp[10] = makeHDR(3);
hp[11] = makeCTR(C_Pair);
hp[12] = makePTR(hp+5);
hp[13] = getPTR(L_sp[-2])[3];
hp[14] = makeHDR(3);
hp[15] = makeCTR(C_Cons);
hp[16] = makePTR(hp+10);
hp[17] = makeCTR(C_Nil);
atom = makePTR(hp+14);
hp += 18;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
case C_True:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
}
F_rawmoves:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1280;
  goto GC_COLLECT;
}
  GC_RET_1280:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_1281;
goto EVAL;
LABEL_1281:
switch (res) {
case C_Pair:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_1282;
goto EVAL;
LABEL_1282:
switch (res) {
case C_King:
hp[0] = makeHDR(4);
hp[1] = makeFUN(&&F_kingmoves);
hp[2] = getPTR(L_sp[-3])[2];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = getPTR(L_sp[-3])[4];
atom = makePTR(hp+0);
hp += 5;
L_POP(3);
L_PUSH(atom);
goto F_kingmoves;
case C_Queen:
hp[0] = makeHDR(4);
hp[1] = makeFUN(&&F_queenmoves);
hp[2] = getPTR(L_sp[-3])[2];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = getPTR(L_sp[-3])[4];
atom = makePTR(hp+0);
hp += 5;
L_POP(3);
L_PUSH(atom);
goto F_queenmoves;
case C_Rook:
hp[0] = makeHDR(4);
hp[1] = makeFUN(&&F_rookmoves);
hp[2] = getPTR(L_sp[-3])[2];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = getPTR(L_sp[-3])[4];
atom = makePTR(hp+0);
hp += 5;
L_POP(3);
L_PUSH(atom);
goto F_rookmoves;
case C_Bishop:
hp[0] = makeHDR(4);
hp[1] = makeFUN(&&F_bishopmoves);
hp[2] = getPTR(L_sp[-3])[2];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = getPTR(L_sp[-3])[4];
atom = makePTR(hp+0);
hp += 5;
L_POP(3);
L_PUSH(atom);
goto F_bishopmoves;
case C_Knight:
hp[0] = makeHDR(4);
hp[1] = makeFUN(&&F_knightmoves);
hp[2] = getPTR(L_sp[-3])[2];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = getPTR(L_sp[-3])[4];
atom = makePTR(hp+0);
hp += 5;
L_POP(3);
L_PUSH(atom);
goto F_knightmoves;
case C_Pawn:
hp[0] = makeHDR(4);
hp[1] = makeFUN(&&F_pawnmoves);
hp[2] = getPTR(L_sp[-3])[2];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = getPTR(L_sp[-3])[4];
atom = makePTR(hp+0);
hp += 5;
L_POP(3);
L_PUSH(atom);
goto F_pawnmoves;
}
}
F_incSquare:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1283;
  goto GC_COLLECT;
}
  GC_RET_1283:
atom = getPTR(L_sp[-1])[4];
getPTR(L_sp[-1])[4] = makeINT(0);
eval_ret_addr = &&LABEL_1284;
goto EVAL;
LABEL_1284:
switch (res) {
case C_Pair:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&P_ADD);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&P_ADD);
hp[6] = getPTR(L_sp[-2])[3];
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Pair);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(2);
L_PUSH(atom);
res = C_Pair;
goto EVAL_RET;
}
F_bishopmoves:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1287;
  goto GC_COLLECT;
}
  GC_RET_1287:
hp[0] = makeHDR(6);
hp[1] = makeFUN(&&F_moveLine);
hp[2] = getPTR(L_sp[-1])[4];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = getPTR(L_sp[-1])[3];
hp[5] = makeINT(-1);
hp[6] = makeINT(1);
hp[7] = makeHDR(6);
hp[8] = makeFUN(&&F_moveLine);
hp[9] = getPTR(L_sp[-1])[4];
hp[10] = getPTR(L_sp[-1])[2];
hp[11] = getPTR(L_sp[-1])[3];
hp[12] = makeINT(1);
hp[13] = makeINT(1);
hp[14] = makeHDR(6);
hp[15] = makeFUN(&&F_moveLine);
hp[16] = getPTR(L_sp[-1])[4];
hp[17] = getPTR(L_sp[-1])[2];
hp[18] = getPTR(L_sp[-1])[3];
hp[19] = makeINT(-1);
hp[20] = makeINT(-1);
hp[21] = makeHDR(6);
hp[22] = makeFUN(&&F_moveLine);
hp[23] = getPTR(L_sp[-1])[4];
hp[24] = getPTR(L_sp[-1])[2];
hp[25] = getPTR(L_sp[-1])[3];
hp[26] = makeINT(1);
hp[27] = makeINT(-1);
hp[28] = makeHDR(3);
hp[29] = makeFUN(&&F_append);
hp[30] = makePTR(hp+14);
hp[31] = makePTR(hp+21);
hp[32] = makeHDR(3);
hp[33] = makeFUN(&&F_append);
hp[34] = makePTR(hp+7);
hp[35] = makePTR(hp+28);
hp[36] = makeHDR(3);
hp[37] = makeFUN(&&F_append);
hp[38] = makePTR(hp+0);
hp[39] = makePTR(hp+32);
atom = makePTR(hp+36);
hp += 40;
L_POP(1);
L_PUSH(atom);
goto F_append;
F_rookmoves:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1294;
  goto GC_COLLECT;
}
  GC_RET_1294:
hp[0] = makeHDR(6);
hp[1] = makeFUN(&&F_moveLine);
hp[2] = getPTR(L_sp[-1])[4];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = getPTR(L_sp[-1])[3];
hp[5] = makeINT(-1);
hp[6] = makeINT(0);
hp[7] = makeHDR(6);
hp[8] = makeFUN(&&F_moveLine);
hp[9] = getPTR(L_sp[-1])[4];
hp[10] = getPTR(L_sp[-1])[2];
hp[11] = getPTR(L_sp[-1])[3];
hp[12] = makeINT(1);
hp[13] = makeINT(0);
hp[14] = makeHDR(6);
hp[15] = makeFUN(&&F_moveLine);
hp[16] = getPTR(L_sp[-1])[4];
hp[17] = getPTR(L_sp[-1])[2];
hp[18] = getPTR(L_sp[-1])[3];
hp[19] = makeINT(0);
hp[20] = makeINT(-1);
hp[21] = makeHDR(6);
hp[22] = makeFUN(&&F_moveLine);
hp[23] = getPTR(L_sp[-1])[4];
hp[24] = getPTR(L_sp[-1])[2];
hp[25] = getPTR(L_sp[-1])[3];
hp[26] = makeINT(0);
hp[27] = makeINT(1);
hp[28] = makeHDR(3);
hp[29] = makeFUN(&&F_append);
hp[30] = makePTR(hp+14);
hp[31] = makePTR(hp+21);
hp[32] = makeHDR(3);
hp[33] = makeFUN(&&F_append);
hp[34] = makePTR(hp+7);
hp[35] = makePTR(hp+28);
hp[36] = makeHDR(3);
hp[37] = makeFUN(&&F_append);
hp[38] = makePTR(hp+0);
hp[39] = makePTR(hp+32);
atom = makePTR(hp+36);
hp += 40;
L_POP(1);
L_PUSH(atom);
goto F_append;
F_moveLine:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1301;
  goto GC_COLLECT;
}
  GC_RET_1301:
hp[0] = makeHDR(4);
hp[1] = makeFUN(&&F_moveLine___0);
hp[2] = getPTR(L_sp[-1])[4];
hp[3] = getPTR(L_sp[-1])[5];
hp[4] = getPTR(L_sp[-1])[6];
hp[5] = makeHDR(6);
hp[6] = makeFUN(&&F_moveLine___1);
hp[7] = makePTR(hp+0);
hp[8] = getPTR(L_sp[-1])[2];
hp[9] = getPTR(L_sp[-1])[3];
hp[10] = getPTR(L_sp[-1])[5];
hp[11] = getPTR(L_sp[-1])[6];
atom = makePTR(hp+5);
hp += 12;
L_POP(1);
L_PUSH(atom);
goto F_moveLine___1;
F_moveLine___0:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1302;
  goto GC_COLLECT;
}
  GC_RET_1302:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_1303;
goto EVAL;
LABEL_1303:
switch (res) {
case C_Pair:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&P_ADD);
hp[2] = getPTR(L_sp[-2])[3];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&P_ADD);
hp[6] = getPTR(L_sp[-2])[4];
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Pair);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(2);
L_PUSH(atom);
res = C_Pair;
goto EVAL_RET;
}
F_moveLine___2:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1306;
  goto GC_COLLECT;
}
  GC_RET_1306:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_1307;
goto EVAL;
LABEL_1307:
switch (res) {
case C_Pair:
atom = getPTR(L_sp[-1])[2];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
}
F_moveLine___1:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1308;
  goto GC_COLLECT;
}
  GC_RET_1308:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_onboard);
hp[2] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+0);
hp += 3;
eval_ret_addr = &&LABEL_1309;
goto EVAL;
LABEL_1309:
switch (res) {
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_pieceAt);
hp[2] = getPTR(L_sp[-2])[3];
hp[3] = getPTR(L_sp[-2])[2];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_1310;
goto EVAL;
LABEL_1310:
switch (res) {
case C_Nothing:
hp[0] = makeHDR(4);
hp[1] = makeCTR(C_Move);
hp[2] = getPTR(L_sp[-3])[2];
hp[3] = makeCTR(C_Nothing);
hp[4] = makeCTR(C_Nothing);
hp[5] = makeHDR(6);
hp[6] = makeFUN(&&F_moveLine);
hp[7] = getPTR(L_sp[-3])[3];
hp[8] = getPTR(L_sp[-3])[4];
hp[9] = getPTR(L_sp[-3])[2];
hp[10] = getPTR(L_sp[-3])[5];
hp[11] = getPTR(L_sp[-3])[6];
hp[12] = makeHDR(3);
hp[13] = makeCTR(C_Cons);
hp[14] = makePTR(hp+0);
hp[15] = makePTR(hp+5);
atom = makePTR(hp+12);
hp += 16;
L_POP(3);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
case C_Just:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_moveLine___2);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = makeHDR(3);
hp[4] = makeFUN(&&F_sameColour);
hp[5] = makePTR(hp+0);
hp[6] = getPTR(L_sp[-3])[4];
atom = makePTR(hp+3);
hp += 7;
eval_ret_addr = &&LABEL_1314;
goto EVAL;
LABEL_1314:
switch (res) {
case C_False:
hp[0] = makeHDR(2);
hp[1] = makeCTR(C_Just);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = makeHDR(4);
hp[4] = makeCTR(C_Move);
hp[5] = getPTR(L_sp[-4])[2];
hp[6] = makePTR(hp+0);
hp[7] = makeCTR(C_Nothing);
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makePTR(hp+3);
hp[11] = makeCTR(C_Nil);
atom = makePTR(hp+8);
hp += 12;
L_POP(4);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
case C_True:
L_POP(4);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
}
}
case C_False:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
}
F_kingmoves:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1317;
  goto GC_COLLECT;
}
  GC_RET_1317:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_1318;
goto EVAL;
LABEL_1318:
switch (res) {
case C_Pair:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&P_ADD);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = makeINT(1);
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&P_SUB);
hp[6] = getPTR(L_sp[-1])[2];
hp[7] = makeINT(1);
hp[8] = makeHDR(3);
hp[9] = makeFUN(&&P_ADD);
hp[10] = getPTR(L_sp[-1])[3];
hp[11] = makeINT(1);
hp[12] = makeHDR(3);
hp[13] = makeFUN(&&P_SUB);
hp[14] = getPTR(L_sp[-1])[3];
hp[15] = makeINT(1);
hp[16] = makeHDR(3);
hp[17] = makeCTR(C_Pair);
hp[18] = makePTR(hp+4);
hp[19] = makePTR(hp+8);
hp[20] = makeHDR(3);
hp[21] = makeCTR(C_Pair);
hp[22] = getPTR(L_sp[-1])[2];
hp[23] = makePTR(hp+8);
hp[24] = makeHDR(3);
hp[25] = makeCTR(C_Pair);
hp[26] = makePTR(hp+0);
hp[27] = makePTR(hp+8);
hp[28] = makeHDR(3);
hp[29] = makeCTR(C_Pair);
hp[30] = makePTR(hp+4);
hp[31] = getPTR(L_sp[-1])[3];
hp[32] = makeHDR(3);
hp[33] = makeCTR(C_Pair);
hp[34] = makePTR(hp+0);
hp[35] = getPTR(L_sp[-1])[3];
hp[36] = makeHDR(3);
hp[37] = makeCTR(C_Pair);
hp[38] = makePTR(hp+4);
hp[39] = makePTR(hp+12);
hp[40] = makeHDR(3);
hp[41] = makeCTR(C_Pair);
hp[42] = getPTR(L_sp[-1])[2];
hp[43] = makePTR(hp+12);
hp[44] = makeHDR(3);
hp[45] = makeCTR(C_Pair);
hp[46] = makePTR(hp+0);
hp[47] = makePTR(hp+12);
hp[48] = makeHDR(3);
hp[49] = makeCTR(C_Cons);
hp[50] = makePTR(hp+44);
hp[51] = makeCTR(C_Nil);
hp[52] = makeHDR(3);
hp[53] = makeCTR(C_Cons);
hp[54] = makePTR(hp+40);
hp[55] = makePTR(hp+48);
hp[56] = makeHDR(3);
hp[57] = makeCTR(C_Cons);
hp[58] = makePTR(hp+36);
hp[59] = makePTR(hp+52);
hp[60] = makeHDR(3);
hp[61] = makeCTR(C_Cons);
hp[62] = makePTR(hp+32);
hp[63] = makePTR(hp+56);
hp[64] = makeHDR(3);
hp[65] = makeCTR(C_Cons);
hp[66] = makePTR(hp+28);
hp[67] = makePTR(hp+60);
hp[68] = makeHDR(3);
hp[69] = makeCTR(C_Cons);
hp[70] = makePTR(hp+24);
hp[71] = makePTR(hp+64);
hp[72] = makeHDR(3);
hp[73] = makeCTR(C_Cons);
hp[74] = makePTR(hp+20);
hp[75] = makePTR(hp+68);
hp[76] = makeHDR(3);
hp[77] = makeCTR(C_Cons);
hp[78] = makePTR(hp+16);
hp[79] = makePTR(hp+72);
hp[80] = makeHDR(5);
hp[81] = makeFUN(&&F_sift);
hp[82] = getPTR(L_sp[-2])[2];
hp[83] = getPTR(L_sp[-2])[4];
hp[84] = makeCTR(C_Nil);
hp[85] = makePTR(hp+76);
atom = makePTR(hp+80);
hp += 86;
L_POP(2);
L_PUSH(atom);
goto F_sift;
}
F_knightmoves:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1335;
  goto GC_COLLECT;
}
  GC_RET_1335:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_1336;
goto EVAL;
LABEL_1336:
switch (res) {
case C_Pair:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&P_ADD);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = makeINT(1);
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&P_SUB);
hp[6] = getPTR(L_sp[-1])[2];
hp[7] = makeINT(1);
hp[8] = makeHDR(3);
hp[9] = makeFUN(&&P_ADD);
hp[10] = getPTR(L_sp[-1])[3];
hp[11] = makeINT(1);
hp[12] = makeHDR(3);
hp[13] = makeFUN(&&P_SUB);
hp[14] = getPTR(L_sp[-1])[3];
hp[15] = makeINT(1);
hp[16] = makeHDR(3);
hp[17] = makeFUN(&&P_ADD);
hp[18] = getPTR(L_sp[-1])[2];
hp[19] = makeINT(2);
hp[20] = makeHDR(3);
hp[21] = makeFUN(&&P_SUB);
hp[22] = getPTR(L_sp[-1])[2];
hp[23] = makeINT(2);
hp[24] = makeHDR(3);
hp[25] = makeFUN(&&P_ADD);
hp[26] = getPTR(L_sp[-1])[3];
hp[27] = makeINT(2);
hp[28] = makeHDR(3);
hp[29] = makeFUN(&&P_SUB);
hp[30] = getPTR(L_sp[-1])[3];
hp[31] = makeINT(2);
hp[32] = makeHDR(3);
hp[33] = makeCTR(C_Pair);
hp[34] = makePTR(hp+4);
hp[35] = makePTR(hp+24);
hp[36] = makeHDR(3);
hp[37] = makeCTR(C_Pair);
hp[38] = makePTR(hp+0);
hp[39] = makePTR(hp+24);
hp[40] = makeHDR(3);
hp[41] = makeCTR(C_Pair);
hp[42] = makePTR(hp+20);
hp[43] = makePTR(hp+8);
hp[44] = makeHDR(3);
hp[45] = makeCTR(C_Pair);
hp[46] = makePTR(hp+16);
hp[47] = makePTR(hp+8);
hp[48] = makeHDR(3);
hp[49] = makeCTR(C_Pair);
hp[50] = makePTR(hp+20);
hp[51] = makePTR(hp+12);
hp[52] = makeHDR(3);
hp[53] = makeCTR(C_Pair);
hp[54] = makePTR(hp+16);
hp[55] = makePTR(hp+12);
hp[56] = makeHDR(3);
hp[57] = makeCTR(C_Pair);
hp[58] = makePTR(hp+4);
hp[59] = makePTR(hp+28);
hp[60] = makeHDR(3);
hp[61] = makeCTR(C_Pair);
hp[62] = makePTR(hp+0);
hp[63] = makePTR(hp+28);
hp[64] = makeHDR(3);
hp[65] = makeCTR(C_Cons);
hp[66] = makePTR(hp+60);
hp[67] = makeCTR(C_Nil);
hp[68] = makeHDR(3);
hp[69] = makeCTR(C_Cons);
hp[70] = makePTR(hp+56);
hp[71] = makePTR(hp+64);
hp[72] = makeHDR(3);
hp[73] = makeCTR(C_Cons);
hp[74] = makePTR(hp+52);
hp[75] = makePTR(hp+68);
hp[76] = makeHDR(3);
hp[77] = makeCTR(C_Cons);
hp[78] = makePTR(hp+48);
hp[79] = makePTR(hp+72);
hp[80] = makeHDR(3);
hp[81] = makeCTR(C_Cons);
hp[82] = makePTR(hp+44);
hp[83] = makePTR(hp+76);
hp[84] = makeHDR(3);
hp[85] = makeCTR(C_Cons);
hp[86] = makePTR(hp+40);
hp[87] = makePTR(hp+80);
hp[88] = makeHDR(3);
hp[89] = makeCTR(C_Cons);
hp[90] = makePTR(hp+36);
hp[91] = makePTR(hp+84);
hp[92] = makeHDR(3);
hp[93] = makeCTR(C_Cons);
hp[94] = makePTR(hp+32);
hp[95] = makePTR(hp+88);
hp[96] = makeHDR(5);
hp[97] = makeFUN(&&F_sift);
hp[98] = getPTR(L_sp[-2])[2];
hp[99] = getPTR(L_sp[-2])[4];
hp[100] = makeCTR(C_Nil);
hp[101] = makePTR(hp+92);
atom = makePTR(hp+96);
hp += 102;
L_POP(2);
L_PUSH(atom);
goto F_sift;
}
F_sift:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1353;
  goto GC_COLLECT;
}
  GC_RET_1353:
atom = getPTR(L_sp[-1])[5];
getPTR(L_sp[-1])[5] = makeINT(0);
eval_ret_addr = &&LABEL_1354;
goto EVAL;
LABEL_1354:
switch (res) {
case C_Nil:
atom = getPTR(L_sp[-2])[4];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_onboard);
hp[2] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+0);
hp += 3;
eval_ret_addr = &&LABEL_1355;
goto EVAL;
LABEL_1355:
switch (res) {
case C_False:
hp[0] = makeHDR(5);
hp[1] = makeFUN(&&F_sift);
hp[2] = getPTR(L_sp[-3])[2];
hp[3] = getPTR(L_sp[-3])[3];
hp[4] = getPTR(L_sp[-3])[4];
hp[5] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+0);
hp += 6;
L_POP(3);
L_PUSH(atom);
goto F_sift;
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_pieceAt);
hp[2] = getPTR(L_sp[-3])[3];
hp[3] = getPTR(L_sp[-2])[2];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_1356;
goto EVAL;
LABEL_1356:
switch (res) {
case C_Nothing:
hp[0] = makeHDR(4);
hp[1] = makeCTR(C_Move);
hp[2] = getPTR(L_sp[-3])[2];
hp[3] = makeCTR(C_Nothing);
hp[4] = makeCTR(C_Nothing);
hp[5] = makeHDR(3);
hp[6] = makeCTR(C_Cons);
hp[7] = makePTR(hp+0);
hp[8] = getPTR(L_sp[-4])[4];
hp[9] = makeHDR(5);
hp[10] = makeFUN(&&F_sift);
hp[11] = getPTR(L_sp[-4])[2];
hp[12] = getPTR(L_sp[-4])[3];
hp[13] = makePTR(hp+5);
hp[14] = getPTR(L_sp[-3])[3];
atom = makePTR(hp+9);
hp += 15;
L_POP(4);
L_PUSH(atom);
goto F_sift;
case C_Just:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_sift___0);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = makeHDR(3);
hp[4] = makeFUN(&&F_sameColour);
hp[5] = makePTR(hp+0);
hp[6] = getPTR(L_sp[-4])[2];
atom = makePTR(hp+3);
hp += 7;
eval_ret_addr = &&LABEL_1360;
goto EVAL;
LABEL_1360:
switch (res) {
case C_True:
hp[0] = makeHDR(5);
hp[1] = makeFUN(&&F_sift);
hp[2] = getPTR(L_sp[-5])[2];
hp[3] = getPTR(L_sp[-5])[3];
hp[4] = getPTR(L_sp[-5])[4];
hp[5] = getPTR(L_sp[-4])[3];
atom = makePTR(hp+0);
hp += 6;
L_POP(5);
L_PUSH(atom);
goto F_sift;
case C_False:
hp[0] = makeHDR(2);
hp[1] = makeCTR(C_Just);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = makeHDR(4);
hp[4] = makeCTR(C_Move);
hp[5] = getPTR(L_sp[-4])[2];
hp[6] = makePTR(hp+0);
hp[7] = makeCTR(C_Nothing);
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makePTR(hp+3);
hp[11] = getPTR(L_sp[-5])[4];
hp[12] = makeHDR(5);
hp[13] = makeFUN(&&F_sift);
hp[14] = getPTR(L_sp[-5])[2];
hp[15] = getPTR(L_sp[-5])[3];
hp[16] = makePTR(hp+8);
hp[17] = getPTR(L_sp[-4])[3];
atom = makePTR(hp+12);
hp += 18;
L_POP(5);
L_PUSH(atom);
goto F_sift;
}
}
}
}
F_sift___0:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1364;
  goto GC_COLLECT;
}
  GC_RET_1364:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_1365;
goto EVAL;
LABEL_1365:
switch (res) {
case C_Pair:
atom = getPTR(L_sp[-1])[2];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
}
F_fwdFun:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1366;
  goto GC_COLLECT;
}
  GC_RET_1366:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_1367;
goto EVAL;
LABEL_1367:
switch (res) {
case C_White:
L_POP(2);
L_PUSH(makeINT(1));
res = 1;
goto EVAL_RET;
case C_Black:
L_POP(2);
L_PUSH(makeINT(-1));
res = -1;
goto EVAL_RET;
}
F_mov2Fun:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1368;
  goto GC_COLLECT;
}
  GC_RET_1368:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_secondRank);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-1])[3];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_1369;
goto EVAL;
LABEL_1369:
switch (res) {
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_pieceAt);
hp[2] = getPTR(L_sp[-2])[4];
hp[3] = getPTR(L_sp[-2])[5];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_1370;
goto EVAL;
LABEL_1370:
switch (res) {
case C_Nothing:
hp[0] = makeHDR(4);
hp[1] = makeCTR(C_Move);
hp[2] = getPTR(L_sp[-3])[5];
hp[3] = makeCTR(C_Nothing);
hp[4] = makeCTR(C_Nothing);
hp[5] = makeHDR(3);
hp[6] = makeCTR(C_Cons);
hp[7] = makePTR(hp+0);
hp[8] = makeCTR(C_Nil);
atom = makePTR(hp+5);
hp += 9;
L_POP(3);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
case C_Just:
L_POP(3);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
}
case C_False:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
}
F_movsFun:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1372;
  goto GC_COLLECT;
}
  GC_RET_1372:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_pieceAt);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-1])[3];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_1373;
goto EVAL;
LABEL_1373:
switch (res) {
case C_Nothing:
hp[0] = makeHDR(4);
hp[1] = makeFUN(&&F_promote);
hp[2] = getPTR(L_sp[-2])[4];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = makeCTR(C_Nothing);
hp[5] = makeHDR(3);
hp[6] = makeFUN(&&F_append);
hp[7] = makePTR(hp+0);
hp[8] = getPTR(L_sp[-2])[5];
atom = makePTR(hp+5);
hp += 9;
L_POP(2);
L_PUSH(atom);
goto F_append;
case C_Just:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
}
F_pawnmoves:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1375;
  goto GC_COLLECT;
}
  GC_RET_1375:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_1376;
goto EVAL;
LABEL_1376:
switch (res) {
case C_Pair:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_pawnmoves___0);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = makeHDR(3);
hp[4] = makeFUN(&&P_ADD);
hp[5] = getPTR(L_sp[-1])[3];
hp[6] = makePTR(hp+0);
hp[7] = makeHDR(3);
hp[8] = makeCTR(C_Pair);
hp[9] = getPTR(L_sp[-1])[2];
hp[10] = makePTR(hp+3);
hp[11] = makeHDR(3);
hp[12] = makeFUN(&&P_ADD);
hp[13] = getPTR(L_sp[-1])[3];
hp[14] = makePTR(hp+0);
hp[15] = makeHDR(3);
hp[16] = makeFUN(&&P_ADD);
hp[17] = makePTR(hp+11);
hp[18] = makePTR(hp+0);
hp[19] = makeHDR(3);
hp[20] = makeCTR(C_Pair);
hp[21] = getPTR(L_sp[-1])[2];
hp[22] = makePTR(hp+15);
hp[23] = makeHDR(5);
hp[24] = makeFUN(&&F_mov2Fun);
hp[25] = getPTR(L_sp[-2])[2];
hp[26] = getPTR(L_sp[-1])[3];
hp[27] = getPTR(L_sp[-2])[4];
hp[28] = makePTR(hp+19);
hp[29] = makeHDR(5);
hp[30] = makeFUN(&&F_movsFun);
hp[31] = getPTR(L_sp[-2])[4];
hp[32] = makePTR(hp+7);
hp[33] = getPTR(L_sp[-2])[2];
hp[34] = makePTR(hp+23);
hp[35] = makeHDR(3);
hp[36] = makeFUN(&&P_ADD);
hp[37] = getPTR(L_sp[-1])[2];
hp[38] = makeINT(1);
hp[39] = makeHDR(3);
hp[40] = makeFUN(&&P_ADD);
hp[41] = getPTR(L_sp[-1])[3];
hp[42] = makePTR(hp+0);
hp[43] = makeHDR(3);
hp[44] = makeCTR(C_Pair);
hp[45] = makePTR(hp+35);
hp[46] = makePTR(hp+39);
hp[47] = makeHDR(4);
hp[48] = makeFUN(&&F_promoteCap);
hp[49] = getPTR(L_sp[-2])[2];
hp[50] = makePTR(hp+43);
hp[51] = getPTR(L_sp[-2])[4];
hp[52] = makeHDR(3);
hp[53] = makeFUN(&&P_SUB);
hp[54] = getPTR(L_sp[-1])[2];
hp[55] = makeINT(1);
hp[56] = makeHDR(3);
hp[57] = makeFUN(&&P_ADD);
hp[58] = getPTR(L_sp[-1])[3];
hp[59] = makePTR(hp+0);
hp[60] = makeHDR(3);
hp[61] = makeCTR(C_Pair);
hp[62] = makePTR(hp+52);
hp[63] = makePTR(hp+56);
hp[64] = makeHDR(4);
hp[65] = makeFUN(&&F_promoteCap);
hp[66] = getPTR(L_sp[-2])[2];
hp[67] = makePTR(hp+60);
hp[68] = getPTR(L_sp[-2])[4];
hp[69] = makeHDR(3);
hp[70] = makeFUN(&&F_append);
hp[71] = makePTR(hp+47);
hp[72] = makePTR(hp+64);
hp[73] = makeHDR(3);
hp[74] = makeFUN(&&F_append);
hp[75] = makePTR(hp+29);
hp[76] = makePTR(hp+69);
atom = makePTR(hp+73);
hp += 77;
L_POP(2);
L_PUSH(atom);
goto F_append;
}
F_pawnmoves___0:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1393;
  goto GC_COLLECT;
}
  GC_RET_1393:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_1394;
goto EVAL;
LABEL_1394:
switch (res) {
case C_White:
L_POP(2);
L_PUSH(makeINT(1));
res = 1;
goto EVAL_RET;
case C_Black:
L_POP(2);
L_PUSH(makeINT(-1));
res = -1;
goto EVAL_RET;
}
F_promoteCap:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1395;
  goto GC_COLLECT;
}
  GC_RET_1395:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_pieceAt);
hp[2] = getPTR(L_sp[-1])[4];
hp[3] = getPTR(L_sp[-1])[3];
hp[4] = makeHDR(4);
hp[5] = makeFUN(&&F_promoteCap___0);
hp[6] = makePTR(hp+0);
hp[7] = getPTR(L_sp[-1])[2];
hp[8] = getPTR(L_sp[-1])[3];
atom = makePTR(hp+4);
hp += 9;
L_POP(1);
L_PUSH(atom);
goto F_promoteCap___0;
F_promoteCap___1:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1396;
  goto GC_COLLECT;
}
  GC_RET_1396:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_1397;
goto EVAL;
LABEL_1397:
switch (res) {
case C_Pair:
atom = getPTR(L_sp[-1])[2];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
}
F_promoteCap___0:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1398;
  goto GC_COLLECT;
}
  GC_RET_1398:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_1399;
goto EVAL;
LABEL_1399:
switch (res) {
case C_Nothing:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Just:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_promoteCap___1);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = makeHDR(3);
hp[4] = makeFUN(&&F_sameColour);
hp[5] = makePTR(hp+0);
hp[6] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+3);
hp += 7;
eval_ret_addr = &&LABEL_1401;
goto EVAL;
LABEL_1401:
switch (res) {
case C_False:
hp[0] = makeHDR(4);
hp[1] = makeFUN(&&F_promote);
hp[2] = getPTR(L_sp[-3])[3];
hp[3] = getPTR(L_sp[-3])[4];
hp[4] = getPTR(L_sp[-3])[2];
atom = makePTR(hp+0);
hp += 5;
L_POP(3);
L_PUSH(atom);
goto F_promote;
case C_True:
L_POP(3);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
}
}
F_mapMove:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1402;
  goto GC_COLLECT;
}
  GC_RET_1402:
atom = getPTR(L_sp[-1])[4];
getPTR(L_sp[-1])[4] = makeINT(0);
eval_ret_addr = &&LABEL_1403;
goto EVAL;
LABEL_1403:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(4);
hp[1] = makeCTR(C_Move);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = getPTR(L_sp[-1])[2];
hp[5] = makeHDR(4);
hp[6] = makeFUN(&&F_mapMove);
hp[7] = getPTR(L_sp[-2])[2];
hp[8] = getPTR(L_sp[-2])[3];
hp[9] = getPTR(L_sp[-1])[3];
hp[10] = makeHDR(3);
hp[11] = makeCTR(C_Cons);
hp[12] = makePTR(hp+0);
hp[13] = makePTR(hp+5);
atom = makePTR(hp+10);
hp += 14;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
F_promote:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1406;
  goto GC_COLLECT;
}
  GC_RET_1406:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_promote___0);
hp[2] = getPTR(L_sp[-1])[3];
hp[3] = makeHDR(3);
hp[4] = makeFUN(&&F_lastRank);
hp[5] = getPTR(L_sp[-1])[2];
hp[6] = makePTR(hp+0);
atom = makePTR(hp+3);
hp += 7;
eval_ret_addr = &&LABEL_1408;
goto EVAL;
LABEL_1408:
switch (res) {
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Pair);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = makeCTR(C_Queen);
hp[4] = makeHDR(2);
hp[5] = makeCTR(C_Just);
hp[6] = makePTR(hp+0);
hp[7] = makeHDR(3);
hp[8] = makeCTR(C_Pair);
hp[9] = getPTR(L_sp[-2])[2];
hp[10] = makeCTR(C_Rook);
hp[11] = makeHDR(2);
hp[12] = makeCTR(C_Just);
hp[13] = makePTR(hp+7);
hp[14] = makeHDR(3);
hp[15] = makeCTR(C_Pair);
hp[16] = getPTR(L_sp[-2])[2];
hp[17] = makeCTR(C_Bishop);
hp[18] = makeHDR(2);
hp[19] = makeCTR(C_Just);
hp[20] = makePTR(hp+14);
hp[21] = makeHDR(3);
hp[22] = makeCTR(C_Pair);
hp[23] = getPTR(L_sp[-2])[2];
hp[24] = makeCTR(C_Knight);
hp[25] = makeHDR(2);
hp[26] = makeCTR(C_Just);
hp[27] = makePTR(hp+21);
hp[28] = makeHDR(3);
hp[29] = makeCTR(C_Cons);
hp[30] = makePTR(hp+25);
hp[31] = makeCTR(C_Nil);
hp[32] = makeHDR(3);
hp[33] = makeCTR(C_Cons);
hp[34] = makePTR(hp+18);
hp[35] = makePTR(hp+28);
hp[36] = makeHDR(3);
hp[37] = makeCTR(C_Cons);
hp[38] = makePTR(hp+11);
hp[39] = makePTR(hp+32);
hp[40] = makeHDR(3);
hp[41] = makeCTR(C_Cons);
hp[42] = makePTR(hp+4);
hp[43] = makePTR(hp+36);
hp[44] = makeHDR(4);
hp[45] = makeFUN(&&F_mapMove);
hp[46] = getPTR(L_sp[-2])[3];
hp[47] = getPTR(L_sp[-2])[4];
hp[48] = makePTR(hp+40);
atom = makePTR(hp+44);
hp += 49;
L_POP(2);
L_PUSH(atom);
goto F_mapMove;
case C_False:
hp[0] = makeHDR(4);
hp[1] = makeCTR(C_Move);
hp[2] = getPTR(L_sp[-2])[3];
hp[3] = getPTR(L_sp[-2])[4];
hp[4] = makeCTR(C_Nothing);
hp[5] = makeHDR(3);
hp[6] = makeCTR(C_Cons);
hp[7] = makePTR(hp+0);
hp[8] = makeCTR(C_Nil);
atom = makePTR(hp+5);
hp += 9;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
F_promote___0:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1422;
  goto GC_COLLECT;
}
  GC_RET_1422:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_1423;
goto EVAL;
LABEL_1423:
switch (res) {
case C_Pair:
atom = getPTR(L_sp[-1])[3];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
}
F_secondRank:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1424;
  goto GC_COLLECT;
}
  GC_RET_1424:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_1425;
goto EVAL;
LABEL_1425:
switch (res) {
case C_White:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_1426;
goto EVAL;
LABEL_1426:
L_PUSH(makeINT(2));
res = 2;
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(3);
L_PUSH(makeCTR(res));
goto EVAL_RET;
case C_Black:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_1427;
goto EVAL;
LABEL_1427:
L_PUSH(makeINT(7));
res = 7;
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(3);
L_PUSH(makeCTR(res));
goto EVAL_RET;
}
F_lastRank:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1428;
  goto GC_COLLECT;
}
  GC_RET_1428:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_1429;
goto EVAL;
LABEL_1429:
switch (res) {
case C_White:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_1430;
goto EVAL;
LABEL_1430:
L_PUSH(makeINT(8));
res = 8;
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(3);
L_PUSH(makeCTR(res));
goto EVAL_RET;
case C_Black:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_1431;
goto EVAL;
LABEL_1431:
L_PUSH(makeINT(1));
res = 1;
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(3);
L_PUSH(makeCTR(res));
goto EVAL_RET;
}
F_queenmoves:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1432;
  goto GC_COLLECT;
}
  GC_RET_1432:
hp[0] = makeHDR(4);
hp[1] = makeFUN(&&F_bishopmoves);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-1])[3];
hp[4] = getPTR(L_sp[-1])[4];
hp[5] = makeHDR(4);
hp[6] = makeFUN(&&F_rookmoves);
hp[7] = getPTR(L_sp[-1])[2];
hp[8] = getPTR(L_sp[-1])[3];
hp[9] = getPTR(L_sp[-1])[4];
hp[10] = makeHDR(3);
hp[11] = makeFUN(&&F_append);
hp[12] = makePTR(hp+0);
hp[13] = makePTR(hp+5);
atom = makePTR(hp+10);
hp += 14;
L_POP(1);
L_PUSH(atom);
goto F_append;
F_kingincheck:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1435;
  goto GC_COLLECT;
}
  GC_RET_1435:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_kingincheck___0);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = makeHDR(3);
hp[4] = makeFUN(&&F_forcesColoured);
hp[5] = makePTR(hp+0);
hp[6] = getPTR(L_sp[-1])[3];
hp[7] = makeHDR(4);
hp[8] = makeFUN(&&F_anyKICF);
hp[9] = getPTR(L_sp[-1])[2];
hp[10] = getPTR(L_sp[-1])[3];
hp[11] = makePTR(hp+3);
atom = makePTR(hp+7);
hp += 12;
L_POP(1);
L_PUSH(atom);
goto F_anyKICF;
F_kingincheck___0:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1438;
  goto GC_COLLECT;
}
  GC_RET_1438:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_1439;
goto EVAL;
LABEL_1439:
switch (res) {
case C_Black:
L_POP(2);
L_PUSH(makeCTR(C_White));
res = C_White;
goto EVAL_RET;
case C_White:
L_POP(2);
L_PUSH(makeCTR(C_Black));
res = C_Black;
goto EVAL_RET;
}
F_kingInCheckFrom:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1440;
  goto GC_COLLECT;
}
  GC_RET_1440:
atom = getPTR(L_sp[-1])[4];
getPTR(L_sp[-1])[4] = makeINT(0);
eval_ret_addr = &&LABEL_1441;
goto EVAL;
LABEL_1441:
switch (res) {
case C_Pair:
atom = getPTR(L_sp[-1])[3];
eval_ret_addr = &&LABEL_1442;
goto EVAL;
LABEL_1442:
switch (res) {
case C_Pair:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_forcesColoured);
hp[2] = getPTR(L_sp[-3])[2];
hp[3] = getPTR(L_sp[-3])[3];
hp[4] = makeHDR(2);
hp[5] = makeFUN(&&F_kSq);
hp[6] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 7;
eval_ret_addr = &&LABEL_1444;
goto EVAL;
LABEL_1444:
switch (res) {
case C_Pair:
atom = getPTR(L_sp[-3])[2];
eval_ret_addr = &&LABEL_1445;
goto EVAL;
LABEL_1445:
switch (res) {
case C_King:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&P_SUB);
hp[2] = getPTR(L_sp[-3])[2];
hp[3] = getPTR(L_sp[-2])[2];
hp[4] = makeHDR(2);
hp[5] = makeFUN(&&F_abs);
hp[6] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 7;
eval_ret_addr = &&LABEL_1447;
goto EVAL;
LABEL_1447:
L_PUSH(makeINT(1));
res = 1;
L_POP(1);
res = getINT(L_top) <= res ? C_True : C_False;
L_POP(1);
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&P_SUB);
hp[2] = getPTR(L_sp[-4])[3];
hp[3] = getPTR(L_sp[-3])[3];
hp[4] = makeHDR(2);
hp[5] = makeFUN(&&F_abs);
hp[6] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 7;
eval_ret_addr = &&LABEL_1449;
goto EVAL;
LABEL_1449:
L_PUSH(makeINT(1));
res = 1;
L_POP(1);
res = getINT(L_top) <= res ? C_True : C_False;
L_POP(7);
L_PUSH(makeCTR(res));
goto EVAL_RET;
case C_False:
L_POP(6);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
}
case C_Queen:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Pair);
hp[2] = getPTR(L_sp[-3])[2];
hp[3] = getPTR(L_sp[-3])[3];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Pair);
hp[6] = makeCTR(C_Rook);
hp[7] = makePTR(hp+0);
hp[8] = makeHDR(4);
hp[9] = makeFUN(&&F_kingInCheckFrom);
hp[10] = getPTR(L_sp[-5])[2];
hp[11] = getPTR(L_sp[-5])[3];
hp[12] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 13;
eval_ret_addr = &&LABEL_1452;
goto EVAL;
LABEL_1452:
switch (res) {
case C_True:
L_POP(6);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
case C_False:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Pair);
hp[2] = getPTR(L_sp[-4])[2];
hp[3] = getPTR(L_sp[-4])[3];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Pair);
hp[6] = makeCTR(C_Bishop);
hp[7] = makePTR(hp+0);
hp[8] = makeHDR(4);
hp[9] = makeFUN(&&F_kingInCheckFrom);
hp[10] = getPTR(L_sp[-6])[2];
hp[11] = getPTR(L_sp[-6])[3];
hp[12] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 13;
L_POP(6);
L_PUSH(atom);
goto F_kingInCheckFrom;
}
case C_Rook:
atom = getPTR(L_sp[-3])[2];
eval_ret_addr = &&LABEL_1455;
goto EVAL;
LABEL_1455:
atom = getPTR(L_sp[-3])[2];
eval_ret_addr = &&LABEL_1456;
goto EVAL;
LABEL_1456:
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(1);
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
hp[0] = makeHDR(5);
hp[1] = makeFUN(&&F_emptyAtAllFP);
hp[2] = getPTR(L_sp[-3])[2];
hp[3] = getPTR(L_sp[-4])[3];
hp[4] = getPTR(L_sp[-3])[3];
hp[5] = getPTR(L_sp[-6])[3];
atom = makePTR(hp+0);
hp += 6;
eval_ret_addr = &&LABEL_1457;
goto EVAL;
LABEL_1457:
switch (res) {
case C_True:
L_POP(7);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
case C_False:
atom = getPTR(L_sp[-5])[3];
eval_ret_addr = &&LABEL_1458;
goto EVAL;
LABEL_1458:
atom = getPTR(L_sp[-5])[3];
eval_ret_addr = &&LABEL_1459;
goto EVAL;
LABEL_1459:
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(1);
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
hp[0] = makeHDR(5);
hp[1] = makeFUN(&&F_emptyAtAllRP);
hp[2] = getPTR(L_sp[-5])[3];
hp[3] = getPTR(L_sp[-6])[2];
hp[4] = getPTR(L_sp[-5])[2];
hp[5] = getPTR(L_sp[-8])[3];
atom = makePTR(hp+0);
hp += 6;
L_POP(8);
L_PUSH(atom);
goto F_emptyAtAllRP;
case C_False:
L_POP(8);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
}
}
case C_False:
atom = getPTR(L_sp[-4])[3];
eval_ret_addr = &&LABEL_1460;
goto EVAL;
LABEL_1460:
atom = getPTR(L_sp[-4])[3];
eval_ret_addr = &&LABEL_1461;
goto EVAL;
LABEL_1461:
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(1);
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
hp[0] = makeHDR(5);
hp[1] = makeFUN(&&F_emptyAtAllRP);
hp[2] = getPTR(L_sp[-4])[3];
hp[3] = getPTR(L_sp[-5])[2];
hp[4] = getPTR(L_sp[-4])[2];
hp[5] = getPTR(L_sp[-7])[3];
atom = makePTR(hp+0);
hp += 6;
L_POP(7);
L_PUSH(atom);
goto F_emptyAtAllRP;
case C_False:
L_POP(7);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
}
}
case C_Bishop:
atom = getPTR(L_sp[-3])[2];
eval_ret_addr = &&LABEL_1462;
goto EVAL;
LABEL_1462:
atom = getPTR(L_sp[-4])[3];
eval_ret_addr = &&LABEL_1463;
goto EVAL;
LABEL_1463:
L_POP(1);
res = getINT(L_top) - res;
L_POP(1);
L_PUSH(makeINT(res));
atom = getPTR(L_sp[-3])[2];
eval_ret_addr = &&LABEL_1464;
goto EVAL;
LABEL_1464:
atom = getPTR(L_sp[-4])[3];
eval_ret_addr = &&LABEL_1465;
goto EVAL;
LABEL_1465:
L_POP(1);
res = getINT(L_top) - res;
L_POP(1);
L_PUSH(makeINT(res));
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(1);
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&P_SUB);
hp[2] = getPTR(L_sp[-3])[2];
hp[3] = getPTR(L_sp[-3])[3];
hp[4] = makeHDR(6);
hp[5] = makeFUN(&&F_emptyAtAllDP);
hp[6] = makeCTR(C_Minus);
hp[7] = makePTR(hp+0);
hp[8] = getPTR(L_sp[-4])[2];
hp[9] = getPTR(L_sp[-3])[2];
hp[10] = getPTR(L_sp[-6])[3];
atom = makePTR(hp+4);
hp += 11;
eval_ret_addr = &&LABEL_1467;
goto EVAL;
LABEL_1467:
switch (res) {
case C_True:
L_POP(7);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
case C_False:
atom = getPTR(L_sp[-5])[2];
eval_ret_addr = &&LABEL_1468;
goto EVAL;
LABEL_1468:
atom = getPTR(L_sp[-6])[3];
eval_ret_addr = &&LABEL_1469;
goto EVAL;
LABEL_1469:
L_POP(1);
res = getINT(L_top) + res;
L_POP(1);
L_PUSH(makeINT(res));
atom = getPTR(L_sp[-5])[2];
eval_ret_addr = &&LABEL_1470;
goto EVAL;
LABEL_1470:
atom = getPTR(L_sp[-6])[3];
eval_ret_addr = &&LABEL_1471;
goto EVAL;
LABEL_1471:
L_POP(1);
res = getINT(L_top) + res;
L_POP(1);
L_PUSH(makeINT(res));
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(1);
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&P_ADD);
hp[2] = getPTR(L_sp[-5])[2];
hp[3] = getPTR(L_sp[-5])[3];
hp[4] = makeHDR(6);
hp[5] = makeFUN(&&F_emptyAtAllDP);
hp[6] = makeCTR(C_Plus);
hp[7] = makePTR(hp+0);
hp[8] = getPTR(L_sp[-6])[2];
hp[9] = getPTR(L_sp[-5])[2];
hp[10] = getPTR(L_sp[-8])[3];
atom = makePTR(hp+4);
hp += 11;
L_POP(8);
L_PUSH(atom);
goto F_emptyAtAllDP;
case C_False:
L_POP(8);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
}
}
case C_False:
atom = getPTR(L_sp[-4])[2];
eval_ret_addr = &&LABEL_1473;
goto EVAL;
LABEL_1473:
atom = getPTR(L_sp[-5])[3];
eval_ret_addr = &&LABEL_1474;
goto EVAL;
LABEL_1474:
L_POP(1);
res = getINT(L_top) + res;
L_POP(1);
L_PUSH(makeINT(res));
atom = getPTR(L_sp[-4])[2];
eval_ret_addr = &&LABEL_1475;
goto EVAL;
LABEL_1475:
atom = getPTR(L_sp[-5])[3];
eval_ret_addr = &&LABEL_1476;
goto EVAL;
LABEL_1476:
L_POP(1);
res = getINT(L_top) + res;
L_POP(1);
L_PUSH(makeINT(res));
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(1);
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&P_ADD);
hp[2] = getPTR(L_sp[-4])[2];
hp[3] = getPTR(L_sp[-4])[3];
hp[4] = makeHDR(6);
hp[5] = makeFUN(&&F_emptyAtAllDP);
hp[6] = makeCTR(C_Plus);
hp[7] = makePTR(hp+0);
hp[8] = getPTR(L_sp[-5])[2];
hp[9] = getPTR(L_sp[-4])[2];
hp[10] = getPTR(L_sp[-7])[3];
atom = makePTR(hp+4);
hp += 11;
L_POP(7);
L_PUSH(atom);
goto F_emptyAtAllDP;
case C_False:
L_POP(7);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
}
}
case C_Knight:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&P_SUB);
hp[2] = getPTR(L_sp[-3])[2];
hp[3] = getPTR(L_sp[-2])[2];
hp[4] = makeHDR(2);
hp[5] = makeFUN(&&F_abs);
hp[6] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 7;
eval_ret_addr = &&LABEL_1479;
goto EVAL;
LABEL_1479:
L_PUSH(makeINT(2));
res = 2;
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(1);
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&P_SUB);
hp[2] = getPTR(L_sp[-4])[3];
hp[3] = getPTR(L_sp[-3])[3];
hp[4] = makeHDR(2);
hp[5] = makeFUN(&&F_abs);
hp[6] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 7;
eval_ret_addr = &&LABEL_1481;
goto EVAL;
LABEL_1481:
L_PUSH(makeINT(1));
res = 1;
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(1);
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
L_POP(7);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
case C_False:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&P_SUB);
hp[2] = getPTR(L_sp[-5])[2];
hp[3] = getPTR(L_sp[-4])[2];
hp[4] = makeHDR(2);
hp[5] = makeFUN(&&F_abs);
hp[6] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 7;
eval_ret_addr = &&LABEL_1483;
goto EVAL;
LABEL_1483:
L_PUSH(makeINT(1));
res = 1;
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(1);
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&P_SUB);
hp[2] = getPTR(L_sp[-6])[3];
hp[3] = getPTR(L_sp[-5])[3];
hp[4] = makeHDR(2);
hp[5] = makeFUN(&&F_abs);
hp[6] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 7;
eval_ret_addr = &&LABEL_1485;
goto EVAL;
LABEL_1485:
L_PUSH(makeINT(2));
res = 2;
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(9);
L_PUSH(makeCTR(res));
goto EVAL_RET;
case C_False:
L_POP(8);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
}
}
case C_False:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&P_SUB);
hp[2] = getPTR(L_sp[-4])[2];
hp[3] = getPTR(L_sp[-3])[2];
hp[4] = makeHDR(2);
hp[5] = makeFUN(&&F_abs);
hp[6] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 7;
eval_ret_addr = &&LABEL_1487;
goto EVAL;
LABEL_1487:
L_PUSH(makeINT(1));
res = 1;
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(1);
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&P_SUB);
hp[2] = getPTR(L_sp[-5])[3];
hp[3] = getPTR(L_sp[-4])[3];
hp[4] = makeHDR(2);
hp[5] = makeFUN(&&F_abs);
hp[6] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 7;
eval_ret_addr = &&LABEL_1489;
goto EVAL;
LABEL_1489:
L_PUSH(makeINT(2));
res = 2;
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(8);
L_PUSH(makeCTR(res));
goto EVAL_RET;
case C_False:
L_POP(7);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
}
}
case C_Pawn:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&P_SUB);
hp[2] = getPTR(L_sp[-3])[2];
hp[3] = getPTR(L_sp[-2])[2];
hp[4] = makeHDR(2);
hp[5] = makeFUN(&&F_abs);
hp[6] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 7;
eval_ret_addr = &&LABEL_1491;
goto EVAL;
LABEL_1491:
L_PUSH(makeINT(1));
res = 1;
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(1);
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
atom = getPTR(L_sp[-3])[3];
eval_ret_addr = &&LABEL_1492;
goto EVAL;
LABEL_1492:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_onFor);
hp[2] = getPTR(L_sp[-7])[2];
hp[3] = getPTR(L_sp[-5])[3];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_1493;
goto EVAL;
LABEL_1493:
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(7);
L_PUSH(makeCTR(res));
goto EVAL_RET;
case C_False:
L_POP(6);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
}
}
}
}
}
F_onFor:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1494;
  goto GC_COLLECT;
}
  GC_RET_1494:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_1495;
goto EVAL;
LABEL_1495:
switch (res) {
case C_Black:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_1496;
goto EVAL;
LABEL_1496:
L_PUSH(makeINT(1));
res = 1;
L_POP(1);
res = getINT(L_top) + res;
L_POP(3);
L_PUSH(makeINT(res));
goto EVAL_RET;
case C_White:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_1497;
goto EVAL;
LABEL_1497:
L_PUSH(makeINT(1));
res = 1;
L_POP(1);
res = getINT(L_top) - res;
L_POP(3);
L_PUSH(makeINT(res));
goto EVAL_RET;
}
F_filePath:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1498;
  goto GC_COLLECT;
}
  GC_RET_1498:
atom = getPTR(L_sp[-1])[5];
getPTR(L_sp[-1])[5] = makeINT(0);
eval_ret_addr = &&LABEL_1499;
goto EVAL;
LABEL_1499:
switch (res) {
case C_Pair:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_1500;
goto EVAL;
LABEL_1500:
atom = getPTR(L_sp[-3])[2];
eval_ret_addr = &&LABEL_1501;
goto EVAL;
LABEL_1501:
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(1);
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_min);
hp[2] = getPTR(L_sp[-3])[3];
hp[3] = getPTR(L_sp[-3])[4];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_1502;
goto EVAL;
LABEL_1502:
L_PUSH(makeINT(1));
res = 1;
L_POP(1);
res = getINT(L_top) + res;
L_POP(1);
L_PUSH(makeINT(res));
atom = getPTR(L_sp[-3])[3];
eval_ret_addr = &&LABEL_1503;
goto EVAL;
LABEL_1503:
L_POP(1);
res = getINT(L_top) <= res ? C_True : C_False;
L_POP(1);
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
atom = getPTR(L_sp[-3])[3];
eval_ret_addr = &&LABEL_1504;
goto EVAL;
LABEL_1504:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_max);
hp[2] = getPTR(L_sp[-5])[3];
hp[3] = getPTR(L_sp[-5])[4];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_1505;
goto EVAL;
LABEL_1505:
L_PUSH(makeINT(1));
res = 1;
L_POP(1);
res = getINT(L_top) - res;
L_POP(1);
L_PUSH(makeINT(res));
L_POP(1);
res = getINT(L_top) <= res ? C_True : C_False;
L_POP(5);
L_PUSH(makeCTR(res));
goto EVAL_RET;
case C_False:
L_POP(4);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
}
case C_False:
L_POP(3);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
}
}
F_rankPath:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1506;
  goto GC_COLLECT;
}
  GC_RET_1506:
atom = getPTR(L_sp[-1])[5];
getPTR(L_sp[-1])[5] = makeINT(0);
eval_ret_addr = &&LABEL_1507;
goto EVAL;
LABEL_1507:
switch (res) {
case C_Pair:
atom = getPTR(L_sp[-1])[3];
eval_ret_addr = &&LABEL_1508;
goto EVAL;
LABEL_1508:
atom = getPTR(L_sp[-3])[2];
eval_ret_addr = &&LABEL_1509;
goto EVAL;
LABEL_1509:
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(1);
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_min);
hp[2] = getPTR(L_sp[-3])[3];
hp[3] = getPTR(L_sp[-3])[4];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_1510;
goto EVAL;
LABEL_1510:
L_PUSH(makeINT(1));
res = 1;
L_POP(1);
res = getINT(L_top) + res;
L_POP(1);
L_PUSH(makeINT(res));
atom = getPTR(L_sp[-3])[2];
eval_ret_addr = &&LABEL_1511;
goto EVAL;
LABEL_1511:
L_POP(1);
res = getINT(L_top) <= res ? C_True : C_False;
L_POP(1);
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
atom = getPTR(L_sp[-3])[2];
eval_ret_addr = &&LABEL_1512;
goto EVAL;
LABEL_1512:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_max);
hp[2] = getPTR(L_sp[-5])[3];
hp[3] = getPTR(L_sp[-5])[4];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_1513;
goto EVAL;
LABEL_1513:
L_PUSH(makeINT(1));
res = 1;
L_POP(1);
res = getINT(L_top) - res;
L_POP(1);
L_PUSH(makeINT(res));
L_POP(1);
res = getINT(L_top) <= res ? C_True : C_False;
L_POP(5);
L_PUSH(makeCTR(res));
goto EVAL_RET;
case C_False:
L_POP(4);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
}
case C_False:
L_POP(3);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
}
}
F_apply:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1514;
  goto GC_COLLECT;
}
  GC_RET_1514:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_1515;
goto EVAL;
LABEL_1515:
switch (res) {
case C_Plus:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_1516;
goto EVAL;
LABEL_1516:
atom = getPTR(L_sp[-3])[4];
eval_ret_addr = &&LABEL_1517;
goto EVAL;
LABEL_1517:
L_POP(1);
res = getINT(L_top) + res;
L_POP(3);
L_PUSH(makeINT(res));
goto EVAL_RET;
case C_Minus:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_1518;
goto EVAL;
LABEL_1518:
atom = getPTR(L_sp[-3])[4];
eval_ret_addr = &&LABEL_1519;
goto EVAL;
LABEL_1519:
L_POP(1);
res = getINT(L_top) - res;
L_POP(3);
L_PUSH(makeINT(res));
goto EVAL_RET;
}
F_diagPath:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1520;
  goto GC_COLLECT;
}
  GC_RET_1520:
atom = getPTR(L_sp[-1])[6];
getPTR(L_sp[-1])[6] = makeINT(0);
eval_ret_addr = &&LABEL_1521;
goto EVAL;
LABEL_1521:
switch (res) {
case C_Pair:
hp[0] = makeHDR(4);
hp[1] = makeFUN(&&F_apply);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = getPTR(L_sp[-1])[3];
atom = makePTR(hp+0);
hp += 5;
eval_ret_addr = &&LABEL_1522;
goto EVAL;
LABEL_1522:
atom = getPTR(L_sp[-3])[3];
eval_ret_addr = &&LABEL_1523;
goto EVAL;
LABEL_1523:
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(1);
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_min);
hp[2] = getPTR(L_sp[-3])[4];
hp[3] = getPTR(L_sp[-3])[5];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_1524;
goto EVAL;
LABEL_1524:
L_PUSH(makeINT(1));
res = 1;
L_POP(1);
res = getINT(L_top) + res;
L_POP(1);
L_PUSH(makeINT(res));
atom = getPTR(L_sp[-3])[2];
eval_ret_addr = &&LABEL_1525;
goto EVAL;
LABEL_1525:
L_POP(1);
res = getINT(L_top) <= res ? C_True : C_False;
L_POP(1);
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
atom = getPTR(L_sp[-3])[2];
eval_ret_addr = &&LABEL_1526;
goto EVAL;
LABEL_1526:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_max);
hp[2] = getPTR(L_sp[-5])[4];
hp[3] = getPTR(L_sp[-5])[5];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_1527;
goto EVAL;
LABEL_1527:
L_PUSH(makeINT(1));
res = 1;
L_POP(1);
res = getINT(L_top) - res;
L_POP(1);
L_PUSH(makeINT(res));
L_POP(1);
res = getINT(L_top) <= res ? C_True : C_False;
L_POP(5);
L_PUSH(makeCTR(res));
goto EVAL_RET;
case C_False:
L_POP(4);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
}
case C_False:
L_POP(3);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
}
}
F_solve:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1528;
  goto GC_COLLECT;
}
  GC_RET_1528:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&P_ADD);
hp[2] = getPTR(L_sp[-1])[4];
hp[3] = getPTR(L_sp[-1])[4];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&P_SUB);
hp[6] = makePTR(hp+0);
hp[7] = makeINT(1);
hp[8] = makeHDR(4);
hp[9] = makeFUN(&&F_solution);
hp[10] = getPTR(L_sp[-1])[2];
hp[11] = getPTR(L_sp[-1])[3];
hp[12] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 13;
eval_ret_addr = &&LABEL_1531;
goto EVAL;
LABEL_1531:
switch (res) {
case C_Nothing:
L_POP(2);
L_PUSH(makeINT(0));
res = 0;
goto EVAL_RET;
case C_Just:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_size);
hp[2] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+0);
hp += 3;
L_POP(2);
L_PUSH(atom);
goto F_size;
}
F_foldrSO:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1532;
  goto GC_COLLECT;
}
  GC_RET_1532:
atom = getPTR(L_sp[-1])[4];
getPTR(L_sp[-1])[4] = makeINT(0);
eval_ret_addr = &&LABEL_1533;
goto EVAL;
LABEL_1533:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nothing));
res = C_Nothing;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(4);
hp[1] = makeFUN(&&F_foldrSO);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = getPTR(L_sp[-1])[3];
hp[5] = makeHDR(5);
hp[6] = makeFUN(&&F_solnOr);
hp[7] = getPTR(L_sp[-2])[2];
hp[8] = getPTR(L_sp[-2])[3];
hp[9] = getPTR(L_sp[-1])[2];
hp[10] = makePTR(hp+0);
atom = makePTR(hp+5);
hp += 11;
L_POP(2);
L_PUSH(atom);
goto F_solnOr;
}
F_solution:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1535;
  goto GC_COLLECT;
}
  GC_RET_1535:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_moveDetailsFor);
hp[2] = getPTR(L_sp[-1])[3];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(4);
hp[5] = makeFUN(&&F_foldrSO);
hp[6] = getPTR(L_sp[-1])[3];
hp[7] = getPTR(L_sp[-1])[4];
hp[8] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 9;
L_POP(1);
L_PUSH(atom);
goto F_foldrSO;
F_solnOr:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1537;
  goto GC_COLLECT;
}
  GC_RET_1537:
atom = getPTR(L_sp[-1])[4];
getPTR(L_sp[-1])[4] = makeINT(0);
eval_ret_addr = &&LABEL_1538;
goto EVAL;
LABEL_1538:
switch (res) {
case C_Pair:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_solnOr___0);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = makeHDR(3);
hp[4] = makeFUN(&&P_SUB);
hp[5] = getPTR(L_sp[-2])[3];
hp[6] = makeINT(1);
hp[7] = makeHDR(4);
hp[8] = makeFUN(&&F_replies);
hp[9] = getPTR(L_sp[-1])[3];
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+3);
atom = makePTR(hp+7);
hp += 12;
eval_ret_addr = &&LABEL_1541;
goto EVAL;
LABEL_1541:
switch (res) {
case C_Nothing:
atom = getPTR(L_sp[-3])[5];
L_POP(3);
goto TAIL_EVAL;
goto EVAL_RET;
case C_Just:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_1542;
goto EVAL;
LABEL_1542:
switch (res) {
case C_Nil:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_solnOr___1);
hp[2] = getPTR(L_sp[-4])[2];
hp[3] = makeHDR(3);
hp[4] = makeFUN(&&F_kingincheck);
hp[5] = makePTR(hp+0);
hp[6] = getPTR(L_sp[-3])[3];
atom = makePTR(hp+3);
hp += 7;
eval_ret_addr = &&LABEL_1544;
goto EVAL;
LABEL_1544:
switch (res) {
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Solution);
hp[2] = getPTR(L_sp[-4])[2];
hp[3] = makeCTR(C_Nil);
hp[4] = makeHDR(2);
hp[5] = makeCTR(C_Just);
hp[6] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 7;
L_POP(5);
L_PUSH(atom);
res = C_Just;
goto EVAL_RET;
case C_False:
atom = getPTR(L_sp[-5])[5];
L_POP(5);
goto TAIL_EVAL;
goto EVAL_RET;
}
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Solution);
hp[2] = getPTR(L_sp[-3])[2];
hp[3] = getPTR(L_sp[-2])[2];
hp[4] = makeHDR(2);
hp[5] = makeCTR(C_Just);
hp[6] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 7;
L_POP(4);
L_PUSH(atom);
res = C_Just;
goto EVAL_RET;
}
}
}
F_solnOr___0:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1547;
  goto GC_COLLECT;
}
  GC_RET_1547:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_1548;
goto EVAL;
LABEL_1548:
switch (res) {
case C_Black:
L_POP(2);
L_PUSH(makeCTR(C_White));
res = C_White;
goto EVAL_RET;
case C_White:
L_POP(2);
L_PUSH(makeCTR(C_Black));
res = C_Black;
goto EVAL_RET;
}
F_solnOr___1:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1549;
  goto GC_COLLECT;
}
  GC_RET_1549:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_1550;
goto EVAL;
LABEL_1550:
switch (res) {
case C_Black:
L_POP(2);
L_PUSH(makeCTR(C_White));
res = C_White;
goto EVAL_RET;
case C_White:
L_POP(2);
L_PUSH(makeCTR(C_Black));
res = C_Black;
goto EVAL_RET;
}
F_foldrSA:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1551;
  goto GC_COLLECT;
}
  GC_RET_1551:
atom = getPTR(L_sp[-1])[4];
getPTR(L_sp[-1])[4] = makeINT(0);
eval_ret_addr = &&LABEL_1552;
goto EVAL;
LABEL_1552:
switch (res) {
case C_Nil:
hp[0] = makeHDR(2);
hp[1] = makeCTR(C_Just);
hp[2] = makeCTR(C_Nil);
atom = makePTR(hp+0);
hp += 3;
L_POP(2);
L_PUSH(atom);
res = C_Just;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(4);
hp[1] = makeFUN(&&F_foldrSA);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = getPTR(L_sp[-1])[3];
hp[5] = makeHDR(5);
hp[6] = makeFUN(&&F_solnAnd);
hp[7] = getPTR(L_sp[-2])[2];
hp[8] = getPTR(L_sp[-2])[3];
hp[9] = getPTR(L_sp[-1])[2];
hp[10] = makePTR(hp+0);
atom = makePTR(hp+5);
hp += 11;
L_POP(2);
L_PUSH(atom);
goto F_solnAnd;
}
F_replies:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1554;
  goto GC_COLLECT;
}
  GC_RET_1554:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_moveDetailsFor);
hp[2] = getPTR(L_sp[-1])[3];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(4);
hp[5] = makeFUN(&&F_replies___0);
hp[6] = getPTR(L_sp[-1])[4];
hp[7] = makePTR(hp+0);
hp[8] = getPTR(L_sp[-1])[3];
atom = makePTR(hp+4);
hp += 9;
L_POP(1);
L_PUSH(atom);
goto F_replies___0;
F_replies___0:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1555;
  goto GC_COLLECT;
}
  GC_RET_1555:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_1556;
goto EVAL;
LABEL_1556:
L_PUSH(makeINT(0));
res = 0;
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(1);
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
atom = getPTR(L_sp[-2])[3];
getPTR(L_sp[-2])[3] = makeINT(0);
eval_ret_addr = &&LABEL_1557;
goto EVAL;
LABEL_1557:
switch (res) {
case C_Nil:
hp[0] = makeHDR(2);
hp[1] = makeCTR(C_Just);
hp[2] = makeCTR(C_Nil);
atom = makePTR(hp+0);
hp += 3;
L_POP(3);
L_PUSH(atom);
res = C_Just;
goto EVAL_RET;
case C_Cons:
L_POP(3);
L_PUSH(makeCTR(C_Nothing));
res = C_Nothing;
goto EVAL_RET;
}
case C_False:
hp[0] = makeHDR(4);
hp[1] = makeFUN(&&F_foldrSA);
hp[2] = getPTR(L_sp[-2])[4];
hp[3] = getPTR(L_sp[-2])[2];
hp[4] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+0);
hp += 5;
L_POP(2);
L_PUSH(atom);
goto F_foldrSA;
}
F_solnAnd:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1558;
  goto GC_COLLECT;
}
  GC_RET_1558:
atom = getPTR(L_sp[-1])[4];
getPTR(L_sp[-1])[4] = makeINT(0);
eval_ret_addr = &&LABEL_1559;
goto EVAL;
LABEL_1559:
switch (res) {
case C_Pair:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_solnAnd___0);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = makeHDR(3);
hp[4] = makeFUN(&&P_SUB);
hp[5] = getPTR(L_sp[-2])[3];
hp[6] = makeINT(1);
hp[7] = makeHDR(4);
hp[8] = makeFUN(&&F_solution);
hp[9] = getPTR(L_sp[-1])[3];
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+3);
atom = makePTR(hp+7);
hp += 12;
eval_ret_addr = &&LABEL_1562;
goto EVAL;
LABEL_1562:
switch (res) {
case C_Nothing:
L_POP(3);
L_PUSH(makeCTR(C_Nothing));
res = C_Nothing;
goto EVAL_RET;
case C_Just:
atom = getPTR(L_sp[-3])[5];
getPTR(L_sp[-3])[5] = makeINT(0);
eval_ret_addr = &&LABEL_1563;
goto EVAL;
LABEL_1563:
switch (res) {
case C_Nothing:
L_POP(4);
L_PUSH(makeCTR(C_Nothing));
res = C_Nothing;
goto EVAL_RET;
case C_Just:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Pair);
hp[2] = getPTR(L_sp[-3])[2];
hp[3] = getPTR(L_sp[-2])[2];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = makePTR(hp+0);
hp[7] = getPTR(L_sp[-1])[2];
hp[8] = makeHDR(2);
hp[9] = makeCTR(C_Just);
hp[10] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 11;
L_POP(4);
L_PUSH(atom);
res = C_Just;
goto EVAL_RET;
}
}
}
F_solnAnd___0:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1566;
  goto GC_COLLECT;
}
  GC_RET_1566:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_1567;
goto EVAL;
LABEL_1567:
switch (res) {
case C_Black:
L_POP(2);
L_PUSH(makeCTR(C_White));
res = C_White;
goto EVAL_RET;
case C_White:
L_POP(2);
L_PUSH(makeCTR(C_Black));
res = C_Black;
goto EVAL_RET;
}
F_showResult:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1568;
  goto GC_COLLECT;
}
  GC_RET_1568:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_1569;
goto EVAL;
LABEL_1569:
switch (res) {
case C_Nothing:
L_POP(2);
L_PUSH(makeINT(0));
res = 0;
goto EVAL_RET;
case C_Just:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_size);
hp[2] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+0);
hp += 3;
L_POP(2);
L_PUSH(atom);
goto F_size;
}
F_mapSize:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1570;
  goto GC_COLLECT;
}
  GC_RET_1570:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_1571;
goto EVAL;
LABEL_1571:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_size);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = makeHDR(2);
hp[4] = makeFUN(&&F_mapSize);
hp[5] = getPTR(L_sp[-1])[3];
hp[6] = makeHDR(3);
hp[7] = makeCTR(C_Cons);
hp[8] = makePTR(hp+0);
hp[9] = makePTR(hp+3);
atom = makePTR(hp+6);
hp += 10;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
F_size:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1574;
  goto GC_COLLECT;
}
  GC_RET_1574:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_1575;
goto EVAL;
LABEL_1575:
switch (res) {
case C_Solution:
L_PUSH(makeINT(1));
res = 1;
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_size___0);
hp[2] = getPTR(L_sp[-2])[3];
hp[3] = makeHDR(2);
hp[4] = makeFUN(&&F_mapSize);
hp[5] = makePTR(hp+0);
hp[6] = makeHDR(3);
hp[7] = makeFUN(&&F_sumAcc);
hp[8] = makeINT(0);
hp[9] = makePTR(hp+3);
atom = makePTR(hp+6);
hp += 10;
eval_ret_addr = &&LABEL_1578;
goto EVAL;
LABEL_1578:
L_POP(1);
res = getINT(L_top) + res;
L_POP(3);
L_PUSH(makeINT(res));
goto EVAL_RET;
}
F_size___0:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1579;
  goto GC_COLLECT;
}
  GC_RET_1579:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_unzip);
hp[2] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+0);
hp += 3;
eval_ret_addr = &&LABEL_1580;
goto EVAL;
LABEL_1580:
switch (res) {
case C_Pair:
atom = getPTR(L_sp[-1])[3];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
}
P_ADD:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1581;
  goto GC_COLLECT;
}
  GC_RET_1581:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_1582;
goto EVAL;
LABEL_1582:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_1583;
goto EVAL;
LABEL_1583:
L_POP(1);
res = getINT(L_top) + res;
L_POP(2);
L_PUSH(makeINT(res));
goto EVAL_RET;
P_SUB:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1584;
  goto GC_COLLECT;
}
  GC_RET_1584:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_1585;
goto EVAL;
LABEL_1585:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_1586;
goto EVAL;
LABEL_1586:
L_POP(1);
res = getINT(L_top) - res;
L_POP(2);
L_PUSH(makeINT(res));
goto EVAL_RET;
P_EQ:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1587;
  goto GC_COLLECT;
}
  GC_RET_1587:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_1588;
goto EVAL;
LABEL_1588:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_1589;
goto EVAL;
LABEL_1589:
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(2);
L_PUSH(makeCTR(res));
goto EVAL_RET;
P_NEQ:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1590;
  goto GC_COLLECT;
}
  GC_RET_1590:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_1591;
goto EVAL;
LABEL_1591:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_1592;
goto EVAL;
LABEL_1592:
L_POP(1);
res = getINT(L_top) != res ? C_True : C_False;
L_POP(2);
L_PUSH(makeCTR(res));
goto EVAL_RET;
P_LEQ:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1593;
  goto GC_COLLECT;
}
  GC_RET_1593:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_1594;
goto EVAL;
LABEL_1594:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_1595;
goto EVAL;
LABEL_1595:
L_POP(1);
res = getINT(L_top) <= res ? C_True : C_False;
L_POP(2);
L_PUSH(makeCTR(res));
goto EVAL_RET;
GC_COPY:
if (from[0] == VISITED) {
  atom = from[1];
  goto *gc_copy_ret;
}
if (isPTR(from[1])) { from = getPTR(from[1]); goto GC_COPY; }
if (size(from[0]) == 1) { atom = from[1]; }
else {
  n = size(from[0]) + 1;
  //printf("Copy (%i);\n", n-1);
  atom = makePTR(free);
  for (i = 0; i < n; i++)
    { *free = from[i]; free++; }
  from[0] = VISITED;
  from[1] = atom;
}
goto *gc_copy_ret;
GC_COLLECT:
//printf("GC invoked (%i);\n", hp - fromSpace);
scan = toSpace;
free = toSpace;
for (p = L_base; p < L_sp; p++) {
  if (isPTR(*p)) {
    from = getPTR(*p);
    gc_copy_ret = &&GC_COPY_RET1; goto GC_COPY; GC_COPY_RET1:
    *p = atom;
  }
}
while (scan < free) {
  m = size(*scan); scan++;
  //printf("Scan (%i);\n", m);
  for (j = 0; j < m; j++) {
    if (isPTR(*scan)) {
      from = getPTR(*scan);
      gc_copy_ret = &&GC_COPY_RET2; goto GC_COPY; GC_COPY_RET2:
      *scan = atom;
    }
    scan++;
  }
}
for (frame = R_base; frame > R_sp; frame--) {
  p = frame->current;
  frame->current = 0;
  while (p && p[0] != VISITED && isPTR(p[1])) p = getPTR(p[1]);
  if (p && p[0] == VISITED) {
    if (isPTR(p[1])) frame->current = getPTR(p[1]);
  }
}
hp = free;
p = fromSpace; fromSpace = toSpace; toSpace = p;
p = fromSpaceEnd; fromSpaceEnd = toSpaceEnd; toSpaceEnd = p;
heapEnd = fromSpaceEnd;
L_top = L_sp[-1];
R_top_returnAddress = R_sp[1].returnAddress;
R_top_current = R_sp[1].current;
//printf("GC finished (%i);\n", hp - fromSpace);
goto *gc_ret;
}



