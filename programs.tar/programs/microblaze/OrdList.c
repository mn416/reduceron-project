#include <stdio.h>
#include <stdlib.h>
typedef unsigned int Atom;
#define isPTR(a)   (((a)&3) == 0)
#define isCTR(a)   (((a)&3) == 1)
#define isINT(a)   (((a)&3) == 2)
#define isFUN(a)   (((a)&3) == 3)
#define getPTR(a)  ((Atom*) (a))
#define getCTR(a)  ((a) >> 2)
#define getINT(a)  ((int) (((int) (a)) >> 2))
#define getFUN(a)  ((void*) (((unsigned int) (a)) & (~3)))
#define makePTR(x) ((Atom) (x))
#define makeCTR(x) ((Atom) (((x) << 2) | 1))
#define makeINT(x) ((Atom) ((((unsigned int) (x)) << 2) | 2))
#define makeFUN(x) ((Atom) (((unsigned int) (x)) | 3))
#define HEAP_SIZE 22000
#define STACK_SIZE 3000
typedef struct {
  Atom* current;
  void* returnAddress;
} Frame;
#define L_POP(n) L_sp-=n; L_top = L_sp[-1];
#define L_PUSH(a) L_top = a; L_sp[0] = L_top; L_sp++;
#define R_POP \
  R_sp++;\
  R_top_returnAddress = R_sp[1].returnAddress;\
  R_top_current = R_sp[1].current;
#define R_PUSH(ra, cur) \
  R_top_returnAddress = R_sp[0].returnAddress = ra; \
  R_top_current = R_sp[0].current = cur; \
  R_sp--;
#define makeHDR(x)        ((x) << 1)
#define VISITED           1
#define size(x)           ((x) >> 1)
#define C_False 0
#define C_True 1
#define C_Cons 0
#define C_Nil 1
#define C_S 0
#define C_Z 1


int main() {
register Atom* L_sp;
Atom* L_base;
register Atom L_top;
register Frame* R_sp;
Frame* R_base;
register void* R_top_returnAddress;
register Atom* R_top_current;
register Atom* hp;
register Atom* heapEnd;
register Atom atom;
register Atom* app;
register int res;
Atom* fromSpace;
Atom* toSpace;
Atom* fromSpaceEnd;
Atom* toSpaceEnd;
Atom* scan;
Atom* free;
Atom* p;
Atom* from;
Frame* frame;
void* gc_copy_ret;
void* gc_ret;
void* eval_ret_addr;
int i;
int j;
int n;
int m;
L_base = L_sp = malloc(sizeof(Atom) * STACK_SIZE);
R_base = R_sp = (Frame*) &L_sp[STACK_SIZE-1];
fromSpace = hp = malloc(sizeof(Atom) * HEAP_SIZE);
heapEnd = fromSpaceEnd = &fromSpace[HEAP_SIZE-1000];
toSpace = malloc(sizeof(Atom) * HEAP_SIZE);
toSpaceEnd = &toSpace[HEAP_SIZE-1000];
print("S");
atom = makePTR(hp);
*hp++ = makeHDR(1); *hp++ =  makeFUN(&&F_main);
L_PUSH(atom);
eval_ret_addr = &&LABEL_86;
goto EVAL;
LABEL_86:
putnum(getINT(L_top));
return 0;
EVAL:
if (isPTR(atom)) {
  app = getPTR(atom);
  EVAL_APP:
  if (isFUN(app[1])) {
    L_PUSH(makePTR(app));
    R_PUSH(eval_ret_addr, app);
    goto *getFUN(app[1]);
    EVAL_RET:
    if (R_top_current) {
      R_top_current[0] = makeHDR(1);
      R_top_current[1] = L_top;
    }
    eval_ret_addr = R_top_returnAddress;
    R_POP;
    goto *eval_ret_addr;
  }
  else if (isCTR(app[1])) {
    L_PUSH(makePTR(app)); res = getCTR(app[1]);
    goto *eval_ret_addr;
  }
  else if (isPTR(app[1])) {
    app = getPTR(app[1]);
    goto EVAL_APP;
  }
  else {
    L_PUSH(app[1]); res = getINT(app[1]);
    goto *eval_ret_addr;
  }
} else {
  L_PUSH(atom);
  res = getINT(atom);
  goto *eval_ret_addr;
}
TAIL_EVAL:
if (isPTR(atom)) {
  app = getPTR(atom);
  TAIL_EVAL_APP:
  if (isFUN(app[1])) {
    L_PUSH(makePTR(app));
    if (R_top_current) {
      R_top_current[0] = makeHDR(1);
      R_top_current[1] = makePTR(app);
    }
    R_top_current = R_sp[1].current = app;
    goto *getFUN(app[1]);
  }
  else if (isPTR(app[1])) {
    app = getPTR(app[1]);
    goto TAIL_EVAL_APP;
  }
  else if (isINT(app[1])) {
    L_PUSH(app[1]); res = getINT(app[1]);
    goto EVAL_RET;
  }
  else {
    L_PUSH(makePTR(app)); res = getCTR(app[1]);
    goto EVAL_RET;
  }
} else {
  L_PUSH(atom);
  res = getINT(atom);
  goto EVAL_RET;
}
F_mapCons_V__V_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_87;
  goto GC_COLLECT;
}
  GC_RET_87:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_88;
goto EVAL;
LABEL_88:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_mapCons_V__V_);
hp[6] = getPTR(L_sp[-2])[2];
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
F_boolList_V_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_91;
  goto GC_COLLECT;
}
  GC_RET_91:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_92;
goto EVAL;
LABEL_92:
switch (res) {
case C_Z:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = makeCTR(C_Nil);
hp[3] = makeCTR(C_Nil);
atom = makePTR(hp+0);
hp += 4;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
case C_S:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_boolList_V_);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = makeHDR(2);
hp[4] = makeFUN(&&F_boolList_V_);
hp[5] = getPTR(L_sp[-1])[2];
hp[6] = makeHDR(3);
hp[7] = makeFUN(&&F_mapCons_V__V_);
hp[8] = makeCTR(C_False);
hp[9] = makePTR(hp+3);
hp[10] = makeHDR(2);
hp[11] = makeFUN(&&F_boolList_V_);
hp[12] = getPTR(L_sp[-1])[2];
hp[13] = makeHDR(3);
hp[14] = makeFUN(&&F_mapCons_V__V_);
hp[15] = makeCTR(C_True);
hp[16] = makePTR(hp+10);
hp[17] = makeHDR(3);
hp[18] = makeFUN(&&F_append_V__V_);
hp[19] = makePTR(hp+6);
hp[20] = makePTR(hp+13);
hp[21] = makeHDR(3);
hp[22] = makeFUN(&&F_append_V__V_);
hp[23] = makePTR(hp+0);
hp[24] = makePTR(hp+17);
atom = makePTR(hp+21);
hp += 25;
L_POP(2);
L_PUSH(atom);
goto F_append_V__V_;
}
F_insert_V__V_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_99;
  goto GC_COLLECT;
}
  GC_RET_99:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_100;
goto EVAL;
LABEL_100:
switch (res) {
case C_Nil:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = makeCTR(C_Nil);
atom = makePTR(hp+0);
hp += 4;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
case C_Cons:
atom = getPTR(L_sp[-2])[2];
getPTR(L_sp[-2])[2] = makeINT(0);
eval_ret_addr = &&LABEL_101;
goto EVAL;
LABEL_101:
switch (res) {
case C_False:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = getPTR(L_sp[-3])[2];
hp[7] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 8;
L_POP(3);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
case C_True:
atom = getPTR(L_sp[-2])[2];
eval_ret_addr = &&LABEL_103;
goto EVAL;
LABEL_103:
switch (res) {
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = getPTR(L_sp[-3])[2];
hp[3] = getPTR(L_sp[-3])[3];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = getPTR(L_sp[-4])[2];
hp[7] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 8;
L_POP(4);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
case C_False:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_insert_V__V_);
hp[2] = getPTR(L_sp[-4])[2];
hp[3] = getPTR(L_sp[-3])[3];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = getPTR(L_sp[-3])[2];
hp[7] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 8;
L_POP(4);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
}
}
F_ord_V_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_106;
  goto GC_COLLECT;
}
  GC_RET_106:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_107;
goto EVAL;
LABEL_107:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
case C_Cons:
atom = getPTR(L_sp[-1])[3];
eval_ret_addr = &&LABEL_108;
goto EVAL;
LABEL_108:
switch (res) {
case C_Nil:
L_POP(3);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
case C_Cons:
atom = getPTR(L_sp[-2])[2];
eval_ret_addr = &&LABEL_109;
goto EVAL;
LABEL_109:
switch (res) {
case C_False:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = makeHDR(2);
hp[5] = makeFUN(&&F_ord_V_);
hp[6] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 7;
L_POP(4);
L_PUSH(atom);
goto F_ord_V_;
case C_True:
atom = getPTR(L_sp[-2])[2];
eval_ret_addr = &&LABEL_111;
goto EVAL;
LABEL_111:
switch (res) {
case C_False:
L_POP(5);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = getPTR(L_sp[-3])[2];
hp[3] = getPTR(L_sp[-3])[3];
hp[4] = makeHDR(2);
hp[5] = makeFUN(&&F_ord_V_);
hp[6] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 7;
L_POP(5);
L_PUSH(atom);
goto F_ord_V_;
}
}
}
}
F_prop_V__V_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_113;
  goto GC_COLLECT;
}
  GC_RET_113:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_ord_V_);
hp[2] = getPTR(L_sp[-1])[3];
atom = makePTR(hp+0);
hp += 3;
eval_ret_addr = &&LABEL_114;
goto EVAL;
LABEL_114:
switch (res) {
case C_False:
L_POP(2);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_insert_V__V_);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = makeHDR(2);
hp[5] = makeFUN(&&F_ord_V_);
hp[6] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 7;
L_POP(2);
L_PUSH(atom);
goto F_ord_V_;
}
F_mapProp_V__V_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_116;
  goto GC_COLLECT;
}
  GC_RET_116:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_117;
goto EVAL;
LABEL_117:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_prop_V__V_);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_mapProp_V__V_);
hp[6] = getPTR(L_sp[-2])[2];
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
F_append_V__V_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_120;
  goto GC_COLLECT;
}
  GC_RET_120:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_121;
goto EVAL;
LABEL_121:
switch (res) {
case C_Nil:
atom = getPTR(L_sp[-2])[3];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_append_V__V_);
hp[2] = getPTR(L_sp[-1])[3];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = getPTR(L_sp[-1])[2];
hp[7] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 8;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
F_andList_V_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_123;
  goto GC_COLLECT;
}
  GC_RET_123:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_124;
goto EVAL;
LABEL_124:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
case C_Cons:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_125;
goto EVAL;
LABEL_125:
switch (res) {
case C_False:
L_POP(3);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
case C_True:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_andList_V_);
hp[2] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+0);
hp += 3;
L_POP(3);
L_PUSH(atom);
goto F_andList_V_;
}
}
F_top_V_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_126;
  goto GC_COLLECT;
}
  GC_RET_126:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_boolList_V_);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = makeHDR(3);
hp[4] = makeFUN(&&F_mapProp_V__V_);
hp[5] = makeCTR(C_True);
hp[6] = makePTR(hp+0);
hp[7] = makeHDR(2);
hp[8] = makeFUN(&&F_boolList_V_);
hp[9] = getPTR(L_sp[-1])[2];
hp[10] = makeHDR(3);
hp[11] = makeFUN(&&F_mapProp_V__V_);
hp[12] = makeCTR(C_False);
hp[13] = makePTR(hp+7);
hp[14] = makeHDR(3);
hp[15] = makeFUN(&&F_append_V__V_);
hp[16] = makePTR(hp+3);
hp[17] = makePTR(hp+10);
hp[18] = makeHDR(2);
hp[19] = makeFUN(&&F_andList_V_);
hp[20] = makePTR(hp+14);
atom = makePTR(hp+18);
hp += 21;
L_POP(1);
L_PUSH(atom);
goto F_andList_V_;
F_main:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_132;
  goto GC_COLLECT;
}
  GC_RET_132:
hp[0] = makeHDR(2);
hp[1] = makeCTR(C_S);
hp[2] = makeCTR(C_Z);
hp[3] = makeHDR(2);
hp[4] = makeCTR(C_S);
hp[5] = makePTR(hp+0);
hp[6] = makeHDR(2);
hp[7] = makeCTR(C_S);
hp[8] = makePTR(hp+3);
hp[9] = makeHDR(2);
hp[10] = makeCTR(C_S);
hp[11] = makePTR(hp+6);
hp[12] = makeHDR(2);
hp[13] = makeCTR(C_S);
hp[14] = makePTR(hp+9);
hp[15] = makeHDR(2);
hp[16] = makeCTR(C_S);
hp[17] = makePTR(hp+12);
hp[18] = makeHDR(2);
hp[19] = makeCTR(C_S);
hp[20] = makePTR(hp+15);
hp[21] = makeHDR(2);
hp[22] = makeCTR(C_S);
hp[23] = makePTR(hp+18);
hp[24] = makeHDR(2);
hp[25] = makeCTR(C_S);
hp[26] = makePTR(hp+21);
hp[27] = makeHDR(2);
hp[28] = makeCTR(C_S);
hp[29] = makePTR(hp+24);
hp[30] = makeHDR(2);
hp[31] = makeCTR(C_S);
hp[32] = makePTR(hp+27);
hp[33] = makeHDR(2);
hp[34] = makeCTR(C_S);
hp[35] = makePTR(hp+30);
hp[36] = makeHDR(2);
hp[37] = makeFUN(&&F_top_V_);
hp[38] = makePTR(hp+33);
atom = makePTR(hp+36);
hp += 39;
eval_ret_addr = &&LABEL_145;
goto EVAL;
LABEL_145:
switch (res) {
case C_False:
L_POP(2);
L_PUSH(makeINT(0));
res = 0;
goto EVAL_RET;
case C_True:
L_POP(2);
L_PUSH(makeINT(1));
res = 1;
goto EVAL_RET;
}
P_ADD:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_146;
  goto GC_COLLECT;
}
  GC_RET_146:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_147;
goto EVAL;
LABEL_147:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_148;
goto EVAL;
LABEL_148:
L_POP(1);
res = getINT(L_top) + res;
L_POP(2);
L_PUSH(makeINT(res));
goto EVAL_RET;
P_SUB:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_149;
  goto GC_COLLECT;
}
  GC_RET_149:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_150;
goto EVAL;
LABEL_150:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_151;
goto EVAL;
LABEL_151:
L_POP(1);
res = getINT(L_top) - res;
L_POP(2);
L_PUSH(makeINT(res));
goto EVAL_RET;
P_EQ:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_152;
  goto GC_COLLECT;
}
  GC_RET_152:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_153;
goto EVAL;
LABEL_153:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_154;
goto EVAL;
LABEL_154:
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(2);
L_PUSH(makeCTR(res));
goto EVAL_RET;
P_NEQ:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_155;
  goto GC_COLLECT;
}
  GC_RET_155:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_156;
goto EVAL;
LABEL_156:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_157;
goto EVAL;
LABEL_157:
L_POP(1);
res = getINT(L_top) != res ? C_True : C_False;
L_POP(2);
L_PUSH(makeCTR(res));
goto EVAL_RET;
P_LEQ:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_158;
  goto GC_COLLECT;
}
  GC_RET_158:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_159;
goto EVAL;
LABEL_159:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_160;
goto EVAL;
LABEL_160:
L_POP(1);
res = getINT(L_top) <= res ? C_True : C_False;
L_POP(2);
L_PUSH(makeCTR(res));
goto EVAL_RET;
GC_COPY:
if (from[0] == VISITED) {
  atom = from[1];
  goto *gc_copy_ret;
}
if (isPTR(from[1])) { from = getPTR(from[1]); goto GC_COPY; }
if (size(from[0]) == 1) { atom = from[1]; }
else {
  n = size(from[0]) + 1;
  //printf("Copy (%i);\n", n-1);
  atom = makePTR(free);
  for (i = 0; i < n; i++)
    { *free = from[i]; free++; }
  from[0] = VISITED;
  from[1] = atom;
}
goto *gc_copy_ret;
GC_COLLECT:
//printf("GC invoked (%i);\n", hp - fromSpace);
scan = toSpace;
free = toSpace;
for (p = L_base; p < L_sp; p++) {
  if (isPTR(*p)) {
    from = getPTR(*p);
    gc_copy_ret = &&GC_COPY_RET1; goto GC_COPY; GC_COPY_RET1:
    *p = atom;
  }
}
while (scan < free) {
  m = size(*scan); scan++;
  //printf("Scan (%i);\n", m);
  for (j = 0; j < m; j++) {
    if (isPTR(*scan)) {
      from = getPTR(*scan);
      gc_copy_ret = &&GC_COPY_RET2; goto GC_COPY; GC_COPY_RET2:
      *scan = atom;
    }
    scan++;
  }
}
for (frame = R_base; frame > R_sp; frame--) {
  p = frame->current;
  frame->current = 0;
  while (p && p[0] != VISITED && isPTR(p[1])) p = getPTR(p[1]);
  if (p && p[0] == VISITED) {
    if (isPTR(p[1])) frame->current = getPTR(p[1]);
  }
}
hp = free;
p = fromSpace; fromSpace = toSpace; toSpace = p;
p = fromSpaceEnd; fromSpaceEnd = toSpaceEnd; toSpaceEnd = p;
heapEnd = fromSpaceEnd;
L_top = L_sp[-1];
R_top_returnAddress = R_sp[1].returnAddress;
R_top_current = R_sp[1].current;
//printf("GC finished (%i);\n", hp - fromSpace);
goto *gc_ret;
}



