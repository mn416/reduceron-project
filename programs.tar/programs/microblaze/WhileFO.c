#include <stdio.h>
#include <stdlib.h>
typedef unsigned int Atom;
#define isPTR(a)   (((a)&3) == 0)
#define isCTR(a)   (((a)&3) == 1)
#define isINT(a)   (((a)&3) == 2)
#define isFUN(a)   (((a)&3) == 3)
#define getPTR(a)  ((Atom*) (a))
#define getCTR(a)  ((a) >> 2)
#define getINT(a)  ((int) (((int) (a)) >> 2))
#define getFUN(a)  ((void*) (((unsigned int) (a)) & (~3)))
#define makePTR(x) ((Atom) (x))
#define makeCTR(x) ((Atom) (((x) << 2) | 1))
#define makeINT(x) ((Atom) ((((unsigned int) (x)) << 2) | 2))
#define makeFUN(x) ((Atom) (((unsigned int) (x)) | 3))
#define HEAP_SIZE 22000
#define STACK_SIZE 3000
typedef struct {
  Atom* current;
  void* returnAddress;
} Frame;
#define L_POP(n) L_sp-=n; L_top = L_sp[-1];
#define L_PUSH(a) L_top = a; L_sp[0] = L_top; L_sp++;
#define R_POP \
  R_sp++;\
  R_top_returnAddress = R_sp[1].returnAddress;\
  R_top_current = R_sp[1].current;
#define R_PUSH(ra, cur) \
  R_top_returnAddress = R_sp[0].returnAddress = ra; \
  R_top_current = R_sp[0].current = cur; \
  R_sp--;
#define makeHDR(x)        ((x) << 1)
#define VISITED           1
#define size(x)           ((x) >> 1)
#define C_False 0
#define C_True 1
#define C_Cons 0
#define C_Nil 1
#define C_Pair 0
#define C_Add 0
#define C_N 1
#define C_Sub 2
#define C_V 3
#define C_And 0
#define C_Eq 1
#define C_FALSE 2
#define C_Le 3
#define C_Neg 4
#define C_TRUE 5
#define C_Ass 0
#define C_Comp 1
#define C_If 2
#define C_Skip 3
#define C_While 4
#define C_Final 0
#define C_Inter 1


int main() {
register Atom* L_sp;
Atom* L_base;
register Atom L_top;
register Frame* R_sp;
Frame* R_base;
register void* R_top_returnAddress;
register Atom* R_top_current;
register Atom* hp;
register Atom* heapEnd;
register Atom atom;
register Atom* app;
register int res;
Atom* fromSpace;
Atom* toSpace;
Atom* fromSpaceEnd;
Atom* toSpaceEnd;
Atom* scan;
Atom* free;
Atom* p;
Atom* from;
Frame* frame;
void* gc_copy_ret;
void* gc_ret;
void* eval_ret_addr;
int i;
int j;
int n;
int m;
L_base = L_sp = malloc(sizeof(Atom) * STACK_SIZE);
R_base = R_sp = (Frame*) &L_sp[STACK_SIZE-1];
fromSpace = hp = malloc(sizeof(Atom) * HEAP_SIZE);
heapEnd = fromSpaceEnd = &fromSpace[HEAP_SIZE-1000];
toSpace = malloc(sizeof(Atom) * HEAP_SIZE);
toSpaceEnd = &toSpace[HEAP_SIZE-1000];
print("S");
atom = makePTR(hp);
*hp++ = makeHDR(1); *hp++ =  makeFUN(&&F_main);
L_PUSH(atom);
eval_ret_addr = &&LABEL_187;
goto EVAL;
LABEL_187:
putnum(getINT(L_top));
return 0;
EVAL:
if (isPTR(atom)) {
  app = getPTR(atom);
  EVAL_APP:
  if (isFUN(app[1])) {
    L_PUSH(makePTR(app));
    R_PUSH(eval_ret_addr, app);
    goto *getFUN(app[1]);
    EVAL_RET:
    if (R_top_current) {
      R_top_current[0] = makeHDR(1);
      R_top_current[1] = L_top;
    }
    eval_ret_addr = R_top_returnAddress;
    R_POP;
    goto *eval_ret_addr;
  }
  else if (isCTR(app[1])) {
    L_PUSH(makePTR(app)); res = getCTR(app[1]);
    goto *eval_ret_addr;
  }
  else if (isPTR(app[1])) {
    app = getPTR(app[1]);
    goto EVAL_APP;
  }
  else {
    L_PUSH(app[1]); res = getINT(app[1]);
    goto *eval_ret_addr;
  }
} else {
  L_PUSH(atom);
  res = getINT(atom);
  goto *eval_ret_addr;
}
TAIL_EVAL:
if (isPTR(atom)) {
  app = getPTR(atom);
  TAIL_EVAL_APP:
  if (isFUN(app[1])) {
    L_PUSH(makePTR(app));
    if (R_top_current) {
      R_top_current[0] = makeHDR(1);
      R_top_current[1] = makePTR(app);
    }
    R_top_current = R_sp[1].current = app;
    goto *getFUN(app[1]);
  }
  else if (isPTR(app[1])) {
    app = getPTR(app[1]);
    goto TAIL_EVAL_APP;
  }
  else if (isINT(app[1])) {
    L_PUSH(app[1]); res = getINT(app[1]);
    goto EVAL_RET;
  }
  else {
    L_PUSH(makePTR(app)); res = getCTR(app[1]);
    goto EVAL_RET;
  }
} else {
  L_PUSH(atom);
  res = getINT(atom);
  goto EVAL_RET;
}
F_main:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_188;
  goto GC_COLLECT;
}
  GC_RET_188:
hp[0] = makeHDR(2);
hp[1] = makeCTR(C_V);
hp[2] = makeINT(3);
hp[3] = makeHDR(3);
hp[4] = makeCTR(C_Ass);
hp[5] = makeINT(4);
hp[6] = makePTR(hp+0);
hp[7] = makeHDR(2);
hp[8] = makeCTR(C_V);
hp[9] = makeINT(4);
hp[10] = makeHDR(2);
hp[11] = makeCTR(C_N);
hp[12] = makeINT(0);
hp[13] = makeHDR(3);
hp[14] = makeCTR(C_Eq);
hp[15] = makePTR(hp+7);
hp[16] = makePTR(hp+10);
hp[17] = makeHDR(2);
hp[18] = makeCTR(C_Neg);
hp[19] = makePTR(hp+13);
hp[20] = makeHDR(2);
hp[21] = makeCTR(C_V);
hp[22] = makeINT(3);
hp[23] = makeHDR(3);
hp[24] = makeCTR(C_Ass);
hp[25] = makeINT(0);
hp[26] = makePTR(hp+20);
hp[27] = makeHDR(2);
hp[28] = makeCTR(C_V);
hp[29] = makeINT(4);
hp[30] = makeHDR(3);
hp[31] = makeCTR(C_Ass);
hp[32] = makeINT(1);
hp[33] = makePTR(hp+27);
hp[34] = makeHDR(3);
hp[35] = makeCTR(C_Comp);
hp[36] = makePTR(hp+23);
hp[37] = makePTR(hp+30);
hp[38] = makeHDR(2);
hp[39] = makeCTR(C_V);
hp[40] = makeINT(1);
hp[41] = makeHDR(2);
hp[42] = makeCTR(C_V);
hp[43] = makeINT(0);
hp[44] = makeHDR(3);
hp[45] = makeCTR(C_Le);
hp[46] = makePTR(hp+38);
hp[47] = makePTR(hp+41);
hp[48] = makeHDR(2);
hp[49] = makeCTR(C_V);
hp[50] = makeINT(0);
hp[51] = makeHDR(2);
hp[52] = makeCTR(C_V);
hp[53] = makeINT(1);
hp[54] = makeHDR(3);
hp[55] = makeCTR(C_Sub);
hp[56] = makePTR(hp+48);
hp[57] = makePTR(hp+51);
hp[58] = makeHDR(3);
hp[59] = makeCTR(C_Ass);
hp[60] = makeINT(0);
hp[61] = makePTR(hp+54);
hp[62] = makeHDR(2);
hp[63] = makeCTR(C_V);
hp[64] = makeINT(2);
hp[65] = makeHDR(2);
hp[66] = makeCTR(C_N);
hp[67] = makeINT(1);
hp[68] = makeHDR(3);
hp[69] = makeCTR(C_Add);
hp[70] = makePTR(hp+62);
hp[71] = makePTR(hp+65);
hp[72] = makeHDR(3);
hp[73] = makeCTR(C_Ass);
hp[74] = makeINT(2);
hp[75] = makePTR(hp+68);
hp[76] = makeHDR(3);
hp[77] = makeCTR(C_Comp);
hp[78] = makePTR(hp+58);
hp[79] = makePTR(hp+72);
hp[80] = makeHDR(3);
hp[81] = makeCTR(C_While);
hp[82] = makePTR(hp+44);
hp[83] = makePTR(hp+76);
hp[84] = makeHDR(3);
hp[85] = makeCTR(C_Comp);
hp[86] = makePTR(hp+34);
hp[87] = makePTR(hp+80);
hp[88] = makeHDR(2);
hp[89] = makeCTR(C_V);
hp[90] = makeINT(0);
hp[91] = makeHDR(2);
hp[92] = makeCTR(C_N);
hp[93] = makeINT(0);
hp[94] = makeHDR(3);
hp[95] = makeCTR(C_Eq);
hp[96] = makePTR(hp+88);
hp[97] = makePTR(hp+91);
hp[98] = makeHDR(2);
hp[99] = makeCTR(C_V);
hp[100] = makeINT(5);
hp[101] = makeHDR(2);
hp[102] = makeCTR(C_N);
hp[103] = makeINT(1);
hp[104] = makeHDR(3);
hp[105] = makeCTR(C_Add);
hp[106] = makePTR(hp+98);
hp[107] = makePTR(hp+101);
hp[108] = makeHDR(3);
hp[109] = makeCTR(C_Ass);
hp[110] = makeINT(5);
hp[111] = makePTR(hp+104);
hp[112] = makeHDR(4);
hp[113] = makeCTR(C_If);
hp[114] = makePTR(hp+94);
hp[115] = makePTR(hp+108);
hp[116] = makeCTR(C_Skip);
hp[117] = makeHDR(3);
hp[118] = makeCTR(C_Comp);
hp[119] = makePTR(hp+84);
hp[120] = makePTR(hp+112);
hp[121] = makeHDR(2);
hp[122] = makeCTR(C_V);
hp[123] = makeINT(4);
hp[124] = makeHDR(2);
hp[125] = makeCTR(C_N);
hp[126] = makeINT(1);
hp[127] = makeHDR(3);
hp[128] = makeCTR(C_Sub);
hp[129] = makePTR(hp+121);
hp[130] = makePTR(hp+124);
hp[131] = makeHDR(3);
hp[132] = makeCTR(C_Ass);
hp[133] = makeINT(4);
hp[134] = makePTR(hp+127);
hp[135] = makeHDR(3);
hp[136] = makeCTR(C_Comp);
hp[137] = makePTR(hp+117);
hp[138] = makePTR(hp+131);
hp[139] = makeHDR(3);
hp[140] = makeCTR(C_While);
hp[141] = makePTR(hp+17);
hp[142] = makePTR(hp+135);
hp[143] = makeHDR(3);
hp[144] = makeCTR(C_Comp);
hp[145] = makePTR(hp+3);
hp[146] = makePTR(hp+139);
hp[147] = makeHDR(3);
hp[148] = makeCTR(C_Pair);
hp[149] = makeINT(0);
hp[150] = makeINT(0);
hp[151] = makeHDR(3);
hp[152] = makeCTR(C_Pair);
hp[153] = makeINT(1);
hp[154] = makeINT(0);
hp[155] = makeHDR(3);
hp[156] = makeCTR(C_Pair);
hp[157] = makeINT(2);
hp[158] = makeINT(0);
hp[159] = makeHDR(3);
hp[160] = makeCTR(C_Pair);
hp[161] = makeINT(3);
hp[162] = makeINT(14000);
hp[163] = makeHDR(3);
hp[164] = makeCTR(C_Pair);
hp[165] = makeINT(4);
hp[166] = makeINT(0);
hp[167] = makeHDR(3);
hp[168] = makeCTR(C_Pair);
hp[169] = makeINT(5);
hp[170] = makeINT(0);
hp[171] = makeHDR(3);
hp[172] = makeCTR(C_Cons);
hp[173] = makePTR(hp+167);
hp[174] = makeCTR(C_Nil);
hp[175] = makeHDR(3);
hp[176] = makeCTR(C_Cons);
hp[177] = makePTR(hp+163);
hp[178] = makePTR(hp+171);
hp[179] = makeHDR(3);
hp[180] = makeCTR(C_Cons);
hp[181] = makePTR(hp+159);
hp[182] = makePTR(hp+175);
hp[183] = makeHDR(3);
hp[184] = makeCTR(C_Cons);
hp[185] = makePTR(hp+155);
hp[186] = makePTR(hp+179);
hp[187] = makeHDR(3);
hp[188] = makeCTR(C_Cons);
hp[189] = makePTR(hp+151);
hp[190] = makePTR(hp+183);
hp[191] = makeHDR(3);
hp[192] = makeCTR(C_Cons);
hp[193] = makePTR(hp+147);
hp[194] = makePTR(hp+187);
hp[195] = makeHDR(3);
hp[196] = makeCTR(C_Inter);
hp[197] = makePTR(hp+143);
hp[198] = makePTR(hp+191);
hp[199] = makeHDR(2);
hp[200] = makeFUN(&&F_run);
hp[201] = makePTR(hp+195);
hp[202] = makeHDR(3);
hp[203] = makeFUN(&&F_value);
hp[204] = makePTR(hp+199);
hp[205] = makeINT(5);
atom = makePTR(hp+202);
hp += 206;
L_POP(1);
L_PUSH(atom);
goto F_value;
F_value:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_244;
  goto GC_COLLECT;
}
  GC_RET_244:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_245;
goto EVAL;
LABEL_245:
switch (res) {
case C_Cons:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_246;
goto EVAL;
LABEL_246:
switch (res) {
case C_Pair:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_247;
goto EVAL;
LABEL_247:
atom = getPTR(L_sp[-4])[3];
eval_ret_addr = &&LABEL_248;
goto EVAL;
LABEL_248:
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(1);
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
atom = getPTR(L_sp[-2])[3];
L_POP(4);
goto TAIL_EVAL;
goto EVAL_RET;
case C_False:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_value);
hp[2] = getPTR(L_sp[-3])[3];
hp[3] = getPTR(L_sp[-4])[3];
atom = makePTR(hp+0);
hp += 4;
L_POP(4);
L_PUSH(atom);
goto F_value;
}
}
}
F_update:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_249;
  goto GC_COLLECT;
}
  GC_RET_249:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_250;
goto EVAL;
LABEL_250:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_251;
goto EVAL;
LABEL_251:
switch (res) {
case C_Pair:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_252;
goto EVAL;
LABEL_252:
atom = getPTR(L_sp[-4])[3];
eval_ret_addr = &&LABEL_253;
goto EVAL;
LABEL_253:
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(1);
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Pair);
hp[2] = getPTR(L_sp[-4])[3];
hp[3] = getPTR(L_sp[-4])[4];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = makePTR(hp+0);
hp[7] = getPTR(L_sp[-3])[3];
atom = makePTR(hp+4);
hp += 8;
L_POP(4);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
case C_False:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Pair);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = makeHDR(4);
hp[5] = makeFUN(&&F_update);
hp[6] = getPTR(L_sp[-3])[3];
hp[7] = getPTR(L_sp[-4])[3];
hp[8] = getPTR(L_sp[-4])[4];
hp[9] = makeHDR(3);
hp[10] = makeCTR(C_Cons);
hp[11] = makePTR(hp+0);
hp[12] = makePTR(hp+4);
atom = makePTR(hp+9);
hp += 13;
L_POP(4);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
}
}
F_not:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_257;
  goto GC_COLLECT;
}
  GC_RET_257:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_258;
goto EVAL;
LABEL_258:
switch (res) {
case C_False:
L_POP(2);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
case C_True:
L_POP(2);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
}
F_and:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_259;
  goto GC_COLLECT;
}
  GC_RET_259:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_260;
goto EVAL;
LABEL_260:
switch (res) {
case C_False:
L_POP(2);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
case C_True:
atom = getPTR(L_sp[-2])[3];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
}
F_aval:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_261;
  goto GC_COLLECT;
}
  GC_RET_261:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_262;
goto EVAL;
LABEL_262:
switch (res) {
case C_N:
atom = getPTR(L_sp[-1])[2];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
case C_V:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_value);
hp[2] = getPTR(L_sp[-2])[3];
hp[3] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+0);
hp += 4;
L_POP(2);
L_PUSH(atom);
goto F_value;
case C_Add:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_aval);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_263;
goto EVAL;
LABEL_263:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_aval);
hp[2] = getPTR(L_sp[-2])[3];
hp[3] = getPTR(L_sp[-3])[3];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_264;
goto EVAL;
LABEL_264:
L_POP(1);
res = getINT(L_top) + res;
L_POP(3);
L_PUSH(makeINT(res));
goto EVAL_RET;
case C_Sub:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_aval);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_265;
goto EVAL;
LABEL_265:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_aval);
hp[2] = getPTR(L_sp[-2])[3];
hp[3] = getPTR(L_sp[-3])[3];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_266;
goto EVAL;
LABEL_266:
L_POP(1);
res = getINT(L_top) - res;
L_POP(3);
L_PUSH(makeINT(res));
goto EVAL_RET;
}
F_bval:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_267;
  goto GC_COLLECT;
}
  GC_RET_267:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_268;
goto EVAL;
LABEL_268:
switch (res) {
case C_TRUE:
L_POP(2);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
case C_FALSE:
L_POP(2);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
case C_Eq:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_aval);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_269;
goto EVAL;
LABEL_269:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_aval);
hp[2] = getPTR(L_sp[-2])[3];
hp[3] = getPTR(L_sp[-3])[3];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_270;
goto EVAL;
LABEL_270:
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(3);
L_PUSH(makeCTR(res));
goto EVAL_RET;
case C_Le:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_aval);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_271;
goto EVAL;
LABEL_271:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_aval);
hp[2] = getPTR(L_sp[-2])[3];
hp[3] = getPTR(L_sp[-3])[3];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_272;
goto EVAL;
LABEL_272:
L_POP(1);
res = getINT(L_top) <= res ? C_True : C_False;
L_POP(3);
L_PUSH(makeCTR(res));
goto EVAL_RET;
case C_Neg:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_bval);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_273;
goto EVAL;
LABEL_273:
switch (res) {
case C_False:
L_POP(3);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
case C_True:
L_POP(3);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
}
case C_And:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_bval);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_274;
goto EVAL;
LABEL_274:
switch (res) {
case C_False:
L_POP(3);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_bval);
hp[2] = getPTR(L_sp[-2])[3];
hp[3] = getPTR(L_sp[-3])[3];
atom = makePTR(hp+0);
hp += 4;
L_POP(3);
L_PUSH(atom);
goto F_bval;
}
}
F_sosstm:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_275;
  goto GC_COLLECT;
}
  GC_RET_275:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_276;
goto EVAL;
LABEL_276:
switch (res) {
case C_Ass:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_aval);
hp[2] = getPTR(L_sp[-1])[3];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = makeHDR(4);
hp[5] = makeFUN(&&F_sosstm___0);
hp[6] = makePTR(hp+0);
hp[7] = getPTR(L_sp[-2])[3];
hp[8] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+4);
hp += 9;
L_POP(2);
L_PUSH(atom);
goto F_sosstm___0;
case C_Skip:
hp[0] = makeHDR(2);
hp[1] = makeCTR(C_Final);
hp[2] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+0);
hp += 3;
L_POP(2);
L_PUSH(atom);
res = C_Final;
goto EVAL_RET;
case C_Comp:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_sosstm);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_277;
goto EVAL;
LABEL_277:
switch (res) {
case C_Inter:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Comp);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Inter);
hp[6] = makePTR(hp+0);
hp[7] = getPTR(L_sp[-1])[3];
atom = makePTR(hp+4);
hp += 8;
L_POP(3);
L_PUSH(atom);
res = C_Inter;
goto EVAL_RET;
case C_Final:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Inter);
hp[2] = getPTR(L_sp[-2])[3];
hp[3] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+0);
hp += 4;
L_POP(3);
L_PUSH(atom);
res = C_Inter;
goto EVAL_RET;
}
case C_If:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_bval);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_279;
goto EVAL;
LABEL_279:
switch (res) {
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Inter);
hp[2] = getPTR(L_sp[-2])[3];
hp[3] = getPTR(L_sp[-3])[3];
atom = makePTR(hp+0);
hp += 4;
L_POP(3);
L_PUSH(atom);
res = C_Inter;
goto EVAL_RET;
case C_False:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Inter);
hp[2] = getPTR(L_sp[-2])[4];
hp[3] = getPTR(L_sp[-3])[3];
atom = makePTR(hp+0);
hp += 4;
L_POP(3);
L_PUSH(atom);
res = C_Inter;
goto EVAL_RET;
}
case C_While:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_While);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-1])[3];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Comp);
hp[6] = getPTR(L_sp[-1])[3];
hp[7] = makePTR(hp+0);
hp[8] = makeHDR(4);
hp[9] = makeCTR(C_If);
hp[10] = getPTR(L_sp[-1])[2];
hp[11] = makePTR(hp+4);
hp[12] = makeCTR(C_Skip);
hp[13] = makeHDR(3);
hp[14] = makeCTR(C_Inter);
hp[15] = makePTR(hp+8);
hp[16] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+13);
hp += 17;
L_POP(2);
L_PUSH(atom);
res = C_Inter;
goto EVAL_RET;
}
F_sosstm___0:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_283;
  goto GC_COLLECT;
}
  GC_RET_283:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_284;
goto EVAL;
LABEL_284:
L_PUSH(makeINT(0));
res = 0;
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(1);
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
hp[0] = makeHDR(4);
hp[1] = makeFUN(&&F_update);
hp[2] = getPTR(L_sp[-2])[3];
hp[3] = getPTR(L_sp[-2])[4];
hp[4] = makeINT(0);
hp[5] = makeHDR(2);
hp[6] = makeCTR(C_Final);
hp[7] = makePTR(hp+0);
atom = makePTR(hp+5);
hp += 8;
L_POP(2);
L_PUSH(atom);
res = C_Final;
goto EVAL_RET;
case C_False:
hp[0] = makeHDR(4);
hp[1] = makeFUN(&&F_update);
hp[2] = getPTR(L_sp[-2])[3];
hp[3] = getPTR(L_sp[-2])[4];
hp[4] = getPTR(L_sp[-2])[2];
hp[5] = makeHDR(2);
hp[6] = makeCTR(C_Final);
hp[7] = makePTR(hp+0);
atom = makePTR(hp+5);
hp += 8;
L_POP(2);
L_PUSH(atom);
res = C_Final;
goto EVAL_RET;
}
F_run:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_287;
  goto GC_COLLECT;
}
  GC_RET_287:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_288;
goto EVAL;
LABEL_288:
switch (res) {
case C_Inter:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_sosstm);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-1])[3];
hp[4] = makeHDR(2);
hp[5] = makeFUN(&&F_run);
hp[6] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 7;
L_POP(2);
L_PUSH(atom);
goto F_run;
case C_Final:
atom = getPTR(L_sp[-1])[2];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
}
F_ssos:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_290;
  goto GC_COLLECT;
}
  GC_RET_290:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Inter);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-1])[3];
hp[4] = makeHDR(2);
hp[5] = makeFUN(&&F_run);
hp[6] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 7;
L_POP(1);
L_PUSH(atom);
goto F_run;
P_ADD:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_292;
  goto GC_COLLECT;
}
  GC_RET_292:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_293;
goto EVAL;
LABEL_293:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_294;
goto EVAL;
LABEL_294:
L_POP(1);
res = getINT(L_top) + res;
L_POP(2);
L_PUSH(makeINT(res));
goto EVAL_RET;
P_SUB:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_295;
  goto GC_COLLECT;
}
  GC_RET_295:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_296;
goto EVAL;
LABEL_296:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_297;
goto EVAL;
LABEL_297:
L_POP(1);
res = getINT(L_top) - res;
L_POP(2);
L_PUSH(makeINT(res));
goto EVAL_RET;
P_EQ:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_298;
  goto GC_COLLECT;
}
  GC_RET_298:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_299;
goto EVAL;
LABEL_299:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_300;
goto EVAL;
LABEL_300:
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(2);
L_PUSH(makeCTR(res));
goto EVAL_RET;
P_NEQ:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_301;
  goto GC_COLLECT;
}
  GC_RET_301:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_302;
goto EVAL;
LABEL_302:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_303;
goto EVAL;
LABEL_303:
L_POP(1);
res = getINT(L_top) != res ? C_True : C_False;
L_POP(2);
L_PUSH(makeCTR(res));
goto EVAL_RET;
P_LEQ:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_304;
  goto GC_COLLECT;
}
  GC_RET_304:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_305;
goto EVAL;
LABEL_305:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_306;
goto EVAL;
LABEL_306:
L_POP(1);
res = getINT(L_top) <= res ? C_True : C_False;
L_POP(2);
L_PUSH(makeCTR(res));
goto EVAL_RET;
GC_COPY:
if (from[0] == VISITED) {
  atom = from[1];
  goto *gc_copy_ret;
}
if (isPTR(from[1])) { from = getPTR(from[1]); goto GC_COPY; }
if (size(from[0]) == 1) { atom = from[1]; }
else {
  n = size(from[0]) + 1;
  //printf("Copy (%i);\n", n-1);
  atom = makePTR(free);
  for (i = 0; i < n; i++)
    { *free = from[i]; free++; }
  from[0] = VISITED;
  from[1] = atom;
}
goto *gc_copy_ret;
GC_COLLECT:
//printf("GC invoked (%i);\n", hp - fromSpace);
scan = toSpace;
free = toSpace;
for (p = L_base; p < L_sp; p++) {
  if (isPTR(*p)) {
    from = getPTR(*p);
    gc_copy_ret = &&GC_COPY_RET1; goto GC_COPY; GC_COPY_RET1:
    *p = atom;
  }
}
while (scan < free) {
  m = size(*scan); scan++;
  //printf("Scan (%i);\n", m);
  for (j = 0; j < m; j++) {
    if (isPTR(*scan)) {
      from = getPTR(*scan);
      gc_copy_ret = &&GC_COPY_RET2; goto GC_COPY; GC_COPY_RET2:
      *scan = atom;
    }
    scan++;
  }
}
for (frame = R_base; frame > R_sp; frame--) {
  p = frame->current;
  frame->current = 0;
  while (p && p[0] != VISITED && isPTR(p[1])) p = getPTR(p[1]);
  if (p && p[0] == VISITED) {
    if (isPTR(p[1])) frame->current = getPTR(p[1]);
  }
}
hp = free;
p = fromSpace; fromSpace = toSpace; toSpace = p;
p = fromSpaceEnd; fromSpaceEnd = toSpaceEnd; toSpaceEnd = p;
heapEnd = fromSpaceEnd;
L_top = L_sp[-1];
R_top_returnAddress = R_sp[1].returnAddress;
R_top_current = R_sp[1].current;
//printf("GC finished (%i);\n", hp - fromSpace);
goto *gc_ret;
}



