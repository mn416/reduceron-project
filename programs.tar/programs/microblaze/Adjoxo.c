#include <stdio.h>
#include <stdlib.h>
typedef unsigned int Atom;
#define isPTR(a)   (((a)&3) == 0)
#define isCTR(a)   (((a)&3) == 1)
#define isINT(a)   (((a)&3) == 2)
#define isFUN(a)   (((a)&3) == 3)
#define getPTR(a)  ((Atom*) (a))
#define getCTR(a)  ((a) >> 2)
#define getINT(a)  ((int) (((int) (a)) >> 2))
#define getFUN(a)  ((void*) (((unsigned int) (a)) & (~3)))
#define makePTR(x) ((Atom) (x))
#define makeCTR(x) ((Atom) (((x) << 2) | 1))
#define makeINT(x) ((Atom) ((((unsigned int) (x)) << 2) | 2))
#define makeFUN(x) ((Atom) (((unsigned int) (x)) | 3))
#define HEAP_SIZE 22000
#define STACK_SIZE 3000
typedef struct {
  Atom* current;
  void* returnAddress;
} Frame;
#define L_POP(n) L_sp-=n; L_top = L_sp[-1];
#define L_PUSH(a) L_top = a; L_sp[0] = L_top; L_sp++;
#define R_POP \
  R_sp++;\
  R_top_returnAddress = R_sp[1].returnAddress;\
  R_top_current = R_sp[1].current;
#define R_PUSH(ra, cur) \
  R_top_returnAddress = R_sp[0].returnAddress = ra; \
  R_top_current = R_sp[0].current = cur; \
  R_sp--;
#define makeHDR(x)        ((x) << 1)
#define VISITED           1
#define size(x)           ((x) >> 1)
#define C_False 0
#define C_True 1
#define C_Cons 0
#define C_Nil 1
#define C_EQ 0
#define C_GT 1
#define C_LT 2
#define C_Draw 0
#define C_Loss 1
#define C_Win 2
#define C_O 0
#define C_X 1


int main() {
register Atom* L_sp;
Atom* L_base;
register Atom L_top;
register Frame* R_sp;
Frame* R_base;
register void* R_top_returnAddress;
register Atom* R_top_current;
register Atom* hp;
register Atom* heapEnd;
register Atom atom;
register Atom* app;
register int res;
Atom* fromSpace;
Atom* toSpace;
Atom* fromSpaceEnd;
Atom* toSpaceEnd;
Atom* scan;
Atom* free;
Atom* p;
Atom* from;
Frame* frame;
void* gc_copy_ret;
void* gc_ret;
void* eval_ret_addr;
int i;
int j;
int n;
int m;
L_base = L_sp = malloc(sizeof(Atom) * STACK_SIZE);
R_base = R_sp = (Frame*) &L_sp[STACK_SIZE-1];
fromSpace = hp = malloc(sizeof(Atom) * HEAP_SIZE);
heapEnd = fromSpaceEnd = &fromSpace[HEAP_SIZE-1000];
toSpace = malloc(sizeof(Atom) * HEAP_SIZE);
toSpaceEnd = &toSpace[HEAP_SIZE-1000];
print("S");
atom = makePTR(hp);
*hp++ = makeHDR(1); *hp++ =  makeFUN(&&F_main);
L_PUSH(atom);
eval_ret_addr = &&LABEL_185;
goto EVAL;
LABEL_185:
putnum(getINT(L_top));
return 0;
EVAL:
if (isPTR(atom)) {
  app = getPTR(atom);
  EVAL_APP:
  if (isFUN(app[1])) {
    L_PUSH(makePTR(app));
    R_PUSH(eval_ret_addr, app);
    goto *getFUN(app[1]);
    EVAL_RET:
    if (R_top_current) {
      R_top_current[0] = makeHDR(1);
      R_top_current[1] = L_top;
    }
    eval_ret_addr = R_top_returnAddress;
    R_POP;
    goto *eval_ret_addr;
  }
  else if (isCTR(app[1])) {
    L_PUSH(makePTR(app)); res = getCTR(app[1]);
    goto *eval_ret_addr;
  }
  else if (isPTR(app[1])) {
    app = getPTR(app[1]);
    goto EVAL_APP;
  }
  else {
    L_PUSH(app[1]); res = getINT(app[1]);
    goto *eval_ret_addr;
  }
} else {
  L_PUSH(atom);
  res = getINT(atom);
  goto *eval_ret_addr;
}
TAIL_EVAL:
if (isPTR(atom)) {
  app = getPTR(atom);
  TAIL_EVAL_APP:
  if (isFUN(app[1])) {
    L_PUSH(makePTR(app));
    if (R_top_current) {
      R_top_current[0] = makeHDR(1);
      R_top_current[1] = makePTR(app);
    }
    R_top_current = R_sp[1].current = app;
    goto *getFUN(app[1]);
  }
  else if (isPTR(app[1])) {
    app = getPTR(app[1]);
    goto TAIL_EVAL_APP;
  }
  else if (isINT(app[1])) {
    L_PUSH(app[1]); res = getINT(app[1]);
    goto EVAL_RET;
  }
  else {
    L_PUSH(makePTR(app)); res = getCTR(app[1]);
    goto EVAL_RET;
  }
} else {
  L_PUSH(atom);
  res = getINT(atom);
  goto EVAL_RET;
}
F_cmp_Q__Q_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_186;
  goto GC_COLLECT;
}
  GC_RET_186:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_187;
goto EVAL;
LABEL_187:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_188;
goto EVAL;
LABEL_188:
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(1);
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
L_POP(2);
L_PUSH(makeCTR(C_EQ));
res = C_EQ;
goto EVAL_RET;
case C_False:
atom = getPTR(L_sp[-2])[2];
eval_ret_addr = &&LABEL_189;
goto EVAL;
LABEL_189:
atom = getPTR(L_sp[-3])[3];
eval_ret_addr = &&LABEL_190;
goto EVAL;
LABEL_190:
L_POP(1);
res = getINT(L_top) <= res ? C_True : C_False;
L_POP(1);
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
L_POP(3);
L_PUSH(makeCTR(C_LT));
res = C_LT;
goto EVAL_RET;
case C_False:
L_POP(3);
L_PUSH(makeCTR(C_GT));
res = C_GT;
goto EVAL_RET;
}
}
F_hasLine_V_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_191;
  goto GC_COLLECT;
}
  GC_RET_191:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = makeINT(3);
hp[3] = makeCTR(C_Nil);
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = makeINT(2);
hp[7] = makePTR(hp+0);
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makeINT(1);
hp[11] = makePTR(hp+4);
hp[12] = makeHDR(3);
hp[13] = makeFUN(&&F_diff_V__V_);
hp[14] = makePTR(hp+8);
hp[15] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+12);
hp += 16;
eval_ret_addr = &&LABEL_195;
goto EVAL;
LABEL_195:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = makeINT(6);
hp[3] = makeCTR(C_Nil);
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = makeINT(5);
hp[7] = makePTR(hp+0);
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makeINT(4);
hp[11] = makePTR(hp+4);
hp[12] = makeHDR(3);
hp[13] = makeFUN(&&F_diff_V__V_);
hp[14] = makePTR(hp+8);
hp[15] = getPTR(L_sp[-2])[2];
atom = makePTR(hp+12);
hp += 16;
eval_ret_addr = &&LABEL_199;
goto EVAL;
LABEL_199:
switch (res) {
case C_Nil:
L_POP(3);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = makeINT(9);
hp[3] = makeCTR(C_Nil);
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = makeINT(8);
hp[7] = makePTR(hp+0);
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makeINT(7);
hp[11] = makePTR(hp+4);
hp[12] = makeHDR(3);
hp[13] = makeFUN(&&F_diff_V__V_);
hp[14] = makePTR(hp+8);
hp[15] = getPTR(L_sp[-3])[2];
atom = makePTR(hp+12);
hp += 16;
eval_ret_addr = &&LABEL_203;
goto EVAL;
LABEL_203:
switch (res) {
case C_Nil:
L_POP(4);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = makeINT(7);
hp[3] = makeCTR(C_Nil);
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = makeINT(4);
hp[7] = makePTR(hp+0);
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makeINT(1);
hp[11] = makePTR(hp+4);
hp[12] = makeHDR(3);
hp[13] = makeFUN(&&F_diff_V__V_);
hp[14] = makePTR(hp+8);
hp[15] = getPTR(L_sp[-4])[2];
atom = makePTR(hp+12);
hp += 16;
eval_ret_addr = &&LABEL_207;
goto EVAL;
LABEL_207:
switch (res) {
case C_Nil:
L_POP(5);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = makeINT(8);
hp[3] = makeCTR(C_Nil);
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = makeINT(5);
hp[7] = makePTR(hp+0);
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makeINT(2);
hp[11] = makePTR(hp+4);
hp[12] = makeHDR(3);
hp[13] = makeFUN(&&F_diff_V__V_);
hp[14] = makePTR(hp+8);
hp[15] = getPTR(L_sp[-5])[2];
atom = makePTR(hp+12);
hp += 16;
eval_ret_addr = &&LABEL_211;
goto EVAL;
LABEL_211:
switch (res) {
case C_Nil:
L_POP(6);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = makeINT(9);
hp[3] = makeCTR(C_Nil);
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = makeINT(6);
hp[7] = makePTR(hp+0);
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makeINT(3);
hp[11] = makePTR(hp+4);
hp[12] = makeHDR(3);
hp[13] = makeFUN(&&F_diff_V__V_);
hp[14] = makePTR(hp+8);
hp[15] = getPTR(L_sp[-6])[2];
atom = makePTR(hp+12);
hp += 16;
eval_ret_addr = &&LABEL_215;
goto EVAL;
LABEL_215:
switch (res) {
case C_Nil:
L_POP(7);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = makeINT(9);
hp[3] = makeCTR(C_Nil);
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = makeINT(5);
hp[7] = makePTR(hp+0);
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makeINT(1);
hp[11] = makePTR(hp+4);
hp[12] = makeHDR(3);
hp[13] = makeFUN(&&F_diff_V__V_);
hp[14] = makePTR(hp+8);
hp[15] = getPTR(L_sp[-7])[2];
atom = makePTR(hp+12);
hp += 16;
eval_ret_addr = &&LABEL_219;
goto EVAL;
LABEL_219:
switch (res) {
case C_Nil:
L_POP(8);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = makeINT(7);
hp[3] = makeCTR(C_Nil);
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = makeINT(5);
hp[7] = makePTR(hp+0);
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makeINT(3);
hp[11] = makePTR(hp+4);
hp[12] = makeHDR(3);
hp[13] = makeFUN(&&F_diff_V__V_);
hp[14] = makePTR(hp+8);
hp[15] = getPTR(L_sp[-8])[2];
atom = makePTR(hp+12);
hp += 16;
eval_ret_addr = &&LABEL_223;
goto EVAL;
LABEL_223:
switch (res) {
case C_Nil:
L_POP(9);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
case C_Cons:
L_POP(9);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
}
}
}
}
}
}
}
}
F_lengthAcc_V__V_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_224;
  goto GC_COLLECT;
}
  GC_RET_224:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_225;
goto EVAL;
LABEL_225:
switch (res) {
case C_Nil:
atom = getPTR(L_sp[-2])[2];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
case C_Cons:
hp[0] = makeINT(1+getINT(getPTR(L_sp[-2])[2]));
hp[1] = makeHDR(3);
hp[2] = makeFUN(&&F_lengthAcc_V__V_);
hp[3] = hp[0];
hp[4] = getPTR(L_sp[-1])[3];
atom = makePTR(hp+1);
hp += 5;
L_POP(2);
L_PUSH(atom);
goto F_lengthAcc_V__V_;
}
F_fromTo_V__V_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_227;
  goto GC_COLLECT;
}
  GC_RET_227:
res = getINT(getPTR(L_sp[-1])[2])<=getINT(getPTR(L_sp[-1])[3])? C_True : C_False;
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
hp[0] = makeINT(getINT(getPTR(L_sp[-2])[2])+1);
hp[1] = makeHDR(3);
hp[2] = makeFUN(&&F_fromTo_V__V_);
hp[3] = hp[0];
hp[4] = getPTR(L_sp[-2])[3];
hp[5] = makeHDR(3);
hp[6] = makeCTR(C_Cons);
hp[7] = getPTR(L_sp[-2])[2];
hp[8] = makePTR(hp+1);
atom = makePTR(hp+5);
hp += 9;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
case C_False:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
}
F_cmp_V__V_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_230;
  goto GC_COLLECT;
}
  GC_RET_230:
res = getINT(getPTR(L_sp[-1])[2])==getINT(getPTR(L_sp[-1])[3])? C_True : C_False;
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
L_POP(2);
L_PUSH(makeCTR(C_EQ));
res = C_EQ;
goto EVAL_RET;
case C_False:
res = getINT(getPTR(L_sp[-2])[2])<=getINT(getPTR(L_sp[-2])[3])? C_True : C_False;
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
L_POP(3);
L_PUSH(makeCTR(C_LT));
res = C_LT;
goto EVAL_RET;
case C_False:
L_POP(3);
L_PUSH(makeCTR(C_GT));
res = C_GT;
goto EVAL_RET;
}
}
F_diff_V__V_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_231;
  goto GC_COLLECT;
}
  GC_RET_231:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_232;
goto EVAL;
LABEL_232:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
atom = getPTR(L_sp[-2])[3];
getPTR(L_sp[-2])[3] = makeINT(0);
eval_ret_addr = &&LABEL_233;
goto EVAL;
LABEL_233:
switch (res) {
case C_Nil:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+0);
hp += 4;
L_POP(3);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_cmp_V__V_);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_234;
goto EVAL;
LABEL_234:
switch (res) {
case C_LT:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_diff_V__V_);
hp[6] = getPTR(L_sp[-3])[3];
hp[7] = makePTR(hp+0);
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = getPTR(L_sp[-3])[2];
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(4);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
case C_EQ:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_diff_V__V_);
hp[2] = getPTR(L_sp[-3])[3];
hp[3] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+0);
hp += 4;
L_POP(4);
L_PUSH(atom);
goto F_diff_V__V_;
case C_GT:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = getPTR(L_sp[-3])[2];
hp[3] = getPTR(L_sp[-3])[3];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_diff_V__V_);
hp[6] = makePTR(hp+0);
hp[7] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+4);
hp += 8;
L_POP(4);
L_PUSH(atom);
goto F_diff_V__V_;
}
}
}
F_insert_V__V_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_238;
  goto GC_COLLECT;
}
  GC_RET_238:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_239;
goto EVAL;
LABEL_239:
switch (res) {
case C_Nil:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = makeCTR(C_Nil);
atom = makePTR(hp+0);
hp += 4;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
case C_Cons:
res = getINT(getPTR(L_sp[-2])[2])<=getINT(getPTR(L_sp[-1])[2])? C_True : C_False;
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = getPTR(L_sp[-3])[2];
hp[7] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 8;
L_POP(3);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
case C_False:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_insert_V__V_);
hp[2] = getPTR(L_sp[-3])[2];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = getPTR(L_sp[-2])[2];
hp[7] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 8;
L_POP(3);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
}
F_moveval_V__V__V_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_242;
  goto GC_COLLECT;
}
  GC_RET_242:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_insert_V__V_);
hp[2] = getPTR(L_sp[-1])[4];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_analysis_V__V_);
hp[6] = getPTR(L_sp[-1])[3];
hp[7] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 8;
eval_ret_addr = &&LABEL_244;
goto EVAL;
LABEL_244:
switch (res) {
case C_Loss:
L_POP(2);
L_PUSH(makeCTR(C_Win));
res = C_Win;
goto EVAL_RET;
case C_Draw:
L_POP(2);
L_PUSH(makeCTR(C_Draw));
res = C_Draw;
goto EVAL_RET;
case C_Win:
L_POP(2);
L_PUSH(makeCTR(C_Loss));
res = C_Loss;
goto EVAL_RET;
}
F_mapme_V__V__V_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_245;
  goto GC_COLLECT;
}
  GC_RET_245:
atom = getPTR(L_sp[-1])[4];
getPTR(L_sp[-1])[4] = makeINT(0);
eval_ret_addr = &&LABEL_246;
goto EVAL;
LABEL_246:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(4);
hp[1] = makeFUN(&&F_moveval_V__V__V_);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = getPTR(L_sp[-1])[2];
hp[5] = makeHDR(4);
hp[6] = makeFUN(&&F_mapme_V__V__V_);
hp[7] = getPTR(L_sp[-2])[2];
hp[8] = getPTR(L_sp[-2])[3];
hp[9] = getPTR(L_sp[-1])[3];
hp[10] = makeHDR(3);
hp[11] = makeCTR(C_Cons);
hp[12] = makePTR(hp+0);
hp[13] = makePTR(hp+5);
atom = makePTR(hp+10);
hp += 14;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
F_bestOf_V__V_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_249;
  goto GC_COLLECT;
}
  GC_RET_249:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_250;
goto EVAL;
LABEL_250:
switch (res) {
case C_Win:
L_POP(2);
L_PUSH(makeCTR(C_Win));
res = C_Win;
goto EVAL_RET;
case C_Loss:
atom = getPTR(L_sp[-2])[3];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
case C_Draw:
atom = getPTR(L_sp[-2])[3];
getPTR(L_sp[-2])[3] = makeINT(0);
eval_ret_addr = &&LABEL_251;
goto EVAL;
LABEL_251:
switch (res) {
case C_Win:
L_POP(3);
L_PUSH(makeCTR(C_Win));
res = C_Win;
goto EVAL_RET;
case C_Draw:
L_POP(3);
L_PUSH(makeCTR(C_Draw));
res = C_Draw;
goto EVAL_RET;
case C_Loss:
L_POP(3);
L_PUSH(makeCTR(C_Draw));
res = C_Draw;
goto EVAL_RET;
}
}
F_best_V_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_252;
  goto GC_COLLECT;
}
  GC_RET_252:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_253;
goto EVAL;
LABEL_253:
switch (res) {
case C_Cons:
atom = getPTR(L_sp[-1])[3];
eval_ret_addr = &&LABEL_254;
goto EVAL;
LABEL_254:
switch (res) {
case C_Nil:
atom = getPTR(L_sp[-2])[2];
L_POP(3);
goto TAIL_EVAL;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-1])[3];
hp[4] = makeHDR(2);
hp[5] = makeFUN(&&F_best_V_);
hp[6] = makePTR(hp+0);
hp[7] = makeHDR(3);
hp[8] = makeFUN(&&F_bestOf_V__V_);
hp[9] = getPTR(L_sp[-2])[2];
hp[10] = makePTR(hp+4);
atom = makePTR(hp+7);
hp += 11;
L_POP(3);
L_PUSH(atom);
goto F_bestOf_V__V_;
}
}
F_analysis_V__V_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_257;
  goto GC_COLLECT;
}
  GC_RET_257:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_hasLine_V_);
hp[2] = getPTR(L_sp[-1])[3];
atom = makePTR(hp+0);
hp += 3;
eval_ret_addr = &&LABEL_258;
goto EVAL;
LABEL_258:
switch (res) {
case C_True:
L_POP(2);
L_PUSH(makeCTR(C_Loss));
res = C_Loss;
goto EVAL_RET;
case C_False:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_lengthAcc_V__V_);
hp[2] = makeINT(0);
hp[3] = getPTR(L_sp[-2])[2];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_259;
goto EVAL;
LABEL_259:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_lengthAcc_V__V_);
hp[2] = makeINT(0);
hp[3] = getPTR(L_sp[-3])[3];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_260;
goto EVAL;
LABEL_260:
L_POP(1);
res = getINT(L_top) + res;
L_POP(1);
L_PUSH(makeINT(res));
L_PUSH(makeINT(9));
res = 9;
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(1);
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
L_POP(3);
L_PUSH(makeCTR(C_Draw));
res = C_Draw;
goto EVAL_RET;
case C_False:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_fromTo_V__V_);
hp[2] = makeINT(1);
hp[3] = makeINT(9);
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_diff_V__V_);
hp[6] = makePTR(hp+0);
hp[7] = getPTR(L_sp[-3])[2];
hp[8] = makeHDR(3);
hp[9] = makeFUN(&&F_diff_V__V_);
hp[10] = makePTR(hp+4);
hp[11] = getPTR(L_sp[-3])[3];
hp[12] = makeHDR(4);
hp[13] = makeFUN(&&F_mapme_V__V__V_);
hp[14] = getPTR(L_sp[-3])[2];
hp[15] = getPTR(L_sp[-3])[3];
hp[16] = makePTR(hp+8);
hp[17] = makeHDR(2);
hp[18] = makeFUN(&&F_best_V_);
hp[19] = makePTR(hp+12);
atom = makePTR(hp+17);
hp += 20;
L_POP(3);
L_PUSH(atom);
goto F_best_V_;
}
}
F_report_V__V_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_265;
  goto GC_COLLECT;
}
  GC_RET_265:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_266;
goto EVAL;
LABEL_266:
switch (res) {
case C_Loss:
atom = getPTR(L_sp[-2])[3];
getPTR(L_sp[-2])[3] = makeINT(0);
eval_ret_addr = &&LABEL_267;
goto EVAL;
LABEL_267:
switch (res) {
case C_O:
L_POP(3);
L_PUSH(makeINT(88));
res = 88;
goto EVAL_RET;
case C_X:
L_POP(3);
L_PUSH(makeINT(79));
res = 79;
goto EVAL_RET;
}
case C_Win:
atom = getPTR(L_sp[-2])[3];
getPTR(L_sp[-2])[3] = makeINT(0);
eval_ret_addr = &&LABEL_268;
goto EVAL;
LABEL_268:
switch (res) {
case C_O:
L_POP(3);
L_PUSH(makeINT(79));
res = 79;
goto EVAL_RET;
case C_X:
L_POP(3);
L_PUSH(makeINT(88));
res = 88;
goto EVAL_RET;
}
case C_Draw:
L_POP(2);
L_PUSH(makeINT(68));
res = 68;
goto EVAL_RET;
}
F_adjudicate_V__V_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_269;
  goto GC_COLLECT;
}
  GC_RET_269:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_lengthAcc_V__V_);
hp[2] = makeINT(0);
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_lengthAcc_V__V_);
hp[6] = makeINT(0);
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(3);
hp[9] = makeFUN(&&F_cmp_Q__Q_);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
eval_ret_addr = &&LABEL_272;
goto EVAL;
LABEL_272:
switch (res) {
case C_GT:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_analysis_V__V_);
hp[2] = getPTR(L_sp[-2])[3];
hp[3] = getPTR(L_sp[-2])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_report_V__V_);
hp[6] = makePTR(hp+0);
hp[7] = makeCTR(C_X);
atom = makePTR(hp+4);
hp += 8;
L_POP(2);
L_PUSH(atom);
goto F_report_V__V_;
case C_EQ:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_hasLine_V_);
hp[2] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+0);
hp += 3;
eval_ret_addr = &&LABEL_274;
goto EVAL;
LABEL_274:
switch (res) {
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_report_V__V_);
hp[2] = makeCTR(C_Win);
hp[3] = makeCTR(C_X);
atom = makePTR(hp+0);
hp += 4;
L_POP(3);
L_PUSH(atom);
goto F_report_V__V_;
case C_False:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_hasLine_V_);
hp[2] = getPTR(L_sp[-3])[2];
atom = makePTR(hp+0);
hp += 3;
eval_ret_addr = &&LABEL_275;
goto EVAL;
LABEL_275:
switch (res) {
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_report_V__V_);
hp[2] = makeCTR(C_Win);
hp[3] = makeCTR(C_O);
atom = makePTR(hp+0);
hp += 4;
L_POP(4);
L_PUSH(atom);
goto F_report_V__V_;
case C_False:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_analysis_V__V_);
hp[2] = getPTR(L_sp[-4])[3];
hp[3] = getPTR(L_sp[-4])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_report_V__V_);
hp[6] = makePTR(hp+0);
hp[7] = makeCTR(C_X);
atom = makePTR(hp+4);
hp += 8;
L_POP(4);
L_PUSH(atom);
goto F_report_V__V_;
}
}
case C_LT:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_analysis_V__V_);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_report_V__V_);
hp[6] = makePTR(hp+0);
hp[7] = makeCTR(C_O);
atom = makePTR(hp+4);
hp += 8;
L_POP(2);
L_PUSH(atom);
goto F_report_V__V_;
}
F_main:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_278;
  goto GC_COLLECT;
}
  GC_RET_278:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_adjudicate_V__V_);
hp[2] = makeCTR(C_Nil);
hp[3] = makeCTR(C_Nil);
atom = makePTR(hp+0);
hp += 4;
L_POP(1);
L_PUSH(atom);
goto F_adjudicate_V__V_;
P_ADD:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_279;
  goto GC_COLLECT;
}
  GC_RET_279:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_280;
goto EVAL;
LABEL_280:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_281;
goto EVAL;
LABEL_281:
L_POP(1);
res = getINT(L_top) + res;
L_POP(2);
L_PUSH(makeINT(res));
goto EVAL_RET;
P_SUB:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_282;
  goto GC_COLLECT;
}
  GC_RET_282:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_283;
goto EVAL;
LABEL_283:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_284;
goto EVAL;
LABEL_284:
L_POP(1);
res = getINT(L_top) - res;
L_POP(2);
L_PUSH(makeINT(res));
goto EVAL_RET;
P_EQ:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_285;
  goto GC_COLLECT;
}
  GC_RET_285:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_286;
goto EVAL;
LABEL_286:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_287;
goto EVAL;
LABEL_287:
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(2);
L_PUSH(makeCTR(res));
goto EVAL_RET;
P_NEQ:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_288;
  goto GC_COLLECT;
}
  GC_RET_288:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_289;
goto EVAL;
LABEL_289:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_290;
goto EVAL;
LABEL_290:
L_POP(1);
res = getINT(L_top) != res ? C_True : C_False;
L_POP(2);
L_PUSH(makeCTR(res));
goto EVAL_RET;
P_LEQ:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_291;
  goto GC_COLLECT;
}
  GC_RET_291:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_292;
goto EVAL;
LABEL_292:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_293;
goto EVAL;
LABEL_293:
L_POP(1);
res = getINT(L_top) <= res ? C_True : C_False;
L_POP(2);
L_PUSH(makeCTR(res));
goto EVAL_RET;
GC_COPY:
if (from[0] == VISITED) {
  atom = from[1];
  goto *gc_copy_ret;
}
if (isPTR(from[1])) { from = getPTR(from[1]); goto GC_COPY; }
if (size(from[0]) == 1) { atom = from[1]; }
else {
  n = size(from[0]) + 1;
  //printf("Copy (%i);\n", n-1);
  atom = makePTR(free);
  for (i = 0; i < n; i++)
    { *free = from[i]; free++; }
  from[0] = VISITED;
  from[1] = atom;
}
goto *gc_copy_ret;
GC_COLLECT:
//printf("GC invoked (%i);\n", hp - fromSpace);
scan = toSpace;
free = toSpace;
for (p = L_base; p < L_sp; p++) {
  if (isPTR(*p)) {
    from = getPTR(*p);
    gc_copy_ret = &&GC_COPY_RET1; goto GC_COPY; GC_COPY_RET1:
    *p = atom;
  }
}
while (scan < free) {
  m = size(*scan); scan++;
  //printf("Scan (%i);\n", m);
  for (j = 0; j < m; j++) {
    if (isPTR(*scan)) {
      from = getPTR(*scan);
      gc_copy_ret = &&GC_COPY_RET2; goto GC_COPY; GC_COPY_RET2:
      *scan = atom;
    }
    scan++;
  }
}
for (frame = R_base; frame > R_sp; frame--) {
  p = frame->current;
  frame->current = 0;
  while (p && p[0] != VISITED && isPTR(p[1])) p = getPTR(p[1]);
  if (p && p[0] == VISITED) {
    if (isPTR(p[1])) frame->current = getPTR(p[1]);
  }
}
hp = free;
p = fromSpace; fromSpace = toSpace; toSpace = p;
p = fromSpaceEnd; fromSpaceEnd = toSpaceEnd; toSpaceEnd = p;
heapEnd = fromSpaceEnd;
L_top = L_sp[-1];
R_top_returnAddress = R_sp[1].returnAddress;
R_top_current = R_sp[1].current;
//printf("GC finished (%i);\n", hp - fromSpace);
goto *gc_ret;
}



