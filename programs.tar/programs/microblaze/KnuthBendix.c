#include <stdio.h>
#include <stdlib.h>
typedef unsigned int Atom;
#define isPTR(a)   (((a)&3) == 0)
#define isCTR(a)   (((a)&3) == 1)
#define isINT(a)   (((a)&3) == 2)
#define isFUN(a)   (((a)&3) == 3)
#define getPTR(a)  ((Atom*) (a))
#define getCTR(a)  ((a) >> 2)
#define getINT(a)  ((int) (((int) (a)) >> 2))
#define getFUN(a)  ((void*) (((unsigned int) (a)) & (~3)))
#define makePTR(x) ((Atom) (x))
#define makeCTR(x) ((Atom) (((x) << 2) | 1))
#define makeINT(x) ((Atom) ((((unsigned int) (x)) << 2) | 2))
#define makeFUN(x) ((Atom) (((unsigned int) (x)) | 3))
#define HEAP_SIZE 22000
#define STACK_SIZE 3000
typedef struct {
  Atom* current;
  void* returnAddress;
} Frame;
#define L_POP(n) L_sp-=n; L_top = L_sp[-1];
#define L_PUSH(a) L_top = a; L_sp[0] = L_top; L_sp++;
#define R_POP \
  R_sp++;\
  R_top_returnAddress = R_sp[1].returnAddress;\
  R_top_current = R_sp[1].current;
#define R_PUSH(ra, cur) \
  R_top_returnAddress = R_sp[0].returnAddress = ra; \
  R_top_current = R_sp[0].current = cur; \
  R_sp--;
#define makeHDR(x)        ((x) << 1)
#define VISITED           1
#define size(x)           ((x) >> 1)
#define C_False 0
#define C_True 1
#define C_Cons 0
#define C_Nil 1
#define C_Just 0
#define C_Nothing 1
#define C_Pair 0
#define C_Weights 0
#define C_Fun 0
#define C_Var 1


int main() {
register Atom* L_sp;
Atom* L_base;
register Atom L_top;
register Frame* R_sp;
Frame* R_base;
register void* R_top_returnAddress;
register Atom* R_top_current;
register Atom* hp;
register Atom* heapEnd;
register Atom atom;
register Atom* app;
register int res;
Atom* fromSpace;
Atom* toSpace;
Atom* fromSpaceEnd;
Atom* toSpaceEnd;
Atom* scan;
Atom* free;
Atom* p;
Atom* from;
Frame* frame;
void* gc_copy_ret;
void* gc_ret;
void* eval_ret_addr;
int i;
int j;
int n;
int m;
L_base = L_sp = malloc(sizeof(Atom) * STACK_SIZE);
R_base = R_sp = (Frame*) &L_sp[STACK_SIZE-1];
fromSpace = hp = malloc(sizeof(Atom) * HEAP_SIZE);
heapEnd = fromSpaceEnd = &fromSpace[HEAP_SIZE-1000];
toSpace = malloc(sizeof(Atom) * HEAP_SIZE);
toSpaceEnd = &toSpace[HEAP_SIZE-1000];
print("S");
atom = makePTR(hp);
*hp++ = makeHDR(1); *hp++ =  makeFUN(&&F_main);
L_PUSH(atom);
eval_ret_addr = &&LABEL_1907;
goto EVAL;
LABEL_1907:
putnum(getINT(L_top));
return 0;
EVAL:
if (isPTR(atom)) {
  app = getPTR(atom);
  EVAL_APP:
  if (isFUN(app[1])) {
    L_PUSH(makePTR(app));
    R_PUSH(eval_ret_addr, app);
    goto *getFUN(app[1]);
    EVAL_RET:
    if (R_top_current) {
      R_top_current[0] = makeHDR(1);
      R_top_current[1] = L_top;
    }
    eval_ret_addr = R_top_returnAddress;
    R_POP;
    goto *eval_ret_addr;
  }
  else if (isCTR(app[1])) {
    L_PUSH(makePTR(app)); res = getCTR(app[1]);
    goto *eval_ret_addr;
  }
  else if (isPTR(app[1])) {
    app = getPTR(app[1]);
    goto EVAL_APP;
  }
  else {
    L_PUSH(app[1]); res = getINT(app[1]);
    goto *eval_ret_addr;
  }
} else {
  L_PUSH(atom);
  res = getINT(atom);
  goto *eval_ret_addr;
}
TAIL_EVAL:
if (isPTR(atom)) {
  app = getPTR(atom);
  TAIL_EVAL_APP:
  if (isFUN(app[1])) {
    L_PUSH(makePTR(app));
    if (R_top_current) {
      R_top_current[0] = makeHDR(1);
      R_top_current[1] = makePTR(app);
    }
    R_top_current = R_sp[1].current = app;
    goto *getFUN(app[1]);
  }
  else if (isPTR(app[1])) {
    app = getPTR(app[1]);
    goto TAIL_EVAL_APP;
  }
  else if (isINT(app[1])) {
    L_PUSH(app[1]); res = getINT(app[1]);
    goto EVAL_RET;
  }
  else {
    L_PUSH(makePTR(app)); res = getCTR(app[1]);
    goto EVAL_RET;
  }
} else {
  L_PUSH(atom);
  res = getINT(atom);
  goto EVAL_RET;
}
F_main:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1908;
  goto GC_COLLECT;
}
  GC_RET_1908:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = makeINT(43);
hp[3] = makeCTR(C_Nil);
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = makeINT(48);
hp[7] = makeCTR(C_Nil);
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Fun);
hp[10] = makePTR(hp+4);
hp[11] = makeCTR(C_Nil);
hp[12] = makeHDR(3);
hp[13] = makeCTR(C_Cons);
hp[14] = makeINT(88);
hp[15] = makeCTR(C_Nil);
hp[16] = makeHDR(2);
hp[17] = makeCTR(C_Var);
hp[18] = makePTR(hp+12);
hp[19] = makeHDR(3);
hp[20] = makeCTR(C_Cons);
hp[21] = makePTR(hp+16);
hp[22] = makeCTR(C_Nil);
hp[23] = makeHDR(3);
hp[24] = makeCTR(C_Cons);
hp[25] = makePTR(hp+8);
hp[26] = makePTR(hp+19);
hp[27] = makeHDR(3);
hp[28] = makeCTR(C_Fun);
hp[29] = makePTR(hp+0);
hp[30] = makePTR(hp+23);
hp[31] = makeHDR(3);
hp[32] = makeCTR(C_Cons);
hp[33] = makeINT(88);
hp[34] = makeCTR(C_Nil);
hp[35] = makeHDR(2);
hp[36] = makeCTR(C_Var);
hp[37] = makePTR(hp+31);
hp[38] = makeHDR(3);
hp[39] = makeCTR(C_Pair);
hp[40] = makePTR(hp+27);
hp[41] = makePTR(hp+35);
hp[42] = makeHDR(3);
hp[43] = makeCTR(C_Cons);
hp[44] = makeINT(43);
hp[45] = makeCTR(C_Nil);
hp[46] = makeHDR(3);
hp[47] = makeCTR(C_Cons);
hp[48] = makeINT(45);
hp[49] = makeCTR(C_Nil);
hp[50] = makeHDR(3);
hp[51] = makeCTR(C_Cons);
hp[52] = makeINT(88);
hp[53] = makeCTR(C_Nil);
hp[54] = makeHDR(2);
hp[55] = makeCTR(C_Var);
hp[56] = makePTR(hp+50);
hp[57] = makeHDR(3);
hp[58] = makeCTR(C_Cons);
hp[59] = makePTR(hp+54);
hp[60] = makeCTR(C_Nil);
hp[61] = makeHDR(3);
hp[62] = makeCTR(C_Fun);
hp[63] = makePTR(hp+46);
hp[64] = makePTR(hp+57);
hp[65] = makeHDR(3);
hp[66] = makeCTR(C_Cons);
hp[67] = makeINT(88);
hp[68] = makeCTR(C_Nil);
hp[69] = makeHDR(2);
hp[70] = makeCTR(C_Var);
hp[71] = makePTR(hp+65);
hp[72] = makeHDR(3);
hp[73] = makeCTR(C_Cons);
hp[74] = makePTR(hp+69);
hp[75] = makeCTR(C_Nil);
hp[76] = makeHDR(3);
hp[77] = makeCTR(C_Cons);
hp[78] = makePTR(hp+61);
hp[79] = makePTR(hp+72);
hp[80] = makeHDR(3);
hp[81] = makeCTR(C_Fun);
hp[82] = makePTR(hp+42);
hp[83] = makePTR(hp+76);
hp[84] = makeHDR(3);
hp[85] = makeCTR(C_Cons);
hp[86] = makeINT(48);
hp[87] = makeCTR(C_Nil);
hp[88] = makeHDR(3);
hp[89] = makeCTR(C_Fun);
hp[90] = makePTR(hp+84);
hp[91] = makeCTR(C_Nil);
hp[92] = makeHDR(3);
hp[93] = makeCTR(C_Pair);
hp[94] = makePTR(hp+80);
hp[95] = makePTR(hp+88);
hp[96] = makeHDR(3);
hp[97] = makeCTR(C_Cons);
hp[98] = makeINT(43);
hp[99] = makeCTR(C_Nil);
hp[100] = makeHDR(3);
hp[101] = makeCTR(C_Cons);
hp[102] = makeINT(43);
hp[103] = makeCTR(C_Nil);
hp[104] = makeHDR(3);
hp[105] = makeCTR(C_Cons);
hp[106] = makeINT(88);
hp[107] = makeCTR(C_Nil);
hp[108] = makeHDR(2);
hp[109] = makeCTR(C_Var);
hp[110] = makePTR(hp+104);
hp[111] = makeHDR(3);
hp[112] = makeCTR(C_Cons);
hp[113] = makeINT(89);
hp[114] = makeCTR(C_Nil);
hp[115] = makeHDR(2);
hp[116] = makeCTR(C_Var);
hp[117] = makePTR(hp+111);
hp[118] = makeHDR(3);
hp[119] = makeCTR(C_Cons);
hp[120] = makePTR(hp+115);
hp[121] = makeCTR(C_Nil);
hp[122] = makeHDR(3);
hp[123] = makeCTR(C_Cons);
hp[124] = makePTR(hp+108);
hp[125] = makePTR(hp+118);
hp[126] = makeHDR(3);
hp[127] = makeCTR(C_Fun);
hp[128] = makePTR(hp+100);
hp[129] = makePTR(hp+122);
hp[130] = makeHDR(3);
hp[131] = makeCTR(C_Cons);
hp[132] = makeINT(90);
hp[133] = makeCTR(C_Nil);
hp[134] = makeHDR(2);
hp[135] = makeCTR(C_Var);
hp[136] = makePTR(hp+130);
hp[137] = makeHDR(3);
hp[138] = makeCTR(C_Cons);
hp[139] = makePTR(hp+134);
hp[140] = makeCTR(C_Nil);
hp[141] = makeHDR(3);
hp[142] = makeCTR(C_Cons);
hp[143] = makePTR(hp+126);
hp[144] = makePTR(hp+137);
hp[145] = makeHDR(3);
hp[146] = makeCTR(C_Fun);
hp[147] = makePTR(hp+96);
hp[148] = makePTR(hp+141);
hp[149] = makeHDR(3);
hp[150] = makeCTR(C_Cons);
hp[151] = makeINT(43);
hp[152] = makeCTR(C_Nil);
hp[153] = makeHDR(3);
hp[154] = makeCTR(C_Cons);
hp[155] = makeINT(88);
hp[156] = makeCTR(C_Nil);
hp[157] = makeHDR(2);
hp[158] = makeCTR(C_Var);
hp[159] = makePTR(hp+153);
hp[160] = makeHDR(3);
hp[161] = makeCTR(C_Cons);
hp[162] = makeINT(43);
hp[163] = makeCTR(C_Nil);
hp[164] = makeHDR(3);
hp[165] = makeCTR(C_Cons);
hp[166] = makeINT(89);
hp[167] = makeCTR(C_Nil);
hp[168] = makeHDR(2);
hp[169] = makeCTR(C_Var);
hp[170] = makePTR(hp+164);
hp[171] = makeHDR(3);
hp[172] = makeCTR(C_Cons);
hp[173] = makeINT(90);
hp[174] = makeCTR(C_Nil);
hp[175] = makeHDR(2);
hp[176] = makeCTR(C_Var);
hp[177] = makePTR(hp+171);
hp[178] = makeHDR(3);
hp[179] = makeCTR(C_Cons);
hp[180] = makePTR(hp+175);
hp[181] = makeCTR(C_Nil);
hp[182] = makeHDR(3);
hp[183] = makeCTR(C_Cons);
hp[184] = makePTR(hp+168);
hp[185] = makePTR(hp+178);
hp[186] = makeHDR(3);
hp[187] = makeCTR(C_Fun);
hp[188] = makePTR(hp+160);
hp[189] = makePTR(hp+182);
hp[190] = makeHDR(3);
hp[191] = makeCTR(C_Cons);
hp[192] = makePTR(hp+186);
hp[193] = makeCTR(C_Nil);
hp[194] = makeHDR(3);
hp[195] = makeCTR(C_Cons);
hp[196] = makePTR(hp+157);
hp[197] = makePTR(hp+190);
hp[198] = makeHDR(3);
hp[199] = makeCTR(C_Fun);
hp[200] = makePTR(hp+149);
hp[201] = makePTR(hp+194);
hp[202] = makeHDR(3);
hp[203] = makeCTR(C_Pair);
hp[204] = makePTR(hp+145);
hp[205] = makePTR(hp+198);
hp[206] = makeHDR(3);
hp[207] = makeCTR(C_Cons);
hp[208] = makePTR(hp+202);
hp[209] = makeCTR(C_Nil);
hp[210] = makeHDR(3);
hp[211] = makeCTR(C_Cons);
hp[212] = makePTR(hp+92);
hp[213] = makePTR(hp+206);
hp[214] = makeHDR(3);
hp[215] = makeCTR(C_Cons);
hp[216] = makePTR(hp+38);
hp[217] = makePTR(hp+210);
hp[218] = makeHDR(3);
hp[219] = makeCTR(C_Cons);
hp[220] = makeINT(43);
hp[221] = makeCTR(C_Nil);
hp[222] = makeHDR(3);
hp[223] = makeCTR(C_Pair);
hp[224] = makeINT(2);
hp[225] = makeCTR(C_True);
hp[226] = makeHDR(3);
hp[227] = makeCTR(C_Pair);
hp[228] = makePTR(hp+218);
hp[229] = makePTR(hp+222);
hp[230] = makeHDR(3);
hp[231] = makeCTR(C_Cons);
hp[232] = makeINT(45);
hp[233] = makeCTR(C_Nil);
hp[234] = makeHDR(3);
hp[235] = makeCTR(C_Pair);
hp[236] = makeINT(1);
hp[237] = makeCTR(C_False);
hp[238] = makeHDR(3);
hp[239] = makeCTR(C_Pair);
hp[240] = makePTR(hp+230);
hp[241] = makePTR(hp+234);
hp[242] = makeHDR(3);
hp[243] = makeCTR(C_Cons);
hp[244] = makeINT(48);
hp[245] = makeCTR(C_Nil);
hp[246] = makeHDR(3);
hp[247] = makeCTR(C_Pair);
hp[248] = makeINT(0);
hp[249] = makeCTR(C_False);
hp[250] = makeHDR(3);
hp[251] = makeCTR(C_Pair);
hp[252] = makePTR(hp+242);
hp[253] = makePTR(hp+246);
hp[254] = makeHDR(3);
hp[255] = makeCTR(C_Cons);
hp[256] = makePTR(hp+250);
hp[257] = makeCTR(C_Nil);
hp[258] = makeHDR(3);
hp[259] = makeCTR(C_Cons);
hp[260] = makePTR(hp+238);
hp[261] = makePTR(hp+254);
hp[262] = makeHDR(3);
hp[263] = makeCTR(C_Cons);
hp[264] = makePTR(hp+226);
hp[265] = makePTR(hp+258);
hp[266] = makeHDR(2);
hp[267] = makeFUN(&&F_concatMapV);
hp[268] = makePTR(hp+269);
hp[269] = makeHDR(3);
hp[270] = makeCTR(C_Cons);
hp[271] = makeCTR(C_Nil);
hp[272] = makePTR(hp+266);
hp[273] = makeHDR(2);
hp[274] = makeFUN(&&F_main___0);
hp[275] = makePTR(hp+269);
hp[276] = makeHDR(4);
hp[277] = makeFUN(&&F_main___1);
hp[278] = makePTR(hp+262);
hp[279] = makePTR(hp+214);
hp[280] = makePTR(hp+273);
atom = makePTR(hp+276);
hp += 281;
L_POP(1);
L_PUSH(atom);
goto F_main___1;
F_main___0:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1977;
  goto GC_COLLECT;
}
  GC_RET_1977:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_1978;
goto EVAL;
LABEL_1978:
switch (res) {
case C_Cons:
atom = getPTR(L_sp[-1])[3];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
}
F_main___1:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_1979;
  goto GC_COLLECT;
}
  GC_RET_1979:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_allBothCT);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-1])[3];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_1980;
goto EVAL;
LABEL_1980:
switch (res) {
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = makeINT(10);
hp[3] = makeCTR(C_Nil);
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = makeINT(58);
hp[7] = makePTR(hp+0);
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makeINT(115);
hp[11] = makePTR(hp+4);
hp[12] = makeHDR(3);
hp[13] = makeCTR(C_Cons);
hp[14] = makeINT(110);
hp[15] = makePTR(hp+8);
hp[16] = makeHDR(3);
hp[17] = makeCTR(C_Cons);
hp[18] = makeINT(111);
hp[19] = makePTR(hp+12);
hp[20] = makeHDR(3);
hp[21] = makeCTR(C_Cons);
hp[22] = makeINT(105);
hp[23] = makePTR(hp+16);
hp[24] = makeHDR(3);
hp[25] = makeCTR(C_Cons);
hp[26] = makeINT(116);
hp[27] = makePTR(hp+20);
hp[28] = makeHDR(3);
hp[29] = makeCTR(C_Cons);
hp[30] = makeINT(97);
hp[31] = makePTR(hp+24);
hp[32] = makeHDR(3);
hp[33] = makeCTR(C_Cons);
hp[34] = makeINT(117);
hp[35] = makePTR(hp+28);
hp[36] = makeHDR(3);
hp[37] = makeCTR(C_Cons);
hp[38] = makeINT(113);
hp[39] = makePTR(hp+32);
hp[40] = makeHDR(3);
hp[41] = makeCTR(C_Cons);
hp[42] = makeINT(101);
hp[43] = makePTR(hp+36);
hp[44] = makeHDR(3);
hp[45] = makeCTR(C_Cons);
hp[46] = makeINT(32);
hp[47] = makePTR(hp+40);
hp[48] = makeHDR(3);
hp[49] = makeCTR(C_Cons);
hp[50] = makeINT(103);
hp[51] = makePTR(hp+44);
hp[52] = makeHDR(3);
hp[53] = makeCTR(C_Cons);
hp[54] = makeINT(110);
hp[55] = makePTR(hp+48);
hp[56] = makeHDR(3);
hp[57] = makeCTR(C_Cons);
hp[58] = makeINT(105);
hp[59] = makePTR(hp+52);
hp[60] = makeHDR(3);
hp[61] = makeCTR(C_Cons);
hp[62] = makeINT(115);
hp[63] = makePTR(hp+56);
hp[64] = makeHDR(3);
hp[65] = makeCTR(C_Cons);
hp[66] = makeINT(85);
hp[67] = makePTR(hp+60);
hp[68] = makeHDR(3);
hp[69] = makeFUN(&&F_mapSE);
hp[70] = getPTR(L_sp[-2])[2];
hp[71] = getPTR(L_sp[-2])[3];
hp[72] = makeHDR(2);
hp[73] = makeFUN(&&F_unlines);
hp[74] = makePTR(hp+68);
hp[75] = makeHDR(5);
hp[76] = makeFUN(&&F_completionLoop);
hp[77] = getPTR(L_sp[-2])[4];
hp[78] = makeINT(0);
hp[79] = getPTR(L_sp[-2])[3];
hp[80] = makeCTR(C_Nil);
hp[81] = makeHDR(4);
hp[82] = makeFUN(&&F_showResult);
hp[83] = getPTR(L_sp[-2])[4];
hp[84] = makePTR(hp+75);
hp[85] = getPTR(L_sp[-2])[2];
hp[86] = makeHDR(3);
hp[87] = makeFUN(&&F_emitStr);
hp[88] = makePTR(hp+81);
hp[89] = makeINT(0);
hp[90] = makeHDR(3);
hp[91] = makeFUN(&&F_emitStr);
hp[92] = makePTR(hp+72);
hp[93] = makePTR(hp+86);
hp[94] = makeHDR(3);
hp[95] = makeFUN(&&F_emitStr);
hp[96] = makePTR(hp+64);
hp[97] = makePTR(hp+90);
atom = makePTR(hp+94);
hp += 98;
L_POP(2);
L_PUSH(atom);
goto F_emitStr;
case C_False:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = makeINT(10);
hp[3] = makeCTR(C_Nil);
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = makeINT(110);
hp[7] = makePTR(hp+0);
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makeINT(111);
hp[11] = makePTR(hp+4);
hp[12] = makeHDR(3);
hp[13] = makeCTR(C_Cons);
hp[14] = makeINT(105);
hp[15] = makePTR(hp+8);
hp[16] = makeHDR(3);
hp[17] = makeCTR(C_Cons);
hp[18] = makeINT(116);
hp[19] = makePTR(hp+12);
hp[20] = makeHDR(3);
hp[21] = makeCTR(C_Cons);
hp[22] = makeINT(97);
hp[23] = makePTR(hp+16);
hp[24] = makeHDR(3);
hp[25] = makeCTR(C_Cons);
hp[26] = makeINT(117);
hp[27] = makePTR(hp+20);
hp[28] = makeHDR(3);
hp[29] = makeCTR(C_Cons);
hp[30] = makeINT(113);
hp[31] = makePTR(hp+24);
hp[32] = makeHDR(3);
hp[33] = makeCTR(C_Cons);
hp[34] = makeINT(101);
hp[35] = makePTR(hp+28);
hp[36] = makeHDR(3);
hp[37] = makeCTR(C_Cons);
hp[38] = makeINT(32);
hp[39] = makePTR(hp+32);
hp[40] = makeHDR(3);
hp[41] = makeCTR(C_Cons);
hp[42] = makeINT(100);
hp[43] = makePTR(hp+36);
hp[44] = makeHDR(3);
hp[45] = makeCTR(C_Cons);
hp[46] = makeINT(101);
hp[47] = makePTR(hp+40);
hp[48] = makeHDR(3);
hp[49] = makeCTR(C_Cons);
hp[50] = makeINT(109);
hp[51] = makePTR(hp+44);
hp[52] = makeHDR(3);
hp[53] = makeCTR(C_Cons);
hp[54] = makeINT(114);
hp[55] = makePTR(hp+48);
hp[56] = makeHDR(3);
hp[57] = makeCTR(C_Cons);
hp[58] = makeINT(111);
hp[59] = makePTR(hp+52);
hp[60] = makeHDR(3);
hp[61] = makeCTR(C_Cons);
hp[62] = makeINT(102);
hp[63] = makePTR(hp+56);
hp[64] = makeHDR(3);
hp[65] = makeCTR(C_Cons);
hp[66] = makeINT(45);
hp[67] = makePTR(hp+60);
hp[68] = makeHDR(3);
hp[69] = makeCTR(C_Cons);
hp[70] = makeINT(108);
hp[71] = makePTR(hp+64);
hp[72] = makeHDR(3);
hp[73] = makeCTR(C_Cons);
hp[74] = makeINT(108);
hp[75] = makePTR(hp+68);
hp[76] = makeHDR(3);
hp[77] = makeCTR(C_Cons);
hp[78] = makeINT(73);
hp[79] = makePTR(hp+72);
hp[80] = makeHDR(3);
hp[81] = makeFUN(&&F_emitStr);
hp[82] = makePTR(hp+76);
hp[83] = makeINT(0);
atom = makePTR(hp+80);
hp += 84;
L_POP(2);
L_PUSH(atom);
goto F_emitStr;
}
F_inc:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2024;
  goto GC_COLLECT;
}
  GC_RET_2024:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_2025;
goto EVAL;
LABEL_2025:
L_PUSH(makeINT(1));
res = 1;
L_POP(1);
res = getINT(L_top) + res;
L_POP(2);
L_PUSH(makeINT(res));
goto EVAL_RET;
F_dec:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2026;
  goto GC_COLLECT;
}
  GC_RET_2026:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_2027;
goto EVAL;
LABEL_2027:
L_PUSH(makeINT(1));
res = 1;
L_POP(1);
res = getINT(L_top) - res;
L_POP(2);
L_PUSH(makeINT(res));
goto EVAL_RET;
F_dis:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2028;
  goto GC_COLLECT;
}
  GC_RET_2028:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2029;
goto EVAL;
LABEL_2029:
switch (res) {
case C_True:
L_POP(2);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
case C_False:
atom = getPTR(L_sp[-2])[3];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
}
F_con:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2030;
  goto GC_COLLECT;
}
  GC_RET_2030:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2031;
goto EVAL;
LABEL_2031:
switch (res) {
case C_True:
atom = getPTR(L_sp[-2])[3];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
case C_False:
L_POP(2);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
}
F_not:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2032;
  goto GC_COLLECT;
}
  GC_RET_2032:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2033;
goto EVAL;
LABEL_2033:
switch (res) {
case C_True:
L_POP(2);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
case C_False:
L_POP(2);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
}
F_isNothing:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2034;
  goto GC_COLLECT;
}
  GC_RET_2034:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2035;
goto EVAL;
LABEL_2035:
switch (res) {
case C_Nothing:
L_POP(2);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
case C_Just:
L_POP(2);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
}
F_isJust:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2036;
  goto GC_COLLECT;
}
  GC_RET_2036:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2037;
goto EVAL;
LABEL_2037:
switch (res) {
case C_Nothing:
L_POP(2);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
case C_Just:
L_POP(2);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
}
F_fromJust:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2038;
  goto GC_COLLECT;
}
  GC_RET_2038:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2039;
goto EVAL;
LABEL_2039:
switch (res) {
case C_Just:
atom = getPTR(L_sp[-1])[2];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
}
F_maybeFst:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2040;
  goto GC_COLLECT;
}
  GC_RET_2040:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2041;
goto EVAL;
LABEL_2041:
switch (res) {
case C_Nothing:
atom = getPTR(L_sp[-2])[2];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
case C_Just:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_2042;
goto EVAL;
LABEL_2042:
switch (res) {
case C_Pair:
atom = getPTR(L_sp[-1])[2];
L_POP(3);
goto TAIL_EVAL;
goto EVAL_RET;
}
}
F_maybeSnd:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2043;
  goto GC_COLLECT;
}
  GC_RET_2043:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2044;
goto EVAL;
LABEL_2044:
switch (res) {
case C_Nothing:
atom = getPTR(L_sp[-2])[2];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
case C_Just:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_2045;
goto EVAL;
LABEL_2045:
switch (res) {
case C_Pair:
atom = getPTR(L_sp[-1])[3];
L_POP(3);
goto TAIL_EVAL;
goto EVAL_RET;
}
}
F_fst:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2046;
  goto GC_COLLECT;
}
  GC_RET_2046:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2047;
goto EVAL;
LABEL_2047:
switch (res) {
case C_Pair:
atom = getPTR(L_sp[-1])[2];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
}
F_snd:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2048;
  goto GC_COLLECT;
}
  GC_RET_2048:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2049;
goto EVAL;
LABEL_2049:
switch (res) {
case C_Pair:
atom = getPTR(L_sp[-1])[3];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
}
F_crossIdVar:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2050;
  goto GC_COLLECT;
}
  GC_RET_2050:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2051;
goto EVAL;
LABEL_2051:
switch (res) {
case C_Pair:
hp[0] = makeHDR(2);
hp[1] = makeCTR(C_Var);
hp[2] = getPTR(L_sp[-1])[3];
hp[3] = makeHDR(3);
hp[4] = makeCTR(C_Pair);
hp[5] = getPTR(L_sp[-1])[2];
hp[6] = makePTR(hp+0);
atom = makePTR(hp+3);
hp += 7;
L_POP(2);
L_PUSH(atom);
res = C_Pair;
goto EVAL_RET;
}
F_crossIdSubst:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2053;
  goto GC_COLLECT;
}
  GC_RET_2053:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2054;
goto EVAL;
LABEL_2054:
switch (res) {
case C_Pair:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_subst);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[3];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Pair);
hp[6] = getPTR(L_sp[-1])[2];
hp[7] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 8;
L_POP(2);
L_PUSH(atom);
res = C_Pair;
goto EVAL_RET;
}
F_null:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2056;
  goto GC_COLLECT;
}
  GC_RET_2056:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2057;
goto EVAL;
LABEL_2057:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
case C_Cons:
L_POP(2);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
}
F_head:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2058;
  goto GC_COLLECT;
}
  GC_RET_2058:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2059;
goto EVAL;
LABEL_2059:
switch (res) {
case C_Cons:
atom = getPTR(L_sp[-1])[2];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
}
F_tail:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2060;
  goto GC_COLLECT;
}
  GC_RET_2060:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2061;
goto EVAL;
LABEL_2061:
switch (res) {
case C_Cons:
atom = getPTR(L_sp[-1])[3];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
}
F_append:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2062;
  goto GC_COLLECT;
}
  GC_RET_2062:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2063;
goto EVAL;
LABEL_2063:
switch (res) {
case C_Nil:
atom = getPTR(L_sp[-2])[3];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_append);
hp[2] = getPTR(L_sp[-1])[3];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = getPTR(L_sp[-1])[2];
hp[7] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 8;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
F_elemByES:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2065;
  goto GC_COLLECT;
}
  GC_RET_2065:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2066;
goto EVAL;
LABEL_2066:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_equalStrings);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_2067;
goto EVAL;
LABEL_2067:
switch (res) {
case C_True:
L_POP(3);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
case C_False:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_elemByES);
hp[2] = getPTR(L_sp[-3])[2];
hp[3] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+0);
hp += 4;
L_POP(3);
L_PUSH(atom);
goto F_elemByES;
}
}
F_elemByEP:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2068;
  goto GC_COLLECT;
}
  GC_RET_2068:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2069;
goto EVAL;
LABEL_2069:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_equivPair);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_2070;
goto EVAL;
LABEL_2070:
switch (res) {
case C_True:
L_POP(3);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
case C_False:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_elemByEP);
hp[2] = getPTR(L_sp[-3])[2];
hp[3] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+0);
hp += 4;
L_POP(3);
L_PUSH(atom);
goto F_elemByEP;
}
}
F_elemAt:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2071;
  goto GC_COLLECT;
}
  GC_RET_2071:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2072;
goto EVAL;
LABEL_2072:
switch (res) {
case C_Cons:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_2073;
goto EVAL;
LABEL_2073:
L_PUSH(makeINT(0));
res = 0;
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(1);
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
atom = getPTR(L_sp[-2])[2];
L_POP(3);
goto TAIL_EVAL;
goto EVAL_RET;
case C_False:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&P_SUB);
hp[2] = getPTR(L_sp[-3])[3];
hp[3] = makeINT(1);
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_elemAt);
hp[6] = getPTR(L_sp[-2])[3];
hp[7] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 8;
L_POP(3);
L_PUSH(atom);
goto F_elemAt;
}
}
F_zip:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2075;
  goto GC_COLLECT;
}
  GC_RET_2075:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2076;
goto EVAL;
LABEL_2076:
switch (res) {
case C_Nil:
atom = getPTR(L_sp[-2])[3];
getPTR(L_sp[-2])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2077;
goto EVAL;
LABEL_2077:
switch (res) {
case C_Nil:
L_POP(3);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
L_POP(3);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
}
case C_Cons:
atom = getPTR(L_sp[-2])[3];
getPTR(L_sp[-2])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2078;
goto EVAL;
LABEL_2078:
switch (res) {
case C_Nil:
L_POP(3);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Pair);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_zip);
hp[6] = getPTR(L_sp[-2])[3];
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(3);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
}
F_unlines:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2081;
  goto GC_COLLECT;
}
  GC_RET_2081:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2082;
goto EVAL;
LABEL_2082:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_unlines);
hp[2] = getPTR(L_sp[-1])[3];
hp[3] = makeHDR(3);
hp[4] = makeCTR(C_Cons);
hp[5] = makeINT(10);
hp[6] = makePTR(hp+0);
hp[7] = makeHDR(3);
hp[8] = makeFUN(&&F_append);
hp[9] = getPTR(L_sp[-1])[2];
hp[10] = makePTR(hp+3);
atom = makePTR(hp+7);
hp += 11;
L_POP(2);
L_PUSH(atom);
goto F_append;
}
F_emitStr:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2085;
  goto GC_COLLECT;
}
  GC_RET_2085:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2086;
goto EVAL;
LABEL_2086:
switch (res) {
case C_Nil:
atom = getPTR(L_sp[-2])[3];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
case C_Cons:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_2087;
goto EVAL;
LABEL_2087:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_emitStr);
hp[2] = getPTR(L_sp[-2])[3];
hp[3] = getPTR(L_sp[-3])[3];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_2088;
goto EVAL;
LABEL_2088:
L_POP(1);
res = getINT(L_top) + res;
L_POP(3);
L_PUSH(makeINT(res));
goto EVAL_RET;
}
F_length:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2089;
  goto GC_COLLECT;
}
  GC_RET_2089:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2090;
goto EVAL;
LABEL_2090:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeINT(0));
res = 0;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_length);
hp[2] = getPTR(L_sp[-1])[3];
atom = makePTR(hp+0);
hp += 3;
eval_ret_addr = &&LABEL_2091;
goto EVAL;
LABEL_2091:
L_PUSH(makeINT(1));
res = 1;
L_POP(1);
res = getINT(L_top) + res;
L_POP(3);
L_PUSH(makeINT(res));
goto EVAL_RET;
}
F_repeat:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2092;
  goto GC_COLLECT;
}
  GC_RET_2092:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_repeat);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = makeHDR(3);
hp[4] = makeCTR(C_Cons);
hp[5] = getPTR(L_sp[-1])[2];
hp[6] = makePTR(hp+0);
atom = makePTR(hp+3);
hp += 7;
L_POP(1);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
F_last:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2094;
  goto GC_COLLECT;
}
  GC_RET_2094:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2095;
goto EVAL;
LABEL_2095:
switch (res) {
case C_Cons:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_null);
hp[2] = getPTR(L_sp[-1])[3];
atom = makePTR(hp+0);
hp += 3;
eval_ret_addr = &&LABEL_2096;
goto EVAL;
LABEL_2096:
switch (res) {
case C_True:
atom = getPTR(L_sp[-2])[2];
L_POP(3);
goto TAIL_EVAL;
goto EVAL_RET;
case C_False:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_last);
hp[2] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+0);
hp += 3;
L_POP(3);
L_PUSH(atom);
goto F_last;
}
}
F_enumFromTo:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2097;
  goto GC_COLLECT;
}
  GC_RET_2097:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_2098;
goto EVAL;
LABEL_2098:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_2099;
goto EVAL;
LABEL_2099:
L_POP(1);
res = getINT(L_top) <= res ? C_True : C_False;
L_POP(1);
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&P_ADD);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = makeINT(1);
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_enumFromTo);
hp[6] = makePTR(hp+0);
hp[7] = getPTR(L_sp[-2])[3];
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = getPTR(L_sp[-2])[2];
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
case C_False:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
}
F_sum:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2102;
  goto GC_COLLECT;
}
  GC_RET_2102:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2103;
goto EVAL;
LABEL_2103:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeINT(0));
res = 0;
goto EVAL_RET;
case C_Cons:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_2104;
goto EVAL;
LABEL_2104:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_sum);
hp[2] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+0);
hp += 3;
eval_ret_addr = &&LABEL_2105;
goto EVAL;
LABEL_2105:
L_POP(1);
res = getINT(L_top) + res;
L_POP(3);
L_PUSH(makeINT(res));
goto EVAL_RET;
}
F_concatStrings:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2106;
  goto GC_COLLECT;
}
  GC_RET_2106:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2107;
goto EVAL;
LABEL_2107:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_concatStrings);
hp[2] = getPTR(L_sp[-1])[3];
hp[3] = makeHDR(3);
hp[4] = makeFUN(&&F_append);
hp[5] = getPTR(L_sp[-1])[2];
hp[6] = makePTR(hp+0);
atom = makePTR(hp+3);
hp += 7;
L_POP(2);
L_PUSH(atom);
goto F_append;
}
F_and:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2109;
  goto GC_COLLECT;
}
  GC_RET_2109:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2110;
goto EVAL;
LABEL_2110:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_and);
hp[2] = getPTR(L_sp[-1])[3];
hp[3] = makeHDR(3);
hp[4] = makeFUN(&&F_con);
hp[5] = getPTR(L_sp[-1])[2];
hp[6] = makePTR(hp+0);
atom = makePTR(hp+3);
hp += 7;
L_POP(2);
L_PUSH(atom);
goto F_con;
}
F_unionBy:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2112;
  goto GC_COLLECT;
}
  GC_RET_2112:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2113;
goto EVAL;
LABEL_2113:
switch (res) {
case C_Nil:
atom = getPTR(L_sp[-2])[2];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_unionBy);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[3];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_insBy);
hp[6] = getPTR(L_sp[-1])[2];
hp[7] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 8;
L_POP(2);
L_PUSH(atom);
goto F_insBy;
}
F_insBy:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2115;
  goto GC_COLLECT;
}
  GC_RET_2115:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_elemByES);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-1])[3];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_2116;
goto EVAL;
LABEL_2116:
switch (res) {
case C_True:
atom = getPTR(L_sp[-2])[3];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
case C_False:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+0);
hp += 4;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
F_intersperse:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2117;
  goto GC_COLLECT;
}
  GC_RET_2117:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2118;
goto EVAL;
LABEL_2118:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
atom = getPTR(L_sp[-1])[3];
eval_ret_addr = &&LABEL_2119;
goto EVAL;
LABEL_2119:
switch (res) {
case C_Nil:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = makeCTR(C_Nil);
atom = makePTR(hp+0);
hp += 4;
L_POP(3);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-1])[3];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_intersperse);
hp[6] = getPTR(L_sp[-3])[2];
hp[7] = makePTR(hp+0);
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = getPTR(L_sp[-3])[2];
hp[11] = makePTR(hp+4);
hp[12] = makeHDR(3);
hp[13] = makeCTR(C_Cons);
hp[14] = getPTR(L_sp[-2])[2];
hp[15] = makePTR(hp+8);
atom = makePTR(hp+12);
hp += 16;
L_POP(3);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
}
F_nubBy:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2123;
  goto GC_COLLECT;
}
  GC_RET_2123:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_nubBySans);
hp[2] = makeCTR(C_Nil);
hp[3] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+0);
hp += 4;
L_POP(1);
L_PUSH(atom);
goto F_nubBySans;
F_nubBySans:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2124;
  goto GC_COLLECT;
}
  GC_RET_2124:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2125;
goto EVAL;
LABEL_2125:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_elemByEP);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-2])[2];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_2126;
goto EVAL;
LABEL_2126:
switch (res) {
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_nubBySans);
hp[2] = getPTR(L_sp[-3])[2];
hp[3] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+0);
hp += 4;
L_POP(3);
L_PUSH(atom);
goto F_nubBySans;
case C_False:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-3])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_nubBySans);
hp[6] = makePTR(hp+0);
hp[7] = getPTR(L_sp[-2])[3];
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = getPTR(L_sp[-2])[2];
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(3);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
}
F_lookUpBy:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2129;
  goto GC_COLLECT;
}
  GC_RET_2129:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2130;
goto EVAL;
LABEL_2130:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nothing));
res = C_Nothing;
goto EVAL_RET;
case C_Cons:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_2131;
goto EVAL;
LABEL_2131:
switch (res) {
case C_Pair:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_equalStrings);
hp[2] = getPTR(L_sp[-3])[2];
hp[3] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_2132;
goto EVAL;
LABEL_2132:
switch (res) {
case C_True:
hp[0] = makeHDR(2);
hp[1] = makeCTR(C_Just);
hp[2] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+0);
hp += 3;
L_POP(4);
L_PUSH(atom);
res = C_Just;
goto EVAL_RET;
case C_False:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_lookUpBy);
hp[2] = getPTR(L_sp[-4])[2];
hp[3] = getPTR(L_sp[-3])[3];
atom = makePTR(hp+0);
hp += 4;
L_POP(4);
L_PUSH(atom);
goto F_lookUpBy;
}
}
}
F_equalStrings:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2133;
  goto GC_COLLECT;
}
  GC_RET_2133:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2134;
goto EVAL;
LABEL_2134:
switch (res) {
case C_Nil:
atom = getPTR(L_sp[-2])[3];
getPTR(L_sp[-2])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2135;
goto EVAL;
LABEL_2135:
switch (res) {
case C_Nil:
L_POP(3);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
case C_Cons:
L_POP(3);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
}
case C_Cons:
atom = getPTR(L_sp[-2])[3];
getPTR(L_sp[-2])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2136;
goto EVAL;
LABEL_2136:
switch (res) {
case C_Nil:
L_POP(3);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&P_EQ);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_equalStrings);
hp[6] = getPTR(L_sp[-2])[3];
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(3);
hp[9] = makeFUN(&&F_con);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(3);
L_PUSH(atom);
goto F_con;
}
}
F_mapRn:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2139;
  goto GC_COLLECT;
}
  GC_RET_2139:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2140;
goto EVAL;
LABEL_2140:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_rn);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_mapRn);
hp[6] = getPTR(L_sp[-2])[2];
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
F_showResult:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2143;
  goto GC_COLLECT;
}
  GC_RET_2143:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2144;
goto EVAL;
LABEL_2144:
switch (res) {
case C_Just:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = makeINT(10);
hp[3] = makeCTR(C_Nil);
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = makeINT(115);
hp[7] = makePTR(hp+0);
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makeINT(115);
hp[11] = makePTR(hp+4);
hp[12] = makeHDR(3);
hp[13] = makeCTR(C_Cons);
hp[14] = makeINT(101);
hp[15] = makePTR(hp+8);
hp[16] = makeHDR(3);
hp[17] = makeCTR(C_Cons);
hp[18] = makeINT(99);
hp[19] = makePTR(hp+12);
hp[20] = makeHDR(3);
hp[21] = makeCTR(C_Cons);
hp[22] = makeINT(99);
hp[23] = makePTR(hp+16);
hp[24] = makeHDR(3);
hp[25] = makeCTR(C_Cons);
hp[26] = makeINT(117);
hp[27] = makePTR(hp+20);
hp[28] = makeHDR(3);
hp[29] = makeCTR(C_Cons);
hp[30] = makeINT(83);
hp[31] = makePTR(hp+24);
hp[32] = makeHDR(3);
hp[33] = makeCTR(C_Cons);
hp[34] = makeINT(10);
hp[35] = makePTR(hp+28);
hp[36] = makeHDR(3);
hp[37] = makeFUN(&&F_mapRn);
hp[38] = getPTR(L_sp[-2])[2];
hp[39] = getPTR(L_sp[-1])[2];
hp[40] = makeHDR(3);
hp[41] = makeFUN(&&F_mapSR);
hp[42] = getPTR(L_sp[-2])[4];
hp[43] = makePTR(hp+36);
hp[44] = makeHDR(2);
hp[45] = makeFUN(&&F_unlines);
hp[46] = makePTR(hp+40);
hp[47] = makeHDR(3);
hp[48] = makeFUN(&&F_append);
hp[49] = makePTR(hp+32);
hp[50] = makePTR(hp+44);
atom = makePTR(hp+47);
hp += 51;
L_POP(2);
L_PUSH(atom);
goto F_append;
case C_Nothing:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = makeINT(10);
hp[3] = makeCTR(C_Nil);
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = makeINT(101);
hp[7] = makePTR(hp+0);
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makeINT(114);
hp[11] = makePTR(hp+4);
hp[12] = makeHDR(3);
hp[13] = makeCTR(C_Cons);
hp[14] = makeINT(117);
hp[15] = makePTR(hp+8);
hp[16] = makeHDR(3);
hp[17] = makeCTR(C_Cons);
hp[18] = makeINT(108);
hp[19] = makePTR(hp+12);
hp[20] = makeHDR(3);
hp[21] = makeCTR(C_Cons);
hp[22] = makeINT(105);
hp[23] = makePTR(hp+16);
hp[24] = makeHDR(3);
hp[25] = makeCTR(C_Cons);
hp[26] = makeINT(97);
hp[27] = makePTR(hp+20);
hp[28] = makeHDR(3);
hp[29] = makeCTR(C_Cons);
hp[30] = makeINT(70);
hp[31] = makePTR(hp+24);
hp[32] = makeHDR(3);
hp[33] = makeCTR(C_Cons);
hp[34] = makeINT(10);
hp[35] = makePTR(hp+28);
atom = makePTR(hp+32);
hp += 36;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
F_varWeight:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2165;
  goto GC_COLLECT;
}
  GC_RET_2165:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2166;
goto EVAL;
LABEL_2166:
switch (res) {
case C_Weights:
atom = getPTR(L_sp[-1])[2];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
}
F_funWeight:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2167;
  goto GC_COLLECT;
}
  GC_RET_2167:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2168;
goto EVAL;
LABEL_2168:
switch (res) {
case C_Weights:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_lookUpBy);
hp[2] = getPTR(L_sp[-2])[3];
hp[3] = getPTR(L_sp[-1])[3];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_2169;
goto EVAL;
LABEL_2169:
switch (res) {
case C_Just:
atom = getPTR(L_sp[-1])[2];
L_POP(3);
goto TAIL_EVAL;
goto EVAL_RET;
}
}
F_mapFst:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2170;
  goto GC_COLLECT;
}
  GC_RET_2170:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2171;
goto EVAL;
LABEL_2171:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_mapFst___0);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = makeHDR(2);
hp[4] = makeFUN(&&F_mapFst);
hp[5] = getPTR(L_sp[-1])[3];
hp[6] = makeHDR(3);
hp[7] = makeCTR(C_Cons);
hp[8] = makePTR(hp+0);
hp[9] = makePTR(hp+3);
atom = makePTR(hp+6);
hp += 10;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
F_mapFst___0:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2174;
  goto GC_COLLECT;
}
  GC_RET_2174:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2175;
goto EVAL;
LABEL_2175:
switch (res) {
case C_Pair:
atom = getPTR(L_sp[-1])[2];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
}
F_funSequence:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2176;
  goto GC_COLLECT;
}
  GC_RET_2176:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2177;
goto EVAL;
LABEL_2177:
switch (res) {
case C_Weights:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_mapFst);
hp[2] = getPTR(L_sp[-1])[3];
atom = makePTR(hp+0);
hp += 3;
L_POP(2);
L_PUSH(atom);
goto F_mapFst;
}
F_order:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2178;
  goto GC_COLLECT;
}
  GC_RET_2178:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = makeINT(48);
hp[3] = makeCTR(C_Nil);
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Pair);
hp[6] = makePTR(hp+0);
hp[7] = makeINT(1);
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makeINT(43);
hp[11] = makeCTR(C_Nil);
hp[12] = makeHDR(3);
hp[13] = makeCTR(C_Pair);
hp[14] = makePTR(hp+8);
hp[15] = makeINT(0);
hp[16] = makeHDR(3);
hp[17] = makeCTR(C_Cons);
hp[18] = makeINT(45);
hp[19] = makeCTR(C_Nil);
hp[20] = makeHDR(3);
hp[21] = makeCTR(C_Pair);
hp[22] = makePTR(hp+16);
hp[23] = makeINT(0);
hp[24] = makeHDR(3);
hp[25] = makeCTR(C_Cons);
hp[26] = makePTR(hp+20);
hp[27] = makeCTR(C_Nil);
hp[28] = makeHDR(3);
hp[29] = makeCTR(C_Cons);
hp[30] = makePTR(hp+12);
hp[31] = makePTR(hp+24);
hp[32] = makeHDR(3);
hp[33] = makeCTR(C_Cons);
hp[34] = makePTR(hp+4);
hp[35] = makePTR(hp+28);
hp[36] = makeHDR(3);
hp[37] = makeCTR(C_Weights);
hp[38] = makeINT(1);
hp[39] = makePTR(hp+32);
hp[40] = makeHDR(4);
hp[41] = makeFUN(&&F_kbGreaterThan);
hp[42] = makePTR(hp+36);
hp[43] = getPTR(L_sp[-1])[2];
hp[44] = getPTR(L_sp[-1])[3];
atom = makePTR(hp+40);
hp += 45;
L_POP(1);
L_PUSH(atom);
goto F_kbGreaterThan;
F_arity:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2189;
  goto GC_COLLECT;
}
  GC_RET_2189:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&P_SUB);
hp[2] = makeINT(0);
hp[3] = makeINT(1);
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_lookUpBy);
hp[6] = getPTR(L_sp[-1])[3];
hp[7] = getPTR(L_sp[-1])[2];
hp[8] = makeHDR(3);
hp[9] = makeFUN(&&F_maybeFst);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(1);
L_PUSH(atom);
goto F_maybeFst;
F_isInfix:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2192;
  goto GC_COLLECT;
}
  GC_RET_2192:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_lookUpBy);
hp[2] = getPTR(L_sp[-1])[3];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_maybeSnd);
hp[6] = makeCTR(C_False);
hp[7] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 8;
L_POP(1);
L_PUSH(atom);
goto F_maybeSnd;
F_var:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2194;
  goto GC_COLLECT;
}
  GC_RET_2194:
hp[0] = makeHDR(2);
hp[1] = makeCTR(C_Var);
hp[2] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+0);
hp += 3;
L_POP(1);
L_PUSH(atom);
res = C_Var;
goto EVAL_RET;
F_fun:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2195;
  goto GC_COLLECT;
}
  GC_RET_2195:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Fun);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-1])[3];
atom = makePTR(hp+0);
hp += 4;
L_POP(1);
L_PUSH(atom);
res = C_Fun;
goto EVAL_RET;
F_allBothCT:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2196;
  goto GC_COLLECT;
}
  GC_RET_2196:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2197;
goto EVAL;
LABEL_2197:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
case C_Cons:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_2198;
goto EVAL;
LABEL_2198:
switch (res) {
case C_Pair:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_checkTerm);
hp[2] = getPTR(L_sp[-3])[2];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_checkTerm);
hp[6] = getPTR(L_sp[-3])[2];
hp[7] = getPTR(L_sp[-1])[2];
hp[8] = makeHDR(3);
hp[9] = makeFUN(&&F_allBothCT);
hp[10] = getPTR(L_sp[-3])[2];
hp[11] = getPTR(L_sp[-2])[3];
hp[12] = makeHDR(3);
hp[13] = makeFUN(&&F_con);
hp[14] = makePTR(hp+4);
hp[15] = makePTR(hp+8);
hp[16] = makeHDR(3);
hp[17] = makeFUN(&&F_con);
hp[18] = makePTR(hp+0);
hp[19] = makePTR(hp+12);
atom = makePTR(hp+16);
hp += 20;
L_POP(3);
L_PUSH(atom);
goto F_con;
}
}
F_allCT:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2203;
  goto GC_COLLECT;
}
  GC_RET_2203:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2204;
goto EVAL;
LABEL_2204:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_checkTerm);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_allCT);
hp[6] = getPTR(L_sp[-2])[2];
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(3);
hp[9] = makeFUN(&&F_con);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(2);
L_PUSH(atom);
goto F_con;
}
F_checkEquations:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2207;
  goto GC_COLLECT;
}
  GC_RET_2207:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_allBothCT);
hp[2] = getPTR(L_sp[-1])[3];
hp[3] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+0);
hp += 4;
L_POP(1);
L_PUSH(atom);
goto F_allBothCT;
F_checkTerm:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2208;
  goto GC_COLLECT;
}
  GC_RET_2208:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2209;
goto EVAL;
LABEL_2209:
switch (res) {
case C_Var:
L_POP(2);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
case C_Fun:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_length);
hp[2] = getPTR(L_sp[-1])[3];
hp[3] = makeHDR(3);
hp[4] = makeFUN(&&F_arity);
hp[5] = getPTR(L_sp[-2])[2];
hp[6] = getPTR(L_sp[-1])[2];
hp[7] = makeHDR(3);
hp[8] = makeFUN(&&P_EQ);
hp[9] = makePTR(hp+0);
hp[10] = makePTR(hp+3);
hp[11] = makeHDR(3);
hp[12] = makeFUN(&&F_allCT);
hp[13] = getPTR(L_sp[-2])[2];
hp[14] = getPTR(L_sp[-1])[3];
hp[15] = makeHDR(3);
hp[16] = makeFUN(&&F_con);
hp[17] = makePTR(hp+7);
hp[18] = makePTR(hp+11);
atom = makePTR(hp+15);
hp += 19;
L_POP(2);
L_PUSH(atom);
goto F_con;
}
F_mapVar:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2214;
  goto GC_COLLECT;
}
  GC_RET_2214:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2215;
goto EVAL;
LABEL_2215:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(2);
hp[1] = makeCTR(C_Var);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = makeHDR(2);
hp[4] = makeFUN(&&F_mapVar);
hp[5] = getPTR(L_sp[-1])[3];
hp[6] = makeHDR(3);
hp[7] = makeCTR(C_Cons);
hp[8] = makePTR(hp+0);
hp[9] = makePTR(hp+3);
atom = makePTR(hp+6);
hp += 10;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
F_rn:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2218;
  goto GC_COLLECT;
}
  GC_RET_2218:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2219;
goto EVAL;
LABEL_2219:
switch (res) {
case C_Pair:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_vars);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = makeHDR(2);
hp[4] = makeFUN(&&F_mapVar);
hp[5] = getPTR(L_sp[-2])[2];
hp[6] = makeHDR(3);
hp[7] = makeFUN(&&F_zip);
hp[8] = makePTR(hp+0);
hp[9] = makePTR(hp+3);
hp[10] = makeHDR(3);
hp[11] = makeFUN(&&F_subst);
hp[12] = makePTR(hp+6);
hp[13] = getPTR(L_sp[-1])[2];
hp[14] = makeHDR(3);
hp[15] = makeFUN(&&F_subst);
hp[16] = makePTR(hp+6);
hp[17] = getPTR(L_sp[-1])[3];
hp[18] = makeHDR(3);
hp[19] = makeCTR(C_Pair);
hp[20] = makePTR(hp+10);
hp[21] = makePTR(hp+14);
atom = makePTR(hp+18);
hp += 22;
L_POP(2);
L_PUSH(atom);
res = C_Pair;
goto EVAL_RET;
}
F_zipWithCIV:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2224;
  goto GC_COLLECT;
}
  GC_RET_2224:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2225;
goto EVAL;
LABEL_2225:
switch (res) {
case C_Nil:
atom = getPTR(L_sp[-2])[3];
getPTR(L_sp[-2])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2226;
goto EVAL;
LABEL_2226:
switch (res) {
case C_Nil:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Pair);
hp[2] = makeCTR(C_Nil);
hp[3] = makeCTR(C_Nil);
atom = makePTR(hp+0);
hp += 4;
L_POP(3);
L_PUSH(atom);
res = C_Pair;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-1])[3];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Pair);
hp[6] = makeCTR(C_Nil);
hp[7] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 8;
L_POP(3);
L_PUSH(atom);
res = C_Pair;
goto EVAL_RET;
}
case C_Cons:
atom = getPTR(L_sp[-2])[3];
getPTR(L_sp[-2])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2228;
goto EVAL;
LABEL_2228:
switch (res) {
case C_Nil:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Pair);
hp[2] = makeCTR(C_Nil);
hp[3] = makeCTR(C_Nil);
atom = makePTR(hp+0);
hp += 4;
L_POP(3);
L_PUSH(atom);
res = C_Pair;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_zipWithCIV);
hp[2] = getPTR(L_sp[-2])[3];
hp[3] = getPTR(L_sp[-1])[3];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_2229;
goto EVAL;
LABEL_2229:
switch (res) {
case C_Pair:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Pair);
hp[2] = getPTR(L_sp[-3])[2];
hp[3] = getPTR(L_sp[-2])[2];
hp[4] = makeHDR(2);
hp[5] = makeFUN(&&F_crossIdVar);
hp[6] = makePTR(hp+0);
hp[7] = makeHDR(3);
hp[8] = makeCTR(C_Cons);
hp[9] = makePTR(hp+4);
hp[10] = getPTR(L_sp[-1])[2];
hp[11] = makeHDR(3);
hp[12] = makeCTR(C_Pair);
hp[13] = makePTR(hp+7);
hp[14] = getPTR(L_sp[-1])[3];
atom = makePTR(hp+11);
hp += 15;
L_POP(4);
L_PUSH(atom);
res = C_Pair;
goto EVAL_RET;
}
}
}
F_renameNew:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2233;
  goto GC_COLLECT;
}
  GC_RET_2233:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2234;
goto EVAL;
LABEL_2234:
switch (res) {
case C_Pair:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_vars);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = makeHDR(3);
hp[4] = makeFUN(&&F_zipWithCIV);
hp[5] = makePTR(hp+0);
hp[6] = getPTR(L_sp[-2])[2];
atom = makePTR(hp+3);
hp += 7;
eval_ret_addr = &&LABEL_2236;
goto EVAL;
LABEL_2236:
switch (res) {
case C_Pair:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_subst);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-2])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_subst);
hp[6] = getPTR(L_sp[-1])[2];
hp[7] = getPTR(L_sp[-2])[3];
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Pair);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
hp[12] = makeHDR(3);
hp[13] = makeCTR(C_Pair);
hp[14] = makePTR(hp+8);
hp[15] = getPTR(L_sp[-1])[3];
atom = makePTR(hp+12);
hp += 16;
L_POP(3);
L_PUSH(atom);
res = C_Pair;
goto EVAL_RET;
}
}
F_renameNewList:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2240;
  goto GC_COLLECT;
}
  GC_RET_2240:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2241;
goto EVAL;
LABEL_2241:
switch (res) {
case C_Nil:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Pair);
hp[2] = makeCTR(C_Nil);
hp[3] = getPTR(L_sp[-2])[2];
atom = makePTR(hp+0);
hp += 4;
L_POP(2);
L_PUSH(atom);
res = C_Pair;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_renameNew);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_2242;
goto EVAL;
LABEL_2242:
switch (res) {
case C_Pair:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_renameNewList);
hp[2] = getPTR(L_sp[-1])[3];
hp[3] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_2243;
goto EVAL;
LABEL_2243:
switch (res) {
case C_Pair:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Pair);
hp[6] = makePTR(hp+0);
hp[7] = getPTR(L_sp[-1])[3];
atom = makePTR(hp+4);
hp += 8;
L_POP(4);
L_PUSH(atom);
res = C_Pair;
goto EVAL_RET;
}
}
}
F_complete:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2245;
  goto GC_COLLECT;
}
  GC_RET_2245:
hp[0] = makeHDR(5);
hp[1] = makeFUN(&&F_completionLoop);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = makeINT(0);
hp[4] = getPTR(L_sp[-1])[3];
hp[5] = makeCTR(C_Nil);
atom = makePTR(hp+0);
hp += 6;
L_POP(1);
L_PUSH(atom);
goto F_completionLoop;
F_completionLoop:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2246;
  goto GC_COLLECT;
}
  GC_RET_2246:
atom = getPTR(L_sp[-1])[4];
getPTR(L_sp[-1])[4] = makeINT(0);
eval_ret_addr = &&LABEL_2247;
goto EVAL;
LABEL_2247:
switch (res) {
case C_Nil:
hp[0] = makeHDR(2);
hp[1] = makeCTR(C_Just);
hp[2] = getPTR(L_sp[-2])[5];
atom = makePTR(hp+0);
hp += 3;
L_POP(2);
L_PUSH(atom);
res = C_Just;
goto EVAL_RET;
case C_Cons:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_2248;
goto EVAL;
LABEL_2248:
switch (res) {
case C_Pair:
atom = getPTR(L_sp[-3])[3];
eval_ret_addr = &&LABEL_2249;
goto EVAL;
LABEL_2249:
L_PUSH(makeINT(1000));
res = 1000;
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(1);
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
L_POP(4);
L_PUSH(makeCTR(C_Nothing));
res = C_Nothing;
goto EVAL_RET;
case C_False:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Pair);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_renameNew);
hp[6] = getPTR(L_sp[-4])[2];
hp[7] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 8;
eval_ret_addr = &&LABEL_2251;
goto EVAL;
LABEL_2251:
switch (res) {
case C_Pair:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_orient);
hp[2] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+0);
hp += 3;
eval_ret_addr = &&LABEL_2252;
goto EVAL;
LABEL_2252:
switch (res) {
case C_Nothing:
L_POP(6);
L_PUSH(makeCTR(C_Nothing));
res = C_Nothing;
goto EVAL_RET;
case C_Just:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&P_ADD);
hp[2] = getPTR(L_sp[-6])[3];
hp[3] = makeINT(1);
hp[4] = makeHDR(7);
hp[5] = makeFUN(&&F_completionWith);
hp[6] = getPTR(L_sp[-6])[2];
hp[7] = getPTR(L_sp[-2])[3];
hp[8] = makePTR(hp+0);
hp[9] = getPTR(L_sp[-5])[3];
hp[10] = getPTR(L_sp[-1])[2];
hp[11] = getPTR(L_sp[-6])[5];
atom = makePTR(hp+4);
hp += 12;
L_POP(6);
L_PUSH(atom);
goto F_completionWith;
}
}
}
}
}
F_completionWith:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2254;
  goto GC_COLLECT;
}
  GC_RET_2254:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = makeINT(43);
hp[3] = makeCTR(C_Nil);
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Pair);
hp[6] = makeINT(2);
hp[7] = makeCTR(C_True);
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Pair);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
hp[12] = makeHDR(3);
hp[13] = makeCTR(C_Cons);
hp[14] = makeINT(45);
hp[15] = makeCTR(C_Nil);
hp[16] = makeHDR(3);
hp[17] = makeCTR(C_Pair);
hp[18] = makeINT(1);
hp[19] = makeCTR(C_False);
hp[20] = makeHDR(3);
hp[21] = makeCTR(C_Pair);
hp[22] = makePTR(hp+12);
hp[23] = makePTR(hp+16);
hp[24] = makeHDR(3);
hp[25] = makeCTR(C_Cons);
hp[26] = makeINT(48);
hp[27] = makeCTR(C_Nil);
hp[28] = makeHDR(3);
hp[29] = makeCTR(C_Pair);
hp[30] = makeINT(0);
hp[31] = makeCTR(C_False);
hp[32] = makeHDR(3);
hp[33] = makeCTR(C_Pair);
hp[34] = makePTR(hp+24);
hp[35] = makePTR(hp+28);
hp[36] = makeHDR(3);
hp[37] = makeCTR(C_Cons);
hp[38] = makePTR(hp+32);
hp[39] = makeCTR(C_Nil);
hp[40] = makeHDR(3);
hp[41] = makeCTR(C_Cons);
hp[42] = makePTR(hp+20);
hp[43] = makePTR(hp+36);
hp[44] = makeHDR(3);
hp[45] = makeCTR(C_Cons);
hp[46] = makePTR(hp+8);
hp[47] = makePTR(hp+40);
hp[48] = makeHDR(8);
hp[49] = makeFUN(&&F_completionWith___0);
hp[50] = makePTR(hp+44);
hp[51] = getPTR(L_sp[-1])[6];
hp[52] = getPTR(L_sp[-1])[7];
hp[53] = getPTR(L_sp[-1])[3];
hp[54] = getPTR(L_sp[-1])[4];
hp[55] = getPTR(L_sp[-1])[5];
hp[56] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+48);
hp += 57;
L_POP(1);
L_PUSH(atom);
goto F_completionWith___0;
F_completionWith___0:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2266;
  goto GC_COLLECT;
}
  GC_RET_2266:
hp[0] = makeHDR(4);
hp[1] = makeFUN(&&F_simplifyRules);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-1])[3];
hp[4] = getPTR(L_sp[-1])[4];
atom = makePTR(hp+0);
hp += 5;
eval_ret_addr = &&LABEL_2267;
goto EVAL;
LABEL_2267:
switch (res) {
case C_Pair:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = getPTR(L_sp[-2])[3];
hp[3] = getPTR(L_sp[-2])[4];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = getPTR(L_sp[-2])[3];
hp[7] = getPTR(L_sp[-2])[4];
hp[8] = makeHDR(4);
hp[9] = makeFUN(&&F_getCriticalPairs);
hp[10] = getPTR(L_sp[-2])[8];
hp[11] = makePTR(hp+4);
hp[12] = getPTR(L_sp[-2])[3];
hp[13] = makeHDR(3);
hp[14] = makeFUN(&&F_append);
hp[15] = getPTR(L_sp[-1])[2];
hp[16] = makePTR(hp+8);
hp[17] = makeHDR(3);
hp[18] = makeFUN(&&F_append);
hp[19] = getPTR(L_sp[-2])[7];
hp[20] = makePTR(hp+13);
hp[21] = makeHDR(4);
hp[22] = makeFUN(&&F_simplifyEquations);
hp[23] = getPTR(L_sp[-2])[2];
hp[24] = makePTR(hp+0);
hp[25] = makePTR(hp+17);
hp[26] = makeHDR(3);
hp[27] = makeFUN(&&F_nubBySans);
hp[28] = makeCTR(C_Nil);
hp[29] = getPTR(L_sp[-1])[3];
hp[30] = makeHDR(5);
hp[31] = makeFUN(&&F_completionLoop);
hp[32] = getPTR(L_sp[-2])[5];
hp[33] = getPTR(L_sp[-2])[6];
hp[34] = makePTR(hp+21);
hp[35] = makePTR(hp+26);
atom = makePTR(hp+30);
hp += 36;
L_POP(2);
L_PUSH(atom);
goto F_completionLoop;
}
F_orient:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2275;
  goto GC_COLLECT;
}
  GC_RET_2275:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2276;
goto EVAL;
LABEL_2276:
switch (res) {
case C_Pair:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_order);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-1])[3];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_2277;
goto EVAL;
LABEL_2277:
switch (res) {
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Pair);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = makeHDR(2);
hp[5] = makeCTR(C_Just);
hp[6] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 7;
L_POP(3);
L_PUSH(atom);
res = C_Just;
goto EVAL_RET;
case C_False:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_order);
hp[2] = getPTR(L_sp[-2])[3];
hp[3] = getPTR(L_sp[-2])[2];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_2279;
goto EVAL;
LABEL_2279:
switch (res) {
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Pair);
hp[2] = getPTR(L_sp[-3])[3];
hp[3] = getPTR(L_sp[-3])[2];
hp[4] = makeHDR(2);
hp[5] = makeCTR(C_Just);
hp[6] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 7;
L_POP(4);
L_PUSH(atom);
res = C_Just;
goto EVAL_RET;
case C_False:
L_POP(4);
L_PUSH(makeCTR(C_Nothing));
res = C_Nothing;
goto EVAL_RET;
}
}
}
F_concatMapDCP:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2281;
  goto GC_COLLECT;
}
  GC_RET_2281:
atom = getPTR(L_sp[-1])[4];
getPTR(L_sp[-1])[4] = makeINT(0);
eval_ret_addr = &&LABEL_2282;
goto EVAL;
LABEL_2282:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(4);
hp[1] = makeFUN(&&F_duoCriticalPairs);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = getPTR(L_sp[-1])[2];
hp[5] = makeHDR(4);
hp[6] = makeFUN(&&F_concatMapDCP);
hp[7] = getPTR(L_sp[-2])[2];
hp[8] = getPTR(L_sp[-2])[3];
hp[9] = getPTR(L_sp[-1])[3];
hp[10] = makeHDR(3);
hp[11] = makeFUN(&&F_append);
hp[12] = makePTR(hp+0);
hp[13] = makePTR(hp+5);
atom = makePTR(hp+10);
hp += 14;
L_POP(2);
L_PUSH(atom);
goto F_append;
}
F_getCriticalPairs:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2285;
  goto GC_COLLECT;
}
  GC_RET_2285:
hp[0] = makeHDR(4);
hp[1] = makeFUN(&&F_selfCriticalPairs);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-1])[3];
hp[4] = getPTR(L_sp[-1])[4];
hp[5] = makeHDR(4);
hp[6] = makeFUN(&&F_concatMapDCP);
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = getPTR(L_sp[-1])[4];
hp[9] = getPTR(L_sp[-1])[3];
hp[10] = makeHDR(3);
hp[11] = makeFUN(&&F_append);
hp[12] = makePTR(hp+0);
hp[13] = makePTR(hp+5);
atom = makePTR(hp+10);
hp += 14;
L_POP(1);
L_PUSH(atom);
goto F_append;
F_mapNormRhs:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2288;
  goto GC_COLLECT;
}
  GC_RET_2288:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2289;
goto EVAL;
LABEL_2289:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_normRhs);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_mapNormRhs);
hp[6] = getPTR(L_sp[-2])[2];
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
F_simplifyRules:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2292;
  goto GC_COLLECT;
}
  GC_RET_2292:
hp[0] = makeHDR(4);
hp[1] = makeFUN(&&F_reduceSplit);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-1])[3];
hp[4] = getPTR(L_sp[-1])[4];
atom = makePTR(hp+0);
hp += 5;
eval_ret_addr = &&LABEL_2293;
goto EVAL;
LABEL_2293:
switch (res) {
case C_Pair:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = getPTR(L_sp[-2])[3];
hp[3] = getPTR(L_sp[-1])[3];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = getPTR(L_sp[-2])[3];
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(3);
hp[9] = makeFUN(&&F_mapNormRhs);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
hp[12] = makeHDR(3);
hp[13] = makeFUN(&&F_nubBySans);
hp[14] = makeCTR(C_Nil);
hp[15] = makePTR(hp+8);
hp[16] = makeHDR(3);
hp[17] = makeCTR(C_Pair);
hp[18] = getPTR(L_sp[-1])[2];
hp[19] = makePTR(hp+12);
atom = makePTR(hp+16);
hp += 20;
L_POP(2);
L_PUSH(atom);
res = C_Pair;
goto EVAL_RET;
}
F_normRhs:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2298;
  goto GC_COLLECT;
}
  GC_RET_2298:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2299;
goto EVAL;
LABEL_2299:
switch (res) {
case C_Pair:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_normRhs___0);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[3];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Pair);
hp[6] = getPTR(L_sp[-1])[2];
hp[7] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 8;
L_POP(2);
L_PUSH(atom);
res = C_Pair;
goto EVAL_RET;
}
F_normRhs___0:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2301;
  goto GC_COLLECT;
}
  GC_RET_2301:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_normalForms);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-1])[3];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_2302;
goto EVAL;
LABEL_2302:
switch (res) {
case C_Cons:
atom = getPTR(L_sp[-1])[2];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
}
F_mapNormEqn:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2303;
  goto GC_COLLECT;
}
  GC_RET_2303:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2304;
goto EVAL;
LABEL_2304:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_normEqn);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_mapNormEqn);
hp[6] = getPTR(L_sp[-2])[2];
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
F_equalTermsU:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2307;
  goto GC_COLLECT;
}
  GC_RET_2307:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2308;
goto EVAL;
LABEL_2308:
switch (res) {
case C_Pair:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_equalTerms);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-1])[3];
atom = makePTR(hp+0);
hp += 4;
L_POP(2);
L_PUSH(atom);
goto F_equalTerms;
}
F_filterNonUncurryET:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2309;
  goto GC_COLLECT;
}
  GC_RET_2309:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2310;
goto EVAL;
LABEL_2310:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_2311;
goto EVAL;
LABEL_2311:
switch (res) {
case C_Pair:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_equalTerms);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-1])[3];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_2312;
goto EVAL;
LABEL_2312:
switch (res) {
case C_False:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_filterNonUncurryET);
hp[2] = getPTR(L_sp[-3])[3];
hp[3] = makeHDR(3);
hp[4] = makeCTR(C_Cons);
hp[5] = getPTR(L_sp[-3])[2];
hp[6] = makePTR(hp+0);
atom = makePTR(hp+3);
hp += 7;
L_POP(4);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
case C_True:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_filterNonUncurryET);
hp[2] = getPTR(L_sp[-3])[3];
atom = makePTR(hp+0);
hp += 3;
L_POP(4);
L_PUSH(atom);
goto F_filterNonUncurryET;
}
}
}
F_simplifyEquations:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2314;
  goto GC_COLLECT;
}
  GC_RET_2314:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_mapNormEqn);
hp[2] = getPTR(L_sp[-1])[3];
hp[3] = getPTR(L_sp[-1])[4];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_nubBySans);
hp[6] = makeCTR(C_Nil);
hp[7] = makePTR(hp+0);
hp[8] = makeHDR(2);
hp[9] = makeFUN(&&F_filterNonUncurryET);
hp[10] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 11;
L_POP(1);
L_PUSH(atom);
goto F_filterNonUncurryET;
F_normEqn:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2317;
  goto GC_COLLECT;
}
  GC_RET_2317:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2318;
goto EVAL;
LABEL_2318:
switch (res) {
case C_Pair:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_normEqn___0);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_normEqn___1);
hp[6] = getPTR(L_sp[-2])[2];
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Pair);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(2);
L_PUSH(atom);
res = C_Pair;
goto EVAL_RET;
}
F_normEqn___0:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2321;
  goto GC_COLLECT;
}
  GC_RET_2321:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_normalForms);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-1])[3];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_2322;
goto EVAL;
LABEL_2322:
switch (res) {
case C_Cons:
atom = getPTR(L_sp[-1])[2];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
}
F_normEqn___1:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2323;
  goto GC_COLLECT;
}
  GC_RET_2323:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_normalForms);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-1])[3];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_2324;
goto EVAL;
LABEL_2324:
switch (res) {
case C_Cons:
atom = getPTR(L_sp[-1])[2];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
}
F_reduceSplit:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2325;
  goto GC_COLLECT;
}
  GC_RET_2325:
atom = getPTR(L_sp[-1])[4];
getPTR(L_sp[-1])[4] = makeINT(0);
eval_ret_addr = &&LABEL_2326;
goto EVAL;
LABEL_2326:
switch (res) {
case C_Nil:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Pair);
hp[2] = makeCTR(C_Nil);
hp[3] = makeCTR(C_Nil);
atom = makePTR(hp+0);
hp += 4;
L_POP(2);
L_PUSH(atom);
res = C_Pair;
goto EVAL_RET;
case C_Cons:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_2327;
goto EVAL;
LABEL_2327:
switch (res) {
case C_Pair:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = getPTR(L_sp[-3])[3];
hp[3] = makeCTR(C_Nil);
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_reduce);
hp[6] = makePTR(hp+0);
hp[7] = getPTR(L_sp[-1])[2];
hp[8] = makeHDR(7);
hp[9] = makeFUN(&&F_reduceSplit___0);
hp[10] = getPTR(L_sp[-3])[2];
hp[11] = getPTR(L_sp[-3])[3];
hp[12] = getPTR(L_sp[-2])[3];
hp[13] = makePTR(hp+4);
hp[14] = getPTR(L_sp[-1])[2];
hp[15] = getPTR(L_sp[-1])[3];
atom = makePTR(hp+8);
hp += 16;
L_POP(3);
L_PUSH(atom);
goto F_reduceSplit___0;
}
}
F_reduceSplit___1:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2329;
  goto GC_COLLECT;
}
  GC_RET_2329:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2330;
goto EVAL;
LABEL_2330:
switch (res) {
case C_Pair:
atom = getPTR(L_sp[-1])[2];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
}
F_reduceSplit___2:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2331;
  goto GC_COLLECT;
}
  GC_RET_2331:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2332;
goto EVAL;
LABEL_2332:
switch (res) {
case C_Cons:
atom = getPTR(L_sp[-1])[2];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
}
F_reduceSplit___0:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2333;
  goto GC_COLLECT;
}
  GC_RET_2333:
hp[0] = makeHDR(4);
hp[1] = makeFUN(&&F_reduceSplit);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-1])[3];
hp[4] = getPTR(L_sp[-1])[4];
atom = makePTR(hp+0);
hp += 5;
eval_ret_addr = &&LABEL_2334;
goto EVAL;
LABEL_2334:
switch (res) {
case C_Pair:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_null);
hp[2] = getPTR(L_sp[-2])[5];
hp[3] = makeHDR(3);
hp[4] = makeCTR(C_Pair);
hp[5] = getPTR(L_sp[-2])[6];
hp[6] = getPTR(L_sp[-2])[7];
hp[7] = makeHDR(3);
hp[8] = makeCTR(C_Cons);
hp[9] = makePTR(hp+3);
hp[10] = makeCTR(C_Nil);
hp[11] = makeHDR(2);
hp[12] = makeFUN(&&F_reduceSplit___1);
hp[13] = getPTR(L_sp[-2])[3];
hp[14] = makeHDR(3);
hp[15] = makeFUN(&&F_reducible);
hp[16] = makePTR(hp+7);
hp[17] = makePTR(hp+11);
hp[18] = makeHDR(3);
hp[19] = makeFUN(&&F_dis);
hp[20] = makePTR(hp+0);
hp[21] = makePTR(hp+14);
atom = makePTR(hp+18);
hp += 22;
eval_ret_addr = &&LABEL_2340;
goto EVAL;
LABEL_2340:
switch (res) {
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Pair);
hp[2] = getPTR(L_sp[-3])[6];
hp[3] = getPTR(L_sp[-3])[7];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = makePTR(hp+0);
hp[7] = getPTR(L_sp[-2])[3];
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Pair);
hp[10] = getPTR(L_sp[-2])[2];
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(3);
L_PUSH(atom);
res = C_Pair;
goto EVAL_RET;
case C_False:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_reduceSplit___2);
hp[2] = getPTR(L_sp[-3])[5];
hp[3] = makeHDR(3);
hp[4] = makeCTR(C_Pair);
hp[5] = makePTR(hp+0);
hp[6] = getPTR(L_sp[-3])[7];
hp[7] = makeHDR(3);
hp[8] = makeCTR(C_Cons);
hp[9] = makePTR(hp+3);
hp[10] = getPTR(L_sp[-2])[2];
hp[11] = makeHDR(3);
hp[12] = makeCTR(C_Pair);
hp[13] = makePTR(hp+7);
hp[14] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+11);
hp += 15;
L_POP(3);
L_PUSH(atom);
res = C_Pair;
goto EVAL_RET;
}
}
F_selfCriticalPairs:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2346;
  goto GC_COLLECT;
}
  GC_RET_2346:
atom = getPTR(L_sp[-1])[4];
getPTR(L_sp[-1])[4] = makeINT(0);
eval_ret_addr = &&LABEL_2347;
goto EVAL;
LABEL_2347:
switch (res) {
case C_Pair:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Pair);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-1])[3];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Pair);
hp[6] = getPTR(L_sp[-1])[2];
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(3);
hp[9] = makeFUN(&&F_rename);
hp[10] = getPTR(L_sp[-2])[2];
hp[11] = makePTR(hp+4);
hp[12] = makeHDR(5);
hp[13] = makeFUN(&&F_criticalPairs);
hp[14] = getPTR(L_sp[-2])[3];
hp[15] = makeCTR(C_False);
hp[16] = makePTR(hp+0);
hp[17] = makePTR(hp+8);
atom = makePTR(hp+12);
hp += 18;
L_POP(2);
L_PUSH(atom);
goto F_criticalPairs;
}
F_duoCriticalPairs:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2351;
  goto GC_COLLECT;
}
  GC_RET_2351:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2352;
goto EVAL;
LABEL_2352:
switch (res) {
case C_Pair:
atom = getPTR(L_sp[-2])[4];
getPTR(L_sp[-2])[4] = makeINT(0);
eval_ret_addr = &&LABEL_2353;
goto EVAL;
LABEL_2353:
switch (res) {
case C_Pair:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Pair);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Pair);
hp[6] = getPTR(L_sp[-1])[2];
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(5);
hp[9] = makeFUN(&&F_criticalPairs);
hp[10] = getPTR(L_sp[-3])[2];
hp[11] = makeCTR(C_True);
hp[12] = makePTR(hp+0);
hp[13] = makePTR(hp+4);
hp[14] = makeHDR(3);
hp[15] = makeCTR(C_Pair);
hp[16] = getPTR(L_sp[-1])[2];
hp[17] = getPTR(L_sp[-1])[3];
hp[18] = makeHDR(3);
hp[19] = makeCTR(C_Pair);
hp[20] = getPTR(L_sp[-2])[2];
hp[21] = getPTR(L_sp[-2])[3];
hp[22] = makeHDR(5);
hp[23] = makeFUN(&&F_criticalPairs);
hp[24] = getPTR(L_sp[-3])[2];
hp[25] = makeCTR(C_False);
hp[26] = makePTR(hp+14);
hp[27] = makePTR(hp+18);
hp[28] = makeHDR(3);
hp[29] = makeFUN(&&F_append);
hp[30] = makePTR(hp+8);
hp[31] = makePTR(hp+22);
atom = makePTR(hp+28);
hp += 32;
L_POP(3);
L_PUSH(atom);
goto F_append;
}
}
F_concatMapCPA:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2360;
  goto GC_COLLECT;
}
  GC_RET_2360:
atom = getPTR(L_sp[-1])[5];
getPTR(L_sp[-1])[5] = makeINT(0);
eval_ret_addr = &&LABEL_2361;
goto EVAL;
LABEL_2361:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(5);
hp[1] = makeFUN(&&F_criticalPairsAt);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = getPTR(L_sp[-2])[4];
hp[5] = getPTR(L_sp[-1])[2];
hp[6] = makeHDR(5);
hp[7] = makeFUN(&&F_concatMapCPA);
hp[8] = getPTR(L_sp[-2])[2];
hp[9] = getPTR(L_sp[-2])[3];
hp[10] = getPTR(L_sp[-2])[4];
hp[11] = getPTR(L_sp[-1])[3];
hp[12] = makeHDR(3);
hp[13] = makeFUN(&&F_append);
hp[14] = makePTR(hp+0);
hp[15] = makePTR(hp+6);
atom = makePTR(hp+12);
hp += 16;
L_POP(2);
L_PUSH(atom);
goto F_append;
}
F_filterNonNull:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2364;
  goto GC_COLLECT;
}
  GC_RET_2364:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2365;
goto EVAL;
LABEL_2365:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_null);
hp[2] = getPTR(L_sp[-1])[3];
atom = makePTR(hp+0);
hp += 3;
eval_ret_addr = &&LABEL_2366;
goto EVAL;
LABEL_2366:
switch (res) {
case C_True:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_filterNonNull);
hp[2] = getPTR(L_sp[-2])[3];
hp[3] = makeHDR(3);
hp[4] = makeCTR(C_Cons);
hp[5] = getPTR(L_sp[-2])[2];
hp[6] = makePTR(hp+0);
atom = makePTR(hp+3);
hp += 7;
L_POP(3);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
case C_False:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_filterNonNull);
hp[2] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+0);
hp += 3;
L_POP(3);
L_PUSH(atom);
goto F_filterNonNull;
}
}
F_rootPos:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2368;
  goto GC_COLLECT;
}
  GC_RET_2368:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2369;
goto EVAL;
LABEL_2369:
switch (res) {
case C_True:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_positions);
hp[2] = getPTR(L_sp[-2])[2];
atom = makePTR(hp+0);
hp += 3;
L_POP(2);
L_PUSH(atom);
goto F_positions;
case C_False:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_positions);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = makeHDR(2);
hp[4] = makeFUN(&&F_filterNonNull);
hp[5] = makePTR(hp+0);
atom = makePTR(hp+3);
hp += 6;
L_POP(2);
L_PUSH(atom);
goto F_filterNonNull;
}
F_criticalPairs:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2371;
  goto GC_COLLECT;
}
  GC_RET_2371:
atom = getPTR(L_sp[-1])[4];
getPTR(L_sp[-1])[4] = makeINT(0);
eval_ret_addr = &&LABEL_2372;
goto EVAL;
LABEL_2372:
switch (res) {
case C_Pair:
atom = getPTR(L_sp[-2])[5];
getPTR(L_sp[-2])[5] = makeINT(0);
eval_ret_addr = &&LABEL_2373;
goto EVAL;
LABEL_2373:
switch (res) {
case C_Pair:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Pair);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Pair);
hp[6] = getPTR(L_sp[-1])[2];
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(3);
hp[9] = makeFUN(&&F_rootPos);
hp[10] = getPTR(L_sp[-2])[2];
hp[11] = getPTR(L_sp[-3])[3];
hp[12] = makeHDR(5);
hp[13] = makeFUN(&&F_concatMapCPA);
hp[14] = getPTR(L_sp[-3])[2];
hp[15] = makePTR(hp+0);
hp[16] = makePTR(hp+4);
hp[17] = makePTR(hp+8);
atom = makePTR(hp+12);
hp += 18;
L_POP(3);
L_PUSH(atom);
goto F_concatMapCPA;
}
}
F_criticalPairsAt:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2377;
  goto GC_COLLECT;
}
  GC_RET_2377:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2378;
goto EVAL;
LABEL_2378:
switch (res) {
case C_Pair:
atom = getPTR(L_sp[-2])[4];
getPTR(L_sp[-2])[4] = makeINT(0);
eval_ret_addr = &&LABEL_2379;
goto EVAL;
LABEL_2379:
switch (res) {
case C_Pair:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_subterm);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-3])[5];
hp[4] = makeHDR(8);
hp[5] = makeFUN(&&F_criticalPairsAt___0);
hp[6] = makePTR(hp+0);
hp[7] = getPTR(L_sp[-1])[2];
hp[8] = getPTR(L_sp[-3])[2];
hp[9] = getPTR(L_sp[-2])[3];
hp[10] = getPTR(L_sp[-1])[3];
hp[11] = getPTR(L_sp[-3])[5];
hp[12] = getPTR(L_sp[-2])[2];
atom = makePTR(hp+4);
hp += 13;
L_POP(3);
L_PUSH(atom);
goto F_criticalPairsAt___0;
}
}
F_criticalPairsAt___1:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2380;
  goto GC_COLLECT;
}
  GC_RET_2380:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_subst);
hp[2] = getPTR(L_sp[-1])[3];
hp[3] = getPTR(L_sp[-1])[4];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_normalForms);
hp[6] = getPTR(L_sp[-1])[2];
hp[7] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 8;
eval_ret_addr = &&LABEL_2382;
goto EVAL;
LABEL_2382:
switch (res) {
case C_Cons:
atom = getPTR(L_sp[-1])[2];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
}
F_criticalPairsAt___2:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2383;
  goto GC_COLLECT;
}
  GC_RET_2383:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_subst);
hp[2] = getPTR(L_sp[-1])[3];
hp[3] = getPTR(L_sp[-1])[4];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_subst);
hp[6] = getPTR(L_sp[-1])[3];
hp[7] = getPTR(L_sp[-1])[6];
hp[8] = makeHDR(4);
hp[9] = makeFUN(&&F_placeAt);
hp[10] = makePTR(hp+0);
hp[11] = getPTR(L_sp[-1])[5];
hp[12] = makePTR(hp+4);
hp[13] = makeHDR(3);
hp[14] = makeFUN(&&F_normalForms);
hp[15] = getPTR(L_sp[-1])[2];
hp[16] = makePTR(hp+8);
atom = makePTR(hp+13);
hp += 17;
eval_ret_addr = &&LABEL_2387;
goto EVAL;
LABEL_2387:
switch (res) {
case C_Cons:
atom = getPTR(L_sp[-1])[2];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
}
F_criticalPairsAt___0:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2388;
  goto GC_COLLECT;
}
  GC_RET_2388:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_isVar);
hp[2] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+0);
hp += 3;
eval_ret_addr = &&LABEL_2389;
goto EVAL;
LABEL_2389:
switch (res) {
case C_True:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_False:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_unify);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_2390;
goto EVAL;
LABEL_2390:
switch (res) {
case C_Nothing:
L_POP(3);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Just:
hp[0] = makeHDR(4);
hp[1] = makeFUN(&&F_criticalPairsAt___1);
hp[2] = getPTR(L_sp[-3])[4];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = getPTR(L_sp[-3])[5];
hp[5] = makeHDR(6);
hp[6] = makeFUN(&&F_criticalPairsAt___2);
hp[7] = getPTR(L_sp[-3])[4];
hp[8] = getPTR(L_sp[-1])[2];
hp[9] = getPTR(L_sp[-3])[6];
hp[10] = getPTR(L_sp[-3])[7];
hp[11] = getPTR(L_sp[-3])[8];
hp[12] = makeHDR(3);
hp[13] = makeFUN(&&F_criticalPairsFrom);
hp[14] = makePTR(hp+0);
hp[15] = makePTR(hp+5);
atom = makePTR(hp+12);
hp += 16;
L_POP(3);
L_PUSH(atom);
goto F_criticalPairsFrom;
}
}
F_criticalPairsFrom:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2393;
  goto GC_COLLECT;
}
  GC_RET_2393:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_equalTerms);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-1])[3];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_2394;
goto EVAL;
LABEL_2394:
switch (res) {
case C_True:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_False:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Pair);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = makePTR(hp+0);
hp[7] = makeCTR(C_Nil);
atom = makePTR(hp+4);
hp += 8;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
F_filterNonFlipElem:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2396;
  goto GC_COLLECT;
}
  GC_RET_2396:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2397;
goto EVAL;
LABEL_2397:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_elemByES);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-2])[2];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_2398;
goto EVAL;
LABEL_2398:
switch (res) {
case C_False:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_filterNonFlipElem);
hp[2] = getPTR(L_sp[-3])[2];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = getPTR(L_sp[-2])[2];
hp[7] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 8;
L_POP(3);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_filterNonFlipElem);
hp[2] = getPTR(L_sp[-3])[2];
hp[3] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+0);
hp += 4;
L_POP(3);
L_PUSH(atom);
goto F_filterNonFlipElem;
}
}
F_mapSnd:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2400;
  goto GC_COLLECT;
}
  GC_RET_2400:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2401;
goto EVAL;
LABEL_2401:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_mapSnd___0);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = makeHDR(2);
hp[4] = makeFUN(&&F_mapSnd);
hp[5] = getPTR(L_sp[-1])[3];
hp[6] = makeHDR(3);
hp[7] = makeCTR(C_Cons);
hp[8] = makePTR(hp+0);
hp[9] = makePTR(hp+3);
atom = makePTR(hp+6);
hp += 10;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
F_mapSnd___0:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2404;
  goto GC_COLLECT;
}
  GC_RET_2404:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2405;
goto EVAL;
LABEL_2405:
switch (res) {
case C_Pair:
atom = getPTR(L_sp[-1])[3];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
}
F_rename:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2406;
  goto GC_COLLECT;
}
  GC_RET_2406:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2407;
goto EVAL;
LABEL_2407:
switch (res) {
case C_Pair:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_vars);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = makeHDR(3);
hp[4] = makeFUN(&&F_filterNonFlipElem);
hp[5] = makePTR(hp+0);
hp[6] = getPTR(L_sp[-2])[2];
hp[7] = makeHDR(2);
hp[8] = makeFUN(&&F_mapVar);
hp[9] = makePTR(hp+3);
hp[10] = makeHDR(3);
hp[11] = makeFUN(&&F_zip);
hp[12] = makePTR(hp+0);
hp[13] = makePTR(hp+7);
hp[14] = makeHDR(3);
hp[15] = makeFUN(&&F_subst);
hp[16] = makePTR(hp+10);
hp[17] = getPTR(L_sp[-1])[2];
hp[18] = makeHDR(3);
hp[19] = makeFUN(&&F_subst);
hp[20] = makePTR(hp+10);
hp[21] = getPTR(L_sp[-1])[3];
hp[22] = makeHDR(3);
hp[23] = makeCTR(C_Pair);
hp[24] = makePTR(hp+14);
hp[25] = makePTR(hp+18);
atom = makePTR(hp+22);
hp += 26;
L_POP(2);
L_PUSH(atom);
res = C_Pair;
goto EVAL_RET;
}
F_kbGreaterThan:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2412;
  goto GC_COLLECT;
}
  GC_RET_2412:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_vars);
hp[2] = getPTR(L_sp[-1])[3];
hp[3] = makeHDR(2);
hp[4] = makeFUN(&&F_vars);
hp[5] = getPTR(L_sp[-1])[4];
hp[6] = makeHDR(3);
hp[7] = makeFUN(&&F_unionBy);
hp[8] = makePTR(hp+0);
hp[9] = makePTR(hp+3);
hp[10] = makeHDR(3);
hp[11] = makeFUN(&&F_termWeight);
hp[12] = getPTR(L_sp[-1])[2];
hp[13] = getPTR(L_sp[-1])[3];
hp[14] = makeHDR(3);
hp[15] = makeFUN(&&F_termWeight);
hp[16] = getPTR(L_sp[-1])[2];
hp[17] = getPTR(L_sp[-1])[4];
hp[18] = makeHDR(3);
hp[19] = makeFUN(&&F_varCounts);
hp[20] = getPTR(L_sp[-1])[3];
hp[21] = makePTR(hp+6);
hp[22] = makeHDR(2);
hp[23] = makeFUN(&&F_mapSnd);
hp[24] = makePTR(hp+18);
hp[25] = makeHDR(3);
hp[26] = makeFUN(&&F_varCounts);
hp[27] = getPTR(L_sp[-1])[4];
hp[28] = makePTR(hp+6);
hp[29] = makeHDR(2);
hp[30] = makeFUN(&&F_mapSnd);
hp[31] = makePTR(hp+25);
hp[32] = makeHDR(3);
hp[33] = makeFUN(&&P_LEQ);
hp[34] = makePTR(hp+10);
hp[35] = makePTR(hp+14);
hp[36] = makeHDR(2);
hp[37] = makeFUN(&&F_not);
hp[38] = makePTR(hp+32);
hp[39] = makeHDR(3);
hp[40] = makeFUN(&&F_zipWithL);
hp[41] = makePTR(hp+29);
hp[42] = makePTR(hp+22);
hp[43] = makeHDR(2);
hp[44] = makeFUN(&&F_and);
hp[45] = makePTR(hp+39);
hp[46] = makeHDR(3);
hp[47] = makeFUN(&&F_con);
hp[48] = makePTR(hp+36);
hp[49] = makePTR(hp+43);
hp[50] = makeHDR(3);
hp[51] = makeFUN(&&P_EQ);
hp[52] = makePTR(hp+10);
hp[53] = makePTR(hp+14);
hp[54] = makeHDR(3);
hp[55] = makeFUN(&&F_zipWithEq);
hp[56] = makePTR(hp+22);
hp[57] = makePTR(hp+29);
hp[58] = makeHDR(2);
hp[59] = makeFUN(&&F_and);
hp[60] = makePTR(hp+54);
hp[61] = makeHDR(3);
hp[62] = makeFUN(&&F_con);
hp[63] = makePTR(hp+50);
hp[64] = makePTR(hp+58);
hp[65] = makeHDR(2);
hp[66] = makeFUN(&&F_kbGreaterThan___0);
hp[67] = getPTR(L_sp[-1])[2];
hp[68] = makeHDR(2);
hp[69] = makeFUN(&&F_last);
hp[70] = makePTR(hp+65);
hp[71] = makeHDR(4);
hp[72] = makeFUN(&&F_powerOf);
hp[73] = makePTR(hp+68);
hp[74] = getPTR(L_sp[-1])[3];
hp[75] = getPTR(L_sp[-1])[4];
hp[76] = makeHDR(4);
hp[77] = makeFUN(&&F_funcAfter);
hp[78] = getPTR(L_sp[-1])[2];
hp[79] = getPTR(L_sp[-1])[3];
hp[80] = getPTR(L_sp[-1])[4];
hp[81] = makeHDR(3);
hp[82] = makeFUN(&&F_dis);
hp[83] = makePTR(hp+71);
hp[84] = makePTR(hp+76);
hp[85] = makeHDR(3);
hp[86] = makeFUN(&&F_con);
hp[87] = makePTR(hp+61);
hp[88] = makePTR(hp+81);
hp[89] = makeHDR(3);
hp[90] = makeFUN(&&F_dis);
hp[91] = makePTR(hp+46);
hp[92] = makePTR(hp+85);
atom = makePTR(hp+89);
hp += 93;
L_POP(1);
L_PUSH(atom);
goto F_dis;
F_kbGreaterThan___0:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2432;
  goto GC_COLLECT;
}
  GC_RET_2432:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2433;
goto EVAL;
LABEL_2433:
switch (res) {
case C_Weights:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_mapFst);
hp[2] = getPTR(L_sp[-1])[3];
atom = makePTR(hp+0);
hp += 3;
L_POP(2);
L_PUSH(atom);
goto F_mapFst;
}
F_mapTW:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2434;
  goto GC_COLLECT;
}
  GC_RET_2434:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2435;
goto EVAL;
LABEL_2435:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_termWeight);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_mapTW);
hp[6] = getPTR(L_sp[-2])[2];
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
F_termWeight:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2438;
  goto GC_COLLECT;
}
  GC_RET_2438:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2439;
goto EVAL;
LABEL_2439:
switch (res) {
case C_Var:
atom = getPTR(L_sp[-2])[2];
getPTR(L_sp[-2])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2440;
goto EVAL;
LABEL_2440:
switch (res) {
case C_Weights:
atom = getPTR(L_sp[-1])[2];
L_POP(3);
goto TAIL_EVAL;
goto EVAL_RET;
}
case C_Fun:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_funWeight);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_2441;
goto EVAL;
LABEL_2441:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_mapTW);
hp[2] = getPTR(L_sp[-3])[2];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = makeHDR(2);
hp[5] = makeFUN(&&F_sum);
hp[6] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 7;
eval_ret_addr = &&LABEL_2443;
goto EVAL;
LABEL_2443:
L_POP(1);
res = getINT(L_top) + res;
L_POP(3);
L_PUSH(makeINT(res));
goto EVAL_RET;
}
F_powerOf:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2444;
  goto GC_COLLECT;
}
  GC_RET_2444:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2445;
goto EVAL;
LABEL_2445:
switch (res) {
case C_Var:
L_POP(2);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
case C_Fun:
atom = getPTR(L_sp[-1])[3];
eval_ret_addr = &&LABEL_2446;
goto EVAL;
LABEL_2446:
switch (res) {
case C_Nil:
L_POP(3);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_isVar);
hp[2] = getPTR(L_sp[-3])[4];
hp[3] = makeHDR(3);
hp[4] = makeFUN(&&F_equalStrings);
hp[5] = getPTR(L_sp[-2])[2];
hp[6] = getPTR(L_sp[-3])[2];
hp[7] = makeHDR(3);
hp[8] = makeFUN(&&F_con);
hp[9] = makePTR(hp+0);
hp[10] = makePTR(hp+3);
hp[11] = makeHDR(2);
hp[12] = makeFUN(&&F_null);
hp[13] = getPTR(L_sp[-1])[3];
hp[14] = makeHDR(3);
hp[15] = makeFUN(&&F_pow);
hp[16] = getPTR(L_sp[-3])[2];
hp[17] = getPTR(L_sp[-1])[2];
hp[18] = makeHDR(3);
hp[19] = makeFUN(&&F_con);
hp[20] = makePTR(hp+11);
hp[21] = makePTR(hp+14);
hp[22] = makeHDR(3);
hp[23] = makeFUN(&&F_con);
hp[24] = makePTR(hp+7);
hp[25] = makePTR(hp+18);
atom = makePTR(hp+22);
hp += 26;
L_POP(3);
L_PUSH(atom);
goto F_con;
}
}
F_pow:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2453;
  goto GC_COLLECT;
}
  GC_RET_2453:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2454;
goto EVAL;
LABEL_2454:
switch (res) {
case C_Var:
L_POP(2);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
case C_Fun:
atom = getPTR(L_sp[-1])[3];
eval_ret_addr = &&LABEL_2455;
goto EVAL;
LABEL_2455:
switch (res) {
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_equalStrings);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-3])[2];
hp[4] = makeHDR(2);
hp[5] = makeFUN(&&F_null);
hp[6] = getPTR(L_sp[-1])[3];
hp[7] = makeHDR(3);
hp[8] = makeFUN(&&F_pow);
hp[9] = getPTR(L_sp[-3])[2];
hp[10] = getPTR(L_sp[-1])[2];
hp[11] = makeHDR(3);
hp[12] = makeFUN(&&F_con);
hp[13] = makePTR(hp+4);
hp[14] = makePTR(hp+7);
hp[15] = makeHDR(3);
hp[16] = makeFUN(&&F_con);
hp[17] = makePTR(hp+0);
hp[18] = makePTR(hp+11);
atom = makePTR(hp+15);
hp += 19;
L_POP(3);
L_PUSH(atom);
goto F_con;
}
}
F_funcAfter:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2460;
  goto GC_COLLECT;
}
  GC_RET_2460:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2461;
goto EVAL;
LABEL_2461:
switch (res) {
case C_Var:
atom = getPTR(L_sp[-2])[4];
getPTR(L_sp[-2])[4] = makeINT(0);
eval_ret_addr = &&LABEL_2462;
goto EVAL;
LABEL_2462:
switch (res) {
case C_Var:
L_POP(3);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
case C_Fun:
L_POP(3);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
}
case C_Fun:
atom = getPTR(L_sp[-2])[4];
getPTR(L_sp[-2])[4] = makeINT(0);
eval_ret_addr = &&LABEL_2463;
goto EVAL;
LABEL_2463:
switch (res) {
case C_Var:
L_POP(3);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
case C_Fun:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_equalStrings);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_2464;
goto EVAL;
LABEL_2464:
switch (res) {
case C_True:
hp[0] = makeHDR(4);
hp[1] = makeFUN(&&F_orderLex);
hp[2] = getPTR(L_sp[-4])[2];
hp[3] = getPTR(L_sp[-3])[3];
hp[4] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+0);
hp += 5;
L_POP(4);
L_PUSH(atom);
goto F_orderLex;
case C_False:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_funcAfter___0);
hp[2] = getPTR(L_sp[-4])[2];
hp[3] = makeHDR(4);
hp[4] = makeFUN(&&F_before);
hp[5] = makePTR(hp+0);
hp[6] = getPTR(L_sp[-2])[2];
hp[7] = getPTR(L_sp[-3])[2];
atom = makePTR(hp+3);
hp += 8;
L_POP(4);
L_PUSH(atom);
goto F_before;
}
}
}
F_funcAfter___0:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2466;
  goto GC_COLLECT;
}
  GC_RET_2466:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2467;
goto EVAL;
LABEL_2467:
switch (res) {
case C_Weights:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_mapFst);
hp[2] = getPTR(L_sp[-1])[3];
atom = makePTR(hp+0);
hp += 3;
L_POP(2);
L_PUSH(atom);
goto F_mapFst;
}
F_zipWithEq:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2468;
  goto GC_COLLECT;
}
  GC_RET_2468:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2469;
goto EVAL;
LABEL_2469:
switch (res) {
case C_Nil:
atom = getPTR(L_sp[-2])[3];
getPTR(L_sp[-2])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2470;
goto EVAL;
LABEL_2470:
switch (res) {
case C_Nil:
L_POP(3);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
L_POP(3);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
}
case C_Cons:
atom = getPTR(L_sp[-2])[3];
getPTR(L_sp[-2])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2471;
goto EVAL;
LABEL_2471:
switch (res) {
case C_Nil:
L_POP(3);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&P_EQ);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_zipWithEq);
hp[6] = getPTR(L_sp[-2])[3];
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(3);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
}
F_zipWithL:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2474;
  goto GC_COLLECT;
}
  GC_RET_2474:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2475;
goto EVAL;
LABEL_2475:
switch (res) {
case C_Nil:
atom = getPTR(L_sp[-2])[3];
getPTR(L_sp[-2])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2476;
goto EVAL;
LABEL_2476:
switch (res) {
case C_Nil:
L_POP(3);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
L_POP(3);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
}
case C_Cons:
atom = getPTR(L_sp[-2])[3];
getPTR(L_sp[-2])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2477;
goto EVAL;
LABEL_2477:
switch (res) {
case C_Nil:
L_POP(3);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&P_LEQ);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_zipWithL);
hp[6] = getPTR(L_sp[-2])[3];
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(3);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
}
F_compareAllEq:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2480;
  goto GC_COLLECT;
}
  GC_RET_2480:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_zipWithEq);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-1])[3];
hp[4] = makeHDR(2);
hp[5] = makeFUN(&&F_and);
hp[6] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 7;
L_POP(1);
L_PUSH(atom);
goto F_and;
F_compareAllL:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2482;
  goto GC_COLLECT;
}
  GC_RET_2482:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_zipWithL);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-1])[3];
hp[4] = makeHDR(2);
hp[5] = makeFUN(&&F_and);
hp[6] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 7;
L_POP(1);
L_PUSH(atom);
goto F_and;
F_concatMapVA:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2484;
  goto GC_COLLECT;
}
  GC_RET_2484:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2485;
goto EVAL;
LABEL_2485:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_varAt);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_concatMapVA);
hp[6] = getPTR(L_sp[-2])[2];
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(3);
hp[9] = makeFUN(&&F_append);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(2);
L_PUSH(atom);
goto F_append;
}
F_foldrTally:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2488;
  goto GC_COLLECT;
}
  GC_RET_2488:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2489;
goto EVAL;
LABEL_2489:
switch (res) {
case C_Nil:
atom = getPTR(L_sp[-2])[2];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_foldrTally);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[3];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_tally);
hp[6] = getPTR(L_sp[-1])[2];
hp[7] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 8;
L_POP(2);
L_PUSH(atom);
goto F_tally;
}
F_varCounts:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2491;
  goto GC_COLLECT;
}
  GC_RET_2491:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_repeat);
hp[2] = makeINT(0);
hp[3] = makeHDR(3);
hp[4] = makeFUN(&&F_zip);
hp[5] = getPTR(L_sp[-1])[3];
hp[6] = makePTR(hp+0);
hp[7] = makeHDR(2);
hp[8] = makeFUN(&&F_positions);
hp[9] = getPTR(L_sp[-1])[2];
hp[10] = makeHDR(3);
hp[11] = makeFUN(&&F_concatMapVA);
hp[12] = getPTR(L_sp[-1])[2];
hp[13] = makePTR(hp+7);
hp[14] = makeHDR(3);
hp[15] = makeFUN(&&F_foldrTally);
hp[16] = makePTR(hp+3);
hp[17] = makePTR(hp+10);
atom = makePTR(hp+14);
hp += 18;
L_POP(1);
L_PUSH(atom);
goto F_foldrTally;
F_varAt:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2496;
  goto GC_COLLECT;
}
  GC_RET_2496:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_subterm);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-1])[3];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_2497;
goto EVAL;
LABEL_2497:
switch (res) {
case C_Var:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = makeCTR(C_Nil);
atom = makePTR(hp+0);
hp += 4;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
case C_Fun:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
}
F_tally:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2498;
  goto GC_COLLECT;
}
  GC_RET_2498:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2499;
goto EVAL;
LABEL_2499:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_2500;
goto EVAL;
LABEL_2500:
switch (res) {
case C_Pair:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_equalStrings);
hp[2] = getPTR(L_sp[-3])[2];
hp[3] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_2501;
goto EVAL;
LABEL_2501:
switch (res) {
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&P_ADD);
hp[2] = getPTR(L_sp[-2])[3];
hp[3] = makeINT(1);
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Pair);
hp[6] = getPTR(L_sp[-2])[2];
hp[7] = makePTR(hp+0);
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makePTR(hp+4);
hp[11] = getPTR(L_sp[-3])[3];
atom = makePTR(hp+8);
hp += 12;
L_POP(4);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
case C_False:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Pair);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_tally);
hp[6] = getPTR(L_sp[-4])[2];
hp[7] = getPTR(L_sp[-3])[3];
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(4);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
}
}
F_orderLex:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2506;
  goto GC_COLLECT;
}
  GC_RET_2506:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2507;
goto EVAL;
LABEL_2507:
switch (res) {
case C_Nil:
atom = getPTR(L_sp[-2])[4];
getPTR(L_sp[-2])[4] = makeINT(0);
eval_ret_addr = &&LABEL_2508;
goto EVAL;
LABEL_2508:
switch (res) {
case C_Nil:
L_POP(3);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
case C_Cons:
L_POP(3);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
}
case C_Cons:
atom = getPTR(L_sp[-2])[4];
getPTR(L_sp[-2])[4] = makeINT(0);
eval_ret_addr = &&LABEL_2509;
goto EVAL;
LABEL_2509:
switch (res) {
case C_Nil:
L_POP(3);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_equalTerms);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_2510;
goto EVAL;
LABEL_2510:
switch (res) {
case C_True:
hp[0] = makeHDR(4);
hp[1] = makeFUN(&&F_orderLex);
hp[2] = getPTR(L_sp[-4])[2];
hp[3] = getPTR(L_sp[-3])[3];
hp[4] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+0);
hp += 5;
L_POP(4);
L_PUSH(atom);
goto F_orderLex;
case C_False:
hp[0] = makeHDR(4);
hp[1] = makeFUN(&&F_kbGreaterThan);
hp[2] = getPTR(L_sp[-4])[2];
hp[3] = getPTR(L_sp[-3])[2];
hp[4] = getPTR(L_sp[-2])[2];
atom = makePTR(hp+0);
hp += 5;
L_POP(4);
L_PUSH(atom);
goto F_kbGreaterThan;
}
}
}
F_before:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2511;
  goto GC_COLLECT;
}
  GC_RET_2511:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2512;
goto EVAL;
LABEL_2512:
switch (res) {
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_equalStrings);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_equalStrings);
hp[6] = getPTR(L_sp[-1])[2];
hp[7] = getPTR(L_sp[-2])[4];
hp[8] = makeHDR(2);
hp[9] = makeFUN(&&F_not);
hp[10] = makePTR(hp+4);
hp[11] = makeHDR(4);
hp[12] = makeFUN(&&F_before);
hp[13] = getPTR(L_sp[-1])[3];
hp[14] = getPTR(L_sp[-2])[3];
hp[15] = getPTR(L_sp[-2])[4];
hp[16] = makeHDR(3);
hp[17] = makeFUN(&&F_con);
hp[18] = makePTR(hp+8);
hp[19] = makePTR(hp+11);
hp[20] = makeHDR(3);
hp[21] = makeFUN(&&F_dis);
hp[22] = makePTR(hp+0);
hp[23] = makePTR(hp+16);
atom = makePTR(hp+20);
hp += 24;
L_POP(2);
L_PUSH(atom);
goto F_dis;
}
F_mapST:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2518;
  goto GC_COLLECT;
}
  GC_RET_2518:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2519;
goto EVAL;
LABEL_2519:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_showTerm);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_mapST);
hp[6] = getPTR(L_sp[-2])[2];
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
F_showTerm:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2522;
  goto GC_COLLECT;
}
  GC_RET_2522:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2523;
goto EVAL;
LABEL_2523:
switch (res) {
case C_Var:
atom = getPTR(L_sp[-1])[2];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
case C_Fun:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_lookUpBy);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-2])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_maybeSnd);
hp[6] = makeCTR(C_False);
hp[7] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 8;
eval_ret_addr = &&LABEL_2525;
goto EVAL;
LABEL_2525:
switch (res) {
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = makeINT(40);
hp[3] = makeCTR(C_Nil);
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_elemAt);
hp[6] = getPTR(L_sp[-2])[3];
hp[7] = makeINT(0);
hp[8] = makeHDR(3);
hp[9] = makeFUN(&&F_showTerm);
hp[10] = getPTR(L_sp[-3])[2];
hp[11] = makePTR(hp+4);
hp[12] = makeHDR(3);
hp[13] = makeCTR(C_Cons);
hp[14] = makeINT(32);
hp[15] = makeCTR(C_Nil);
hp[16] = makeHDR(3);
hp[17] = makeCTR(C_Cons);
hp[18] = makeINT(32);
hp[19] = makeCTR(C_Nil);
hp[20] = makeHDR(3);
hp[21] = makeFUN(&&F_elemAt);
hp[22] = getPTR(L_sp[-2])[3];
hp[23] = makeINT(1);
hp[24] = makeHDR(3);
hp[25] = makeFUN(&&F_showTerm);
hp[26] = getPTR(L_sp[-3])[2];
hp[27] = makePTR(hp+20);
hp[28] = makeHDR(3);
hp[29] = makeCTR(C_Cons);
hp[30] = makeINT(41);
hp[31] = makeCTR(C_Nil);
hp[32] = makeHDR(3);
hp[33] = makeFUN(&&F_append);
hp[34] = makePTR(hp+24);
hp[35] = makePTR(hp+28);
hp[36] = makeHDR(3);
hp[37] = makeFUN(&&F_append);
hp[38] = makePTR(hp+16);
hp[39] = makePTR(hp+32);
hp[40] = makeHDR(3);
hp[41] = makeFUN(&&F_append);
hp[42] = getPTR(L_sp[-2])[2];
hp[43] = makePTR(hp+36);
hp[44] = makeHDR(3);
hp[45] = makeFUN(&&F_append);
hp[46] = makePTR(hp+12);
hp[47] = makePTR(hp+40);
hp[48] = makeHDR(3);
hp[49] = makeFUN(&&F_append);
hp[50] = makePTR(hp+8);
hp[51] = makePTR(hp+44);
hp[52] = makeHDR(3);
hp[53] = makeFUN(&&F_append);
hp[54] = makePTR(hp+0);
hp[55] = makePTR(hp+48);
atom = makePTR(hp+52);
hp += 56;
L_POP(3);
L_PUSH(atom);
goto F_append;
case C_False:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_null);
hp[2] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+0);
hp += 3;
eval_ret_addr = &&LABEL_2539;
goto EVAL;
LABEL_2539:
switch (res) {
case C_True:
atom = getPTR(L_sp[-3])[2];
L_POP(4);
goto TAIL_EVAL;
goto EVAL_RET;
case C_False:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = makeINT(40);
hp[3] = makeCTR(C_Nil);
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = makeINT(44);
hp[7] = makeCTR(C_Nil);
hp[8] = makeHDR(3);
hp[9] = makeFUN(&&F_mapST);
hp[10] = getPTR(L_sp[-4])[2];
hp[11] = getPTR(L_sp[-3])[3];
hp[12] = makeHDR(3);
hp[13] = makeFUN(&&F_intersperse);
hp[14] = makePTR(hp+4);
hp[15] = makePTR(hp+8);
hp[16] = makeHDR(2);
hp[17] = makeFUN(&&F_concatStrings);
hp[18] = makePTR(hp+12);
hp[19] = makeHDR(3);
hp[20] = makeCTR(C_Cons);
hp[21] = makeINT(41);
hp[22] = makeCTR(C_Nil);
hp[23] = makeHDR(3);
hp[24] = makeFUN(&&F_append);
hp[25] = makePTR(hp+16);
hp[26] = makePTR(hp+19);
hp[27] = makeHDR(3);
hp[28] = makeFUN(&&F_append);
hp[29] = makePTR(hp+0);
hp[30] = makePTR(hp+23);
hp[31] = makeHDR(3);
hp[32] = makeFUN(&&F_append);
hp[33] = getPTR(L_sp[-3])[2];
hp[34] = makePTR(hp+27);
atom = makePTR(hp+31);
hp += 35;
L_POP(4);
L_PUSH(atom);
goto F_append;
}
}
}
F_showEqn:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2548;
  goto GC_COLLECT;
}
  GC_RET_2548:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2549;
goto EVAL;
LABEL_2549:
switch (res) {
case C_Pair:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_showTerm);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = makeINT(32);
hp[7] = makeCTR(C_Nil);
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makeINT(61);
hp[11] = makePTR(hp+4);
hp[12] = makeHDR(3);
hp[13] = makeCTR(C_Cons);
hp[14] = makeINT(32);
hp[15] = makePTR(hp+8);
hp[16] = makeHDR(3);
hp[17] = makeFUN(&&F_showTerm);
hp[18] = getPTR(L_sp[-2])[2];
hp[19] = getPTR(L_sp[-1])[3];
hp[20] = makeHDR(3);
hp[21] = makeFUN(&&F_append);
hp[22] = makePTR(hp+12);
hp[23] = makePTR(hp+16);
hp[24] = makeHDR(3);
hp[25] = makeFUN(&&F_append);
hp[26] = makePTR(hp+0);
hp[27] = makePTR(hp+20);
atom = makePTR(hp+24);
hp += 28;
L_POP(2);
L_PUSH(atom);
goto F_append;
}
F_mapSE:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2556;
  goto GC_COLLECT;
}
  GC_RET_2556:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2557;
goto EVAL;
LABEL_2557:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_showEqn);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_mapSE);
hp[6] = getPTR(L_sp[-2])[2];
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
F_showEqns:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2560;
  goto GC_COLLECT;
}
  GC_RET_2560:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_mapSE);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-1])[3];
hp[4] = makeHDR(2);
hp[5] = makeFUN(&&F_unlines);
hp[6] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 7;
L_POP(1);
L_PUSH(atom);
goto F_unlines;
F_showRule:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2562;
  goto GC_COLLECT;
}
  GC_RET_2562:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2563;
goto EVAL;
LABEL_2563:
switch (res) {
case C_Pair:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_showTerm);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = makeINT(32);
hp[7] = makeCTR(C_Nil);
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makeINT(62);
hp[11] = makePTR(hp+4);
hp[12] = makeHDR(3);
hp[13] = makeCTR(C_Cons);
hp[14] = makeINT(45);
hp[15] = makePTR(hp+8);
hp[16] = makeHDR(3);
hp[17] = makeCTR(C_Cons);
hp[18] = makeINT(32);
hp[19] = makePTR(hp+12);
hp[20] = makeHDR(3);
hp[21] = makeFUN(&&F_showTerm);
hp[22] = getPTR(L_sp[-2])[2];
hp[23] = getPTR(L_sp[-1])[3];
hp[24] = makeHDR(3);
hp[25] = makeFUN(&&F_append);
hp[26] = makePTR(hp+16);
hp[27] = makePTR(hp+20);
hp[28] = makeHDR(3);
hp[29] = makeFUN(&&F_append);
hp[30] = makePTR(hp+0);
hp[31] = makePTR(hp+24);
atom = makePTR(hp+28);
hp += 32;
L_POP(2);
L_PUSH(atom);
goto F_append;
}
F_mapSR:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2571;
  goto GC_COLLECT;
}
  GC_RET_2571:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2572;
goto EVAL;
LABEL_2572:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_showRule);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_mapSR);
hp[6] = getPTR(L_sp[-2])[2];
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
F_showRules:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2575;
  goto GC_COLLECT;
}
  GC_RET_2575:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_mapSR);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-1])[3];
hp[4] = makeHDR(2);
hp[5] = makeFUN(&&F_unlines);
hp[6] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 7;
L_POP(1);
L_PUSH(atom);
goto F_unlines;
F_equivPair:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2577;
  goto GC_COLLECT;
}
  GC_RET_2577:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2578;
goto EVAL;
LABEL_2578:
switch (res) {
case C_Pair:
atom = getPTR(L_sp[-2])[3];
getPTR(L_sp[-2])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2579;
goto EVAL;
LABEL_2579:
switch (res) {
case C_Pair:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_equiv);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_equiv);
hp[6] = getPTR(L_sp[-2])[3];
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(3);
hp[9] = makeFUN(&&F_con);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
hp[12] = makeHDR(3);
hp[13] = makeFUN(&&F_equiv);
hp[14] = getPTR(L_sp[-2])[2];
hp[15] = getPTR(L_sp[-1])[3];
hp[16] = makeHDR(3);
hp[17] = makeFUN(&&F_equiv);
hp[18] = getPTR(L_sp[-2])[3];
hp[19] = getPTR(L_sp[-1])[2];
hp[20] = makeHDR(3);
hp[21] = makeFUN(&&F_con);
hp[22] = makePTR(hp+12);
hp[23] = makePTR(hp+16);
hp[24] = makeHDR(3);
hp[25] = makeFUN(&&F_dis);
hp[26] = makePTR(hp+8);
hp[27] = makePTR(hp+20);
atom = makePTR(hp+24);
hp += 28;
L_POP(3);
L_PUSH(atom);
goto F_dis;
}
}
F_unify:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2586;
  goto GC_COLLECT;
}
  GC_RET_2586:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = makeCTR(C_Nil);
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = getPTR(L_sp[-1])[3];
hp[7] = makeCTR(C_Nil);
hp[8] = makeHDR(4);
hp[9] = makeFUN(&&F_unifyWith);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
hp[12] = makeCTR(C_Nil);
atom = makePTR(hp+8);
hp += 13;
L_POP(1);
L_PUSH(atom);
goto F_unifyWith;
F_unifyWith:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2589;
  goto GC_COLLECT;
}
  GC_RET_2589:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2590;
goto EVAL;
LABEL_2590:
switch (res) {
case C_Nil:
atom = getPTR(L_sp[-2])[3];
getPTR(L_sp[-2])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2591;
goto EVAL;
LABEL_2591:
switch (res) {
case C_Nil:
hp[0] = makeHDR(2);
hp[1] = makeCTR(C_Just);
hp[2] = getPTR(L_sp[-3])[4];
atom = makePTR(hp+0);
hp += 3;
L_POP(3);
L_PUSH(atom);
res = C_Just;
goto EVAL_RET;
}
case C_Cons:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_2592;
goto EVAL;
LABEL_2592:
switch (res) {
case C_Var:
atom = getPTR(L_sp[-3])[3];
getPTR(L_sp[-3])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2593;
goto EVAL;
LABEL_2593:
switch (res) {
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_subst);
hp[2] = getPTR(L_sp[-4])[4];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(2);
hp[5] = makeCTR(C_Var);
hp[6] = getPTR(L_sp[-2])[2];
hp[7] = makeHDR(3);
hp[8] = makeFUN(&&F_subst);
hp[9] = getPTR(L_sp[-4])[4];
hp[10] = makePTR(hp+4);
hp[11] = makeHDR(3);
hp[12] = makeFUN(&&F_unify);
hp[13] = makePTR(hp+7);
hp[14] = makePTR(hp+0);
hp[15] = makeHDR(9);
hp[16] = makeFUN(&&F_unifyWith___0);
hp[17] = getPTR(L_sp[-1])[2];
hp[18] = getPTR(L_sp[-2])[2];
hp[19] = getPTR(L_sp[-3])[3];
hp[20] = getPTR(L_sp[-1])[3];
hp[21] = getPTR(L_sp[-4])[4];
hp[22] = makePTR(hp+7);
hp[23] = makePTR(hp+0);
hp[24] = makePTR(hp+11);
atom = makePTR(hp+15);
hp += 25;
L_POP(4);
L_PUSH(atom);
goto F_unifyWith___0;
}
case C_Fun:
atom = getPTR(L_sp[-3])[3];
getPTR(L_sp[-3])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2595;
goto EVAL;
LABEL_2595:
switch (res) {
case C_Cons:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_2596;
goto EVAL;
LABEL_2596:
switch (res) {
case C_Var:
hp[0] = makeHDR(2);
hp[1] = makeCTR(C_Var);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = makeHDR(3);
hp[4] = makeCTR(C_Cons);
hp[5] = makePTR(hp+0);
hp[6] = getPTR(L_sp[-2])[3];
hp[7] = makeHDR(3);
hp[8] = makeCTR(C_Fun);
hp[9] = getPTR(L_sp[-3])[2];
hp[10] = getPTR(L_sp[-3])[3];
hp[11] = makeHDR(3);
hp[12] = makeCTR(C_Cons);
hp[13] = makePTR(hp+7);
hp[14] = getPTR(L_sp[-4])[3];
hp[15] = makeHDR(4);
hp[16] = makeFUN(&&F_unifyWith);
hp[17] = makePTR(hp+3);
hp[18] = makePTR(hp+11);
hp[19] = getPTR(L_sp[-5])[4];
atom = makePTR(hp+15);
hp += 20;
L_POP(5);
L_PUSH(atom);
goto F_unifyWith;
case C_Fun:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_equalStrings);
hp[2] = getPTR(L_sp[-3])[2];
hp[3] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_2601;
goto EVAL;
LABEL_2601:
switch (res) {
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_append);
hp[2] = getPTR(L_sp[-4])[3];
hp[3] = getPTR(L_sp[-5])[3];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_append);
hp[6] = getPTR(L_sp[-2])[3];
hp[7] = getPTR(L_sp[-3])[3];
hp[8] = makeHDR(4);
hp[9] = makeFUN(&&F_unifyWith);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
hp[12] = getPTR(L_sp[-6])[4];
atom = makePTR(hp+8);
hp += 13;
L_POP(6);
L_PUSH(atom);
goto F_unifyWith;
case C_False:
L_POP(6);
L_PUSH(makeCTR(C_Nothing));
res = C_Nothing;
goto EVAL_RET;
}
}
}
}
}
F_unifyWith___1:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2604;
  goto GC_COLLECT;
}
  GC_RET_2604:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2605;
goto EVAL;
LABEL_2605:
switch (res) {
case C_Just:
atom = getPTR(L_sp[-1])[2];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
}
F_unifyWith___0:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2606;
  goto GC_COLLECT;
}
  GC_RET_2606:
hp[0] = makeHDR(2);
hp[1] = makeCTR(C_Var);
hp[2] = getPTR(L_sp[-1])[3];
hp[3] = makeHDR(3);
hp[4] = makeFUN(&&F_equalTerms);
hp[5] = getPTR(L_sp[-1])[2];
hp[6] = makePTR(hp+0);
atom = makePTR(hp+3);
hp += 7;
eval_ret_addr = &&LABEL_2608;
goto EVAL;
LABEL_2608:
switch (res) {
case C_True:
hp[0] = makeHDR(4);
hp[1] = makeFUN(&&F_unifyWith);
hp[2] = getPTR(L_sp[-2])[4];
hp[3] = getPTR(L_sp[-2])[5];
hp[4] = getPTR(L_sp[-2])[6];
atom = makePTR(hp+0);
hp += 5;
L_POP(2);
L_PUSH(atom);
goto F_unifyWith;
case C_False:
hp[0] = makeHDR(2);
hp[1] = makeCTR(C_Var);
hp[2] = getPTR(L_sp[-2])[3];
hp[3] = makeHDR(3);
hp[4] = makeFUN(&&F_equalTerms);
hp[5] = getPTR(L_sp[-2])[7];
hp[6] = makePTR(hp+0);
atom = makePTR(hp+3);
hp += 7;
eval_ret_addr = &&LABEL_2610;
goto EVAL;
LABEL_2610:
switch (res) {
case C_True:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_vars);
hp[2] = getPTR(L_sp[-3])[8];
hp[3] = makeHDR(3);
hp[4] = makeFUN(&&F_elemByES);
hp[5] = getPTR(L_sp[-3])[3];
hp[6] = makePTR(hp+0);
atom = makePTR(hp+3);
hp += 7;
eval_ret_addr = &&LABEL_2612;
goto EVAL;
LABEL_2612:
switch (res) {
case C_True:
L_POP(4);
L_PUSH(makeCTR(C_Nothing));
res = C_Nothing;
goto EVAL_RET;
case C_False:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Pair);
hp[2] = getPTR(L_sp[-4])[3];
hp[3] = getPTR(L_sp[-4])[8];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = makePTR(hp+0);
hp[7] = makeCTR(C_Nil);
hp[8] = makeHDR(3);
hp[9] = makeFUN(&&F_substAdd);
hp[10] = makePTR(hp+4);
hp[11] = getPTR(L_sp[-4])[6];
hp[12] = makeHDR(4);
hp[13] = makeFUN(&&F_unifyWith);
hp[14] = getPTR(L_sp[-4])[4];
hp[15] = getPTR(L_sp[-4])[5];
hp[16] = makePTR(hp+8);
atom = makePTR(hp+12);
hp += 17;
L_POP(4);
L_PUSH(atom);
goto F_unifyWith;
}
case C_False:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_isJust);
hp[2] = getPTR(L_sp[-3])[9];
atom = makePTR(hp+0);
hp += 3;
eval_ret_addr = &&LABEL_2616;
goto EVAL;
LABEL_2616:
switch (res) {
case C_True:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_unifyWith___1);
hp[2] = getPTR(L_sp[-4])[9];
hp[3] = makeHDR(3);
hp[4] = makeFUN(&&F_substAdd);
hp[5] = makePTR(hp+0);
hp[6] = getPTR(L_sp[-4])[6];
hp[7] = makeHDR(4);
hp[8] = makeFUN(&&F_unifyWith);
hp[9] = getPTR(L_sp[-4])[4];
hp[10] = getPTR(L_sp[-4])[5];
hp[11] = makePTR(hp+3);
atom = makePTR(hp+7);
hp += 12;
L_POP(4);
L_PUSH(atom);
goto F_unifyWith;
case C_False:
L_POP(4);
L_PUSH(makeCTR(C_Nothing));
res = C_Nothing;
goto EVAL_RET;
}
}
}
F_mapCIS:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2619;
  goto GC_COLLECT;
}
  GC_RET_2619:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2620;
goto EVAL;
LABEL_2620:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_crossIdSubst);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_mapCIS);
hp[6] = getPTR(L_sp[-2])[2];
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
F_substAdd:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2623;
  goto GC_COLLECT;
}
  GC_RET_2623:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_mapCIS);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-1])[3];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_append);
hp[6] = getPTR(L_sp[-1])[2];
hp[7] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 8;
L_POP(1);
L_PUSH(atom);
goto F_append;
F_match:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2625;
  goto GC_COLLECT;
}
  GC_RET_2625:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = makeCTR(C_Nil);
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = getPTR(L_sp[-1])[3];
hp[7] = makeCTR(C_Nil);
hp[8] = makeHDR(4);
hp[9] = makeFUN(&&F_matchWith);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
hp[12] = makeCTR(C_Nil);
atom = makePTR(hp+8);
hp += 13;
L_POP(1);
L_PUSH(atom);
goto F_matchWith;
F_matchWith:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2628;
  goto GC_COLLECT;
}
  GC_RET_2628:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2629;
goto EVAL;
LABEL_2629:
switch (res) {
case C_Nil:
atom = getPTR(L_sp[-2])[3];
getPTR(L_sp[-2])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2630;
goto EVAL;
LABEL_2630:
switch (res) {
case C_Nil:
hp[0] = makeHDR(2);
hp[1] = makeCTR(C_Just);
hp[2] = getPTR(L_sp[-3])[4];
atom = makePTR(hp+0);
hp += 3;
L_POP(3);
L_PUSH(atom);
res = C_Just;
goto EVAL_RET;
}
case C_Cons:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_2631;
goto EVAL;
LABEL_2631:
switch (res) {
case C_Var:
atom = getPTR(L_sp[-3])[3];
getPTR(L_sp[-3])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2632;
goto EVAL;
LABEL_2632:
switch (res) {
case C_Cons:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_mapFst);
hp[2] = getPTR(L_sp[-4])[4];
hp[3] = makeHDR(3);
hp[4] = makeFUN(&&F_elemByES);
hp[5] = getPTR(L_sp[-2])[2];
hp[6] = makePTR(hp+0);
atom = makePTR(hp+3);
hp += 7;
eval_ret_addr = &&LABEL_2634;
goto EVAL;
LABEL_2634:
switch (res) {
case C_True:
hp[0] = makeHDR(2);
hp[1] = makeCTR(C_Var);
hp[2] = getPTR(L_sp[-3])[2];
hp[3] = makeHDR(3);
hp[4] = makeFUN(&&F_subst);
hp[5] = getPTR(L_sp[-5])[4];
hp[6] = makePTR(hp+0);
hp[7] = makeHDR(3);
hp[8] = makeFUN(&&F_equalTerms);
hp[9] = getPTR(L_sp[-2])[2];
hp[10] = makePTR(hp+3);
atom = makePTR(hp+7);
hp += 11;
eval_ret_addr = &&LABEL_2637;
goto EVAL;
LABEL_2637:
switch (res) {
case C_True:
hp[0] = makeHDR(4);
hp[1] = makeFUN(&&F_matchWith);
hp[2] = getPTR(L_sp[-5])[3];
hp[3] = getPTR(L_sp[-3])[3];
hp[4] = getPTR(L_sp[-6])[4];
atom = makePTR(hp+0);
hp += 5;
L_POP(6);
L_PUSH(atom);
goto F_matchWith;
case C_False:
L_POP(6);
L_PUSH(makeCTR(C_Nothing));
res = C_Nothing;
goto EVAL_RET;
}
case C_False:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Pair);
hp[2] = getPTR(L_sp[-3])[2];
hp[3] = getPTR(L_sp[-2])[2];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = makePTR(hp+0);
hp[7] = getPTR(L_sp[-5])[4];
hp[8] = makeHDR(4);
hp[9] = makeFUN(&&F_matchWith);
hp[10] = getPTR(L_sp[-4])[3];
hp[11] = getPTR(L_sp[-2])[3];
hp[12] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 13;
L_POP(5);
L_PUSH(atom);
goto F_matchWith;
}
}
case C_Fun:
atom = getPTR(L_sp[-3])[3];
getPTR(L_sp[-3])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2640;
goto EVAL;
LABEL_2640:
switch (res) {
case C_Cons:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_2641;
goto EVAL;
LABEL_2641:
switch (res) {
case C_Var:
L_POP(5);
L_PUSH(makeCTR(C_Nothing));
res = C_Nothing;
goto EVAL_RET;
case C_Fun:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_equalStrings);
hp[2] = getPTR(L_sp[-3])[2];
hp[3] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_2642;
goto EVAL;
LABEL_2642:
switch (res) {
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_append);
hp[2] = getPTR(L_sp[-4])[3];
hp[3] = getPTR(L_sp[-5])[3];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_append);
hp[6] = getPTR(L_sp[-2])[3];
hp[7] = getPTR(L_sp[-3])[3];
hp[8] = makeHDR(4);
hp[9] = makeFUN(&&F_matchWith);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
hp[12] = getPTR(L_sp[-6])[4];
atom = makePTR(hp+8);
hp += 13;
L_POP(6);
L_PUSH(atom);
goto F_matchWith;
case C_False:
L_POP(6);
L_PUSH(makeCTR(C_Nothing));
res = C_Nothing;
goto EVAL_RET;
}
}
}
}
}
F_concatMapNF:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2645;
  goto GC_COLLECT;
}
  GC_RET_2645:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2646;
goto EVAL;
LABEL_2646:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_normalForms);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_concatMapNF);
hp[6] = getPTR(L_sp[-2])[2];
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(3);
hp[9] = makeFUN(&&F_append);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(2);
L_PUSH(atom);
goto F_append;
}
F_normalForms:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2649;
  goto GC_COLLECT;
}
  GC_RET_2649:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_reduce);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-1])[3];
hp[4] = makeHDR(4);
hp[5] = makeFUN(&&F_normalForms___0);
hp[6] = makePTR(hp+0);
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+4);
hp += 9;
L_POP(1);
L_PUSH(atom);
goto F_normalForms___0;
F_normalForms___0:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2650;
  goto GC_COLLECT;
}
  GC_RET_2650:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_null);
hp[2] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+0);
hp += 3;
eval_ret_addr = &&LABEL_2651;
goto EVAL;
LABEL_2651:
switch (res) {
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = getPTR(L_sp[-2])[3];
hp[3] = makeCTR(C_Nil);
atom = makePTR(hp+0);
hp += 4;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
case C_False:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_concatMapNF);
hp[2] = getPTR(L_sp[-2])[4];
hp[3] = getPTR(L_sp[-2])[2];
atom = makePTR(hp+0);
hp += 4;
L_POP(2);
L_PUSH(atom);
goto F_concatMapNF;
}
F_norm:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2652;
  goto GC_COLLECT;
}
  GC_RET_2652:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_normalForms);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-1])[3];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_2653;
goto EVAL;
LABEL_2653:
switch (res) {
case C_Cons:
atom = getPTR(L_sp[-1])[2];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
}
F_reducible:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2654;
  goto GC_COLLECT;
}
  GC_RET_2654:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_reduce);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-1])[3];
hp[4] = makeHDR(2);
hp[5] = makeFUN(&&F_null);
hp[6] = makePTR(hp+0);
hp[7] = makeHDR(2);
hp[8] = makeFUN(&&F_not);
hp[9] = makePTR(hp+4);
atom = makePTR(hp+7);
hp += 10;
L_POP(1);
L_PUSH(atom);
goto F_not;
F_concatMapRA:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2657;
  goto GC_COLLECT;
}
  GC_RET_2657:
atom = getPTR(L_sp[-1])[4];
getPTR(L_sp[-1])[4] = makeINT(0);
eval_ret_addr = &&LABEL_2658;
goto EVAL;
LABEL_2658:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(4);
hp[1] = makeFUN(&&F_reduceAt);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = getPTR(L_sp[-1])[2];
hp[5] = makeHDR(4);
hp[6] = makeFUN(&&F_concatMapRA);
hp[7] = getPTR(L_sp[-2])[2];
hp[8] = getPTR(L_sp[-2])[3];
hp[9] = getPTR(L_sp[-1])[3];
hp[10] = makeHDR(3);
hp[11] = makeFUN(&&F_append);
hp[12] = makePTR(hp+0);
hp[13] = makePTR(hp+5);
atom = makePTR(hp+10);
hp += 14;
L_POP(2);
L_PUSH(atom);
goto F_append;
}
F_reduce:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2661;
  goto GC_COLLECT;
}
  GC_RET_2661:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_positions);
hp[2] = getPTR(L_sp[-1])[3];
hp[3] = makeHDR(4);
hp[4] = makeFUN(&&F_concatMapRA);
hp[5] = getPTR(L_sp[-1])[2];
hp[6] = getPTR(L_sp[-1])[3];
hp[7] = makePTR(hp+0);
atom = makePTR(hp+3);
hp += 8;
L_POP(1);
L_PUSH(atom);
goto F_concatMapRA;
F_concatMapRAW:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2663;
  goto GC_COLLECT;
}
  GC_RET_2663:
atom = getPTR(L_sp[-1])[4];
getPTR(L_sp[-1])[4] = makeINT(0);
eval_ret_addr = &&LABEL_2664;
goto EVAL;
LABEL_2664:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(4);
hp[1] = makeFUN(&&F_reduceAtWith);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = getPTR(L_sp[-1])[2];
hp[5] = makeHDR(4);
hp[6] = makeFUN(&&F_concatMapRAW);
hp[7] = getPTR(L_sp[-2])[2];
hp[8] = getPTR(L_sp[-2])[3];
hp[9] = getPTR(L_sp[-1])[3];
hp[10] = makeHDR(3);
hp[11] = makeFUN(&&F_append);
hp[12] = makePTR(hp+0);
hp[13] = makePTR(hp+5);
atom = makePTR(hp+10);
hp += 14;
L_POP(2);
L_PUSH(atom);
goto F_append;
}
F_reduceAt:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2667;
  goto GC_COLLECT;
}
  GC_RET_2667:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_subterm);
hp[2] = getPTR(L_sp[-1])[3];
hp[3] = getPTR(L_sp[-1])[4];
hp[4] = makeHDR(2);
hp[5] = makeFUN(&&F_isVar);
hp[6] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 7;
eval_ret_addr = &&LABEL_2669;
goto EVAL;
LABEL_2669:
switch (res) {
case C_True:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_False:
hp[0] = makeHDR(4);
hp[1] = makeFUN(&&F_concatMapRAW);
hp[2] = getPTR(L_sp[-2])[3];
hp[3] = getPTR(L_sp[-2])[4];
hp[4] = getPTR(L_sp[-2])[2];
atom = makePTR(hp+0);
hp += 5;
L_POP(2);
L_PUSH(atom);
goto F_concatMapRAW;
}
F_reduceAtWith:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2670;
  goto GC_COLLECT;
}
  GC_RET_2670:
atom = getPTR(L_sp[-1])[4];
getPTR(L_sp[-1])[4] = makeINT(0);
eval_ret_addr = &&LABEL_2671;
goto EVAL;
LABEL_2671:
switch (res) {
case C_Pair:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_subterm);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_match);
hp[6] = getPTR(L_sp[-1])[2];
hp[7] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 8;
eval_ret_addr = &&LABEL_2673;
goto EVAL;
LABEL_2673:
switch (res) {
case C_Nothing:
L_POP(3);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Just:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_subst);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = makeHDR(4);
hp[5] = makeFUN(&&F_placeAt);
hp[6] = makePTR(hp+0);
hp[7] = getPTR(L_sp[-3])[3];
hp[8] = getPTR(L_sp[-3])[2];
hp[9] = makeHDR(3);
hp[10] = makeCTR(C_Cons);
hp[11] = makePTR(hp+4);
hp[12] = makeCTR(C_Nil);
atom = makePTR(hp+9);
hp += 13;
L_POP(3);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
}
F_isVar:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2676;
  goto GC_COLLECT;
}
  GC_RET_2676:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2677;
goto EVAL;
LABEL_2677:
switch (res) {
case C_Var:
L_POP(2);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
case C_Fun:
L_POP(2);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
}
F_mapSubst:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2678;
  goto GC_COLLECT;
}
  GC_RET_2678:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2679;
goto EVAL;
LABEL_2679:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_subst);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_mapSubst);
hp[6] = getPTR(L_sp[-2])[2];
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
F_subst:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2682;
  goto GC_COLLECT;
}
  GC_RET_2682:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2683;
goto EVAL;
LABEL_2683:
switch (res) {
case C_Var:
atom = getPTR(L_sp[-2])[2];
getPTR(L_sp[-2])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2684;
goto EVAL;
LABEL_2684:
switch (res) {
case C_Nil:
hp[0] = makeHDR(2);
hp[1] = makeCTR(C_Var);
hp[2] = getPTR(L_sp[-2])[2];
atom = makePTR(hp+0);
hp += 3;
L_POP(3);
L_PUSH(atom);
res = C_Var;
goto EVAL_RET;
case C_Cons:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_2685;
goto EVAL;
LABEL_2685:
switch (res) {
case C_Pair:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_equalStrings);
hp[2] = getPTR(L_sp[-3])[2];
hp[3] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+0);
hp += 4;
eval_ret_addr = &&LABEL_2686;
goto EVAL;
LABEL_2686:
switch (res) {
case C_True:
atom = getPTR(L_sp[-2])[3];
L_POP(5);
goto TAIL_EVAL;
goto EVAL_RET;
case C_False:
hp[0] = makeHDR(2);
hp[1] = makeCTR(C_Var);
hp[2] = getPTR(L_sp[-4])[2];
hp[3] = makeHDR(3);
hp[4] = makeFUN(&&F_subst);
hp[5] = getPTR(L_sp[-3])[3];
hp[6] = makePTR(hp+0);
atom = makePTR(hp+3);
hp += 7;
L_POP(5);
L_PUSH(atom);
goto F_subst;
}
}
}
case C_Fun:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_mapSubst);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[3];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Fun);
hp[6] = getPTR(L_sp[-1])[2];
hp[7] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 8;
L_POP(2);
L_PUSH(atom);
res = C_Fun;
goto EVAL_RET;
}
F_zipWithET:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2689;
  goto GC_COLLECT;
}
  GC_RET_2689:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2690;
goto EVAL;
LABEL_2690:
switch (res) {
case C_Nil:
atom = getPTR(L_sp[-2])[3];
getPTR(L_sp[-2])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2691;
goto EVAL;
LABEL_2691:
switch (res) {
case C_Nil:
L_POP(3);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
L_POP(3);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
}
case C_Cons:
atom = getPTR(L_sp[-2])[3];
getPTR(L_sp[-2])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2692;
goto EVAL;
LABEL_2692:
switch (res) {
case C_Nil:
L_POP(3);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_equalTerms);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_zipWithET);
hp[6] = getPTR(L_sp[-2])[3];
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(3);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
}
F_equalTerms:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2695;
  goto GC_COLLECT;
}
  GC_RET_2695:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2696;
goto EVAL;
LABEL_2696:
switch (res) {
case C_Var:
atom = getPTR(L_sp[-2])[3];
getPTR(L_sp[-2])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2697;
goto EVAL;
LABEL_2697:
switch (res) {
case C_Var:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_equalStrings);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+0);
hp += 4;
L_POP(3);
L_PUSH(atom);
goto F_equalStrings;
case C_Fun:
L_POP(3);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
}
case C_Fun:
atom = getPTR(L_sp[-2])[3];
getPTR(L_sp[-2])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2698;
goto EVAL;
LABEL_2698:
switch (res) {
case C_Var:
L_POP(3);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
case C_Fun:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_equalStrings);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_zipWithET);
hp[6] = getPTR(L_sp[-2])[3];
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(2);
hp[9] = makeFUN(&&F_and);
hp[10] = makePTR(hp+4);
hp[11] = makeHDR(3);
hp[12] = makeFUN(&&F_con);
hp[13] = makePTR(hp+0);
hp[14] = makePTR(hp+8);
atom = makePTR(hp+11);
hp += 15;
L_POP(3);
L_PUSH(atom);
goto F_con;
}
}
F_applyToIndex:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2702;
  goto GC_COLLECT;
}
  GC_RET_2702:
atom = getPTR(L_sp[-1])[5];
getPTR(L_sp[-1])[5] = makeINT(0);
eval_ret_addr = &&LABEL_2703;
goto EVAL;
LABEL_2703:
switch (res) {
case C_Cons:
atom = getPTR(L_sp[-2])[4];
eval_ret_addr = &&LABEL_2704;
goto EVAL;
LABEL_2704:
L_PUSH(makeINT(0));
res = 0;
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(1);
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
hp[0] = makeHDR(4);
hp[1] = makeFUN(&&F_placeAt);
hp[2] = getPTR(L_sp[-3])[2];
hp[3] = getPTR(L_sp[-3])[3];
hp[4] = getPTR(L_sp[-2])[2];
hp[5] = makeHDR(3);
hp[6] = makeCTR(C_Cons);
hp[7] = makePTR(hp+0);
hp[8] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+5);
hp += 9;
L_POP(3);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
case C_False:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&P_SUB);
hp[2] = getPTR(L_sp[-3])[4];
hp[3] = makeINT(1);
hp[4] = makeHDR(5);
hp[5] = makeFUN(&&F_applyToIndex);
hp[6] = getPTR(L_sp[-3])[2];
hp[7] = getPTR(L_sp[-3])[3];
hp[8] = makePTR(hp+0);
hp[9] = getPTR(L_sp[-2])[3];
hp[10] = makeHDR(3);
hp[11] = makeCTR(C_Cons);
hp[12] = getPTR(L_sp[-2])[2];
hp[13] = makePTR(hp+4);
atom = makePTR(hp+10);
hp += 14;
L_POP(3);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
}
F_equiv:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2708;
  goto GC_COLLECT;
}
  GC_RET_2708:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_match);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-1])[3];
hp[4] = makeHDR(2);
hp[5] = makeFUN(&&F_isJust);
hp[6] = makePTR(hp+0);
hp[7] = makeHDR(3);
hp[8] = makeFUN(&&F_match);
hp[9] = getPTR(L_sp[-1])[3];
hp[10] = getPTR(L_sp[-1])[2];
hp[11] = makeHDR(2);
hp[12] = makeFUN(&&F_isJust);
hp[13] = makePTR(hp+7);
hp[14] = makeHDR(3);
hp[15] = makeFUN(&&F_con);
hp[16] = makePTR(hp+4);
hp[17] = makePTR(hp+11);
atom = makePTR(hp+14);
hp += 18;
L_POP(1);
L_PUSH(atom);
goto F_con;
F_subterm:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2713;
  goto GC_COLLECT;
}
  GC_RET_2713:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2714;
goto EVAL;
LABEL_2714:
switch (res) {
case C_Nil:
atom = getPTR(L_sp[-2])[2];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
case C_Cons:
atom = getPTR(L_sp[-2])[2];
getPTR(L_sp[-2])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2715;
goto EVAL;
LABEL_2715:
switch (res) {
case C_Fun:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&P_SUB);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = makeINT(1);
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_elemAt);
hp[6] = getPTR(L_sp[-1])[3];
hp[7] = makePTR(hp+0);
hp[8] = makeHDR(3);
hp[9] = makeFUN(&&F_subterm);
hp[10] = makePTR(hp+4);
hp[11] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+8);
hp += 12;
L_POP(3);
L_PUSH(atom);
goto F_subterm;
}
}
F_placeAt:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2718;
  goto GC_COLLECT;
}
  GC_RET_2718:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2719;
goto EVAL;
LABEL_2719:
switch (res) {
case C_Nil:
atom = getPTR(L_sp[-2])[2];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
case C_Cons:
atom = getPTR(L_sp[-2])[4];
getPTR(L_sp[-2])[4] = makeINT(0);
eval_ret_addr = &&LABEL_2720;
goto EVAL;
LABEL_2720:
switch (res) {
case C_Fun:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&P_SUB);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = makeINT(1);
hp[4] = makeHDR(5);
hp[5] = makeFUN(&&F_applyToIndex);
hp[6] = getPTR(L_sp[-3])[2];
hp[7] = getPTR(L_sp[-2])[3];
hp[8] = makePTR(hp+0);
hp[9] = getPTR(L_sp[-1])[3];
hp[10] = makeHDR(3);
hp[11] = makeCTR(C_Fun);
hp[12] = getPTR(L_sp[-1])[2];
hp[13] = makePTR(hp+4);
atom = makePTR(hp+10);
hp += 14;
L_POP(3);
L_PUSH(atom);
res = C_Fun;
goto EVAL_RET;
}
}
F_mapVars:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2723;
  goto GC_COLLECT;
}
  GC_RET_2723:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2724;
goto EVAL;
LABEL_2724:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_vars);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = makeHDR(2);
hp[4] = makeFUN(&&F_mapVars);
hp[5] = getPTR(L_sp[-1])[3];
hp[6] = makeHDR(3);
hp[7] = makeCTR(C_Cons);
hp[8] = makePTR(hp+0);
hp[9] = makePTR(hp+3);
atom = makePTR(hp+6);
hp += 10;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
F_foldrU:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2727;
  goto GC_COLLECT;
}
  GC_RET_2727:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2728;
goto EVAL;
LABEL_2728:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_foldrU);
hp[2] = getPTR(L_sp[-1])[3];
hp[3] = makeHDR(3);
hp[4] = makeFUN(&&F_unionBy);
hp[5] = getPTR(L_sp[-1])[2];
hp[6] = makePTR(hp+0);
atom = makePTR(hp+3);
hp += 7;
L_POP(2);
L_PUSH(atom);
goto F_unionBy;
}
F_vars:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2730;
  goto GC_COLLECT;
}
  GC_RET_2730:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2731;
goto EVAL;
LABEL_2731:
switch (res) {
case C_Var:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = makeCTR(C_Nil);
atom = makePTR(hp+0);
hp += 4;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
case C_Fun:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_mapVars);
hp[2] = getPTR(L_sp[-1])[3];
hp[3] = makeHDR(2);
hp[4] = makeFUN(&&F_foldrU);
hp[5] = makePTR(hp+0);
atom = makePTR(hp+3);
hp += 6;
L_POP(2);
L_PUSH(atom);
goto F_foldrU;
}
F_concatMapAP:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2733;
  goto GC_COLLECT;
}
  GC_RET_2733:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2734;
goto EVAL;
LABEL_2734:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_argPositions);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_concatMapAP);
hp[6] = getPTR(L_sp[-2])[2];
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(3);
hp[9] = makeFUN(&&F_append);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(2);
L_PUSH(atom);
goto F_append;
}
F_positions:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2737;
  goto GC_COLLECT;
}
  GC_RET_2737:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2738;
goto EVAL;
LABEL_2738:
switch (res) {
case C_Var:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = makeCTR(C_Nil);
hp[3] = makeCTR(C_Nil);
atom = makePTR(hp+0);
hp += 4;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
case C_Fun:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_length);
hp[2] = getPTR(L_sp[-1])[3];
hp[3] = makeHDR(3);
hp[4] = makeFUN(&&F_enumFromTo);
hp[5] = makeINT(1);
hp[6] = makePTR(hp+0);
hp[7] = makeHDR(3);
hp[8] = makeFUN(&&F_concatMapAP);
hp[9] = getPTR(L_sp[-1])[3];
hp[10] = makePTR(hp+3);
hp[11] = makeHDR(3);
hp[12] = makeCTR(C_Cons);
hp[13] = makeCTR(C_Nil);
hp[14] = makePTR(hp+7);
atom = makePTR(hp+11);
hp += 15;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
F_mapCons:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2742;
  goto GC_COLLECT;
}
  GC_RET_2742:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2743;
goto EVAL;
LABEL_2743:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_mapCons);
hp[6] = getPTR(L_sp[-2])[2];
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
F_argPositions:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2746;
  goto GC_COLLECT;
}
  GC_RET_2746:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&P_SUB);
hp[2] = getPTR(L_sp[-1])[3];
hp[3] = makeINT(1);
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_elemAt);
hp[6] = getPTR(L_sp[-1])[2];
hp[7] = makePTR(hp+0);
hp[8] = makeHDR(2);
hp[9] = makeFUN(&&F_positions);
hp[10] = makePTR(hp+4);
hp[11] = makeHDR(3);
hp[12] = makeFUN(&&F_mapCons);
hp[13] = getPTR(L_sp[-1])[3];
hp[14] = makePTR(hp+8);
atom = makePTR(hp+11);
hp += 15;
L_POP(1);
L_PUSH(atom);
goto F_mapCons;
F_concatMapV:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2750;
  goto GC_COLLECT;
}
  GC_RET_2750:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_2751;
goto EVAL;
LABEL_2751:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_variations);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = makeHDR(2);
hp[4] = makeFUN(&&F_concatMapV);
hp[5] = getPTR(L_sp[-1])[3];
hp[6] = makeHDR(3);
hp[7] = makeFUN(&&F_append);
hp[8] = makePTR(hp+0);
hp[9] = makePTR(hp+3);
atom = makePTR(hp+6);
hp += 10;
L_POP(2);
L_PUSH(atom);
goto F_append;
}
F_mapFlipCons:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2754;
  goto GC_COLLECT;
}
  GC_RET_2754:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_2755;
goto EVAL;
LABEL_2755:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-2])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_mapFlipCons);
hp[6] = getPTR(L_sp[-2])[2];
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
F_variations:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2758;
  goto GC_COLLECT;
}
  GC_RET_2758:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = makeINT(90);
hp[3] = makeCTR(C_Nil);
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = makeINT(89);
hp[7] = makePTR(hp+0);
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makeINT(88);
hp[11] = makePTR(hp+4);
hp[12] = makeHDR(3);
hp[13] = makeCTR(C_Cons);
hp[14] = makeINT(87);
hp[15] = makePTR(hp+8);
hp[16] = makeHDR(3);
hp[17] = makeCTR(C_Cons);
hp[18] = makeINT(86);
hp[19] = makePTR(hp+12);
hp[20] = makeHDR(3);
hp[21] = makeCTR(C_Cons);
hp[22] = makeINT(85);
hp[23] = makePTR(hp+16);
hp[24] = makeHDR(3);
hp[25] = makeCTR(C_Cons);
hp[26] = makeINT(84);
hp[27] = makePTR(hp+20);
hp[28] = makeHDR(3);
hp[29] = makeCTR(C_Cons);
hp[30] = makeINT(83);
hp[31] = makePTR(hp+24);
hp[32] = makeHDR(3);
hp[33] = makeCTR(C_Cons);
hp[34] = makeINT(82);
hp[35] = makePTR(hp+28);
hp[36] = makeHDR(3);
hp[37] = makeCTR(C_Cons);
hp[38] = makeINT(81);
hp[39] = makePTR(hp+32);
hp[40] = makeHDR(3);
hp[41] = makeCTR(C_Cons);
hp[42] = makeINT(80);
hp[43] = makePTR(hp+36);
hp[44] = makeHDR(3);
hp[45] = makeCTR(C_Cons);
hp[46] = makeINT(79);
hp[47] = makePTR(hp+40);
hp[48] = makeHDR(3);
hp[49] = makeCTR(C_Cons);
hp[50] = makeINT(78);
hp[51] = makePTR(hp+44);
hp[52] = makeHDR(3);
hp[53] = makeCTR(C_Cons);
hp[54] = makeINT(77);
hp[55] = makePTR(hp+48);
hp[56] = makeHDR(3);
hp[57] = makeCTR(C_Cons);
hp[58] = makeINT(76);
hp[59] = makePTR(hp+52);
hp[60] = makeHDR(3);
hp[61] = makeCTR(C_Cons);
hp[62] = makeINT(75);
hp[63] = makePTR(hp+56);
hp[64] = makeHDR(3);
hp[65] = makeCTR(C_Cons);
hp[66] = makeINT(74);
hp[67] = makePTR(hp+60);
hp[68] = makeHDR(3);
hp[69] = makeCTR(C_Cons);
hp[70] = makeINT(73);
hp[71] = makePTR(hp+64);
hp[72] = makeHDR(3);
hp[73] = makeCTR(C_Cons);
hp[74] = makeINT(72);
hp[75] = makePTR(hp+68);
hp[76] = makeHDR(3);
hp[77] = makeCTR(C_Cons);
hp[78] = makeINT(71);
hp[79] = makePTR(hp+72);
hp[80] = makeHDR(3);
hp[81] = makeCTR(C_Cons);
hp[82] = makeINT(70);
hp[83] = makePTR(hp+76);
hp[84] = makeHDR(3);
hp[85] = makeCTR(C_Cons);
hp[86] = makeINT(69);
hp[87] = makePTR(hp+80);
hp[88] = makeHDR(3);
hp[89] = makeCTR(C_Cons);
hp[90] = makeINT(68);
hp[91] = makePTR(hp+84);
hp[92] = makeHDR(3);
hp[93] = makeCTR(C_Cons);
hp[94] = makeINT(67);
hp[95] = makePTR(hp+88);
hp[96] = makeHDR(3);
hp[97] = makeCTR(C_Cons);
hp[98] = makeINT(66);
hp[99] = makePTR(hp+92);
hp[100] = makeHDR(3);
hp[101] = makeCTR(C_Cons);
hp[102] = makeINT(65);
hp[103] = makePTR(hp+96);
hp[104] = makeHDR(3);
hp[105] = makeFUN(&&F_mapFlipCons);
hp[106] = getPTR(L_sp[-1])[2];
hp[107] = makePTR(hp+100);
atom = makePTR(hp+104);
hp += 108;
L_POP(1);
L_PUSH(atom);
goto F_mapFlipCons;
P_ADD:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2785;
  goto GC_COLLECT;
}
  GC_RET_2785:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_2786;
goto EVAL;
LABEL_2786:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_2787;
goto EVAL;
LABEL_2787:
L_POP(1);
res = getINT(L_top) + res;
L_POP(2);
L_PUSH(makeINT(res));
goto EVAL_RET;
P_SUB:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2788;
  goto GC_COLLECT;
}
  GC_RET_2788:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_2789;
goto EVAL;
LABEL_2789:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_2790;
goto EVAL;
LABEL_2790:
L_POP(1);
res = getINT(L_top) - res;
L_POP(2);
L_PUSH(makeINT(res));
goto EVAL_RET;
P_EQ:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2791;
  goto GC_COLLECT;
}
  GC_RET_2791:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_2792;
goto EVAL;
LABEL_2792:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_2793;
goto EVAL;
LABEL_2793:
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(2);
L_PUSH(makeCTR(res));
goto EVAL_RET;
P_NEQ:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2794;
  goto GC_COLLECT;
}
  GC_RET_2794:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_2795;
goto EVAL;
LABEL_2795:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_2796;
goto EVAL;
LABEL_2796:
L_POP(1);
res = getINT(L_top) != res ? C_True : C_False;
L_POP(2);
L_PUSH(makeCTR(res));
goto EVAL_RET;
P_LEQ:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_2797;
  goto GC_COLLECT;
}
  GC_RET_2797:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_2798;
goto EVAL;
LABEL_2798:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_2799;
goto EVAL;
LABEL_2799:
L_POP(1);
res = getINT(L_top) <= res ? C_True : C_False;
L_POP(2);
L_PUSH(makeCTR(res));
goto EVAL_RET;
GC_COPY:
if (from[0] == VISITED) {
  atom = from[1];
  goto *gc_copy_ret;
}
if (isPTR(from[1])) { from = getPTR(from[1]); goto GC_COPY; }
if (size(from[0]) == 1) { atom = from[1]; }
else {
  n = size(from[0]) + 1;
  //printf("Copy (%i);\n", n-1);
  atom = makePTR(free);
  for (i = 0; i < n; i++)
    { *free = from[i]; free++; }
  from[0] = VISITED;
  from[1] = atom;
}
goto *gc_copy_ret;
GC_COLLECT:
//printf("GC invoked (%i);\n", hp - fromSpace);
scan = toSpace;
free = toSpace;
for (p = L_base; p < L_sp; p++) {
  if (isPTR(*p)) {
    from = getPTR(*p);
    gc_copy_ret = &&GC_COPY_RET1; goto GC_COPY; GC_COPY_RET1:
    *p = atom;
  }
}
while (scan < free) {
  m = size(*scan); scan++;
  //printf("Scan (%i);\n", m);
  for (j = 0; j < m; j++) {
    if (isPTR(*scan)) {
      from = getPTR(*scan);
      gc_copy_ret = &&GC_COPY_RET2; goto GC_COPY; GC_COPY_RET2:
      *scan = atom;
    }
    scan++;
  }
}
for (frame = R_base; frame > R_sp; frame--) {
  p = frame->current;
  frame->current = 0;
  while (p && p[0] != VISITED && isPTR(p[1])) p = getPTR(p[1]);
  if (p && p[0] == VISITED) {
    if (isPTR(p[1])) frame->current = getPTR(p[1]);
  }
}
hp = free;
p = fromSpace; fromSpace = toSpace; toSpace = p;
p = fromSpaceEnd; fromSpaceEnd = toSpaceEnd; toSpaceEnd = p;
heapEnd = fromSpaceEnd;
L_top = L_sp[-1];
R_top_returnAddress = R_sp[1].returnAddress;
R_top_current = R_sp[1].current;
//printf("GC finished (%i);\n", hp - fromSpace);
goto *gc_ret;
}



