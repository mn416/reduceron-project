#include <stdio.h>
#include <stdlib.h>
typedef unsigned int Atom;
#define isPTR(a)   (((a)&3) == 0)
#define isCTR(a)   (((a)&3) == 1)
#define isINT(a)   (((a)&3) == 2)
#define isFUN(a)   (((a)&3) == 3)
#define getPTR(a)  ((Atom*) (a))
#define getCTR(a)  ((a) >> 2)
#define getINT(a)  ((int) (((int) (a)) >> 2))
#define getFUN(a)  ((void*) (((unsigned int) (a)) & (~3)))
#define makePTR(x) ((Atom) (x))
#define makeCTR(x) ((Atom) (((x) << 2) | 1))
#define makeINT(x) ((Atom) ((((unsigned int) (x)) << 2) | 2))
#define makeFUN(x) ((Atom) (((unsigned int) (x)) | 3))
#define HEAP_SIZE 22000
#define STACK_SIZE 3000
typedef struct {
  Atom* current;
  void* returnAddress;
} Frame;
#define L_POP(n) L_sp-=n; L_top = L_sp[-1];
#define L_PUSH(a) L_top = a; L_sp[0] = L_top; L_sp++;
#define R_POP \
  R_sp++;\
  R_top_returnAddress = R_sp[1].returnAddress;\
  R_top_current = R_sp[1].current;
#define R_PUSH(ra, cur) \
  R_top_returnAddress = R_sp[0].returnAddress = ra; \
  R_top_current = R_sp[0].current = cur; \
  R_sp--;
#define makeHDR(x)        ((x) << 1)
#define VISITED           1
#define size(x)           ((x) >> 1)
#define C_False 0
#define C_True 1
#define C_Cons 0
#define C_Nil 1


int main() {
register Atom* L_sp;
Atom* L_base;
register Atom L_top;
register Frame* R_sp;
Frame* R_base;
register void* R_top_returnAddress;
register Atom* R_top_current;
register Atom* hp;
register Atom* heapEnd;
register Atom atom;
register Atom* app;
register int res;
Atom* fromSpace;
Atom* toSpace;
Atom* fromSpaceEnd;
Atom* toSpaceEnd;
Atom* scan;
Atom* free;
Atom* p;
Atom* from;
Frame* frame;
void* gc_copy_ret;
void* gc_ret;
void* eval_ret_addr;
int i;
int j;
int n;
int m;
L_base = L_sp = malloc(sizeof(Atom) * STACK_SIZE);
R_base = R_sp = (Frame*) &L_sp[STACK_SIZE-1];
fromSpace = hp = malloc(sizeof(Atom) * HEAP_SIZE);
heapEnd = fromSpaceEnd = &fromSpace[HEAP_SIZE-1000];
toSpace = malloc(sizeof(Atom) * HEAP_SIZE);
toSpaceEnd = &toSpace[HEAP_SIZE-1000];
print("S");
atom = makePTR(hp);
*hp++ = makeHDR(1); *hp++ =  makeFUN(&&F_main);
L_PUSH(atom);
eval_ret_addr = &&LABEL_139;
goto EVAL;
LABEL_139:
putnum(getINT(L_top));
return 0;
EVAL:
if (isPTR(atom)) {
  app = getPTR(atom);
  EVAL_APP:
  if (isFUN(app[1])) {
    L_PUSH(makePTR(app));
    R_PUSH(eval_ret_addr, app);
    goto *getFUN(app[1]);
    EVAL_RET:
    if (R_top_current) {
      R_top_current[0] = makeHDR(1);
      R_top_current[1] = L_top;
    }
    eval_ret_addr = R_top_returnAddress;
    R_POP;
    goto *eval_ret_addr;
  }
  else if (isCTR(app[1])) {
    L_PUSH(makePTR(app)); res = getCTR(app[1]);
    goto *eval_ret_addr;
  }
  else if (isPTR(app[1])) {
    app = getPTR(app[1]);
    goto EVAL_APP;
  }
  else {
    L_PUSH(app[1]); res = getINT(app[1]);
    goto *eval_ret_addr;
  }
} else {
  L_PUSH(atom);
  res = getINT(atom);
  goto *eval_ret_addr;
}
TAIL_EVAL:
if (isPTR(atom)) {
  app = getPTR(atom);
  TAIL_EVAL_APP:
  if (isFUN(app[1])) {
    L_PUSH(makePTR(app));
    if (R_top_current) {
      R_top_current[0] = makeHDR(1);
      R_top_current[1] = makePTR(app);
    }
    R_top_current = R_sp[1].current = app;
    goto *getFUN(app[1]);
  }
  else if (isPTR(app[1])) {
    app = getPTR(app[1]);
    goto TAIL_EVAL_APP;
  }
  else if (isINT(app[1])) {
    L_PUSH(app[1]); res = getINT(app[1]);
    goto EVAL_RET;
  }
  else {
    L_PUSH(makePTR(app)); res = getCTR(app[1]);
    goto EVAL_RET;
  }
} else {
  L_PUSH(atom);
  res = getINT(atom);
  goto EVAL_RET;
}
F_replicate_V__V_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_140;
  goto GC_COLLECT;
}
  GC_RET_140:
res = getINT(getPTR(L_sp[-1])[2])==0? C_True : C_False;
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_False:
hp[0] = makeINT(getINT(getPTR(L_sp[-2])[2])-1);
hp[1] = makeHDR(3);
hp[2] = makeFUN(&&F_replicate_V__V_);
hp[3] = hp[0];
hp[4] = getPTR(L_sp[-2])[3];
hp[5] = makeHDR(3);
hp[6] = makeCTR(C_Cons);
hp[7] = getPTR(L_sp[-2])[3];
hp[8] = makePTR(hp+1);
atom = makePTR(hp+5);
hp += 9;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
F_mapCons_V__V_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_143;
  goto GC_COLLECT;
}
  GC_RET_143:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_144;
goto EVAL;
LABEL_144:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_mapCons_V__V_);
hp[6] = getPTR(L_sp[-2])[2];
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
F_lrd_V__V_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_147;
  goto GC_COLLECT;
}
  GC_RET_147:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_148;
goto EVAL;
LABEL_148:
switch (res) {
case C_Nil:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = makeINT(2);
hp[3] = makeCTR(C_Nil);
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = makeINT(1);
hp[7] = makePTR(hp+0);
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makeINT(0);
hp[11] = makePTR(hp+4);
hp[12] = makeHDR(3);
hp[13] = makeCTR(C_Cons);
hp[14] = makePTR(hp+8);
hp[15] = getPTR(L_sp[-2])[3];
hp[16] = makeHDR(3);
hp[17] = makeCTR(C_Cons);
hp[18] = makePTR(hp+12);
hp[19] = makeCTR(C_Nil);
atom = makePTR(hp+16);
hp += 20;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
case C_Cons:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
}
F_append_V__V_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_153;
  goto GC_COLLECT;
}
  GC_RET_153:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_154;
goto EVAL;
LABEL_154:
switch (res) {
case C_Nil:
atom = getPTR(L_sp[-2])[3];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_append_V__V_);
hp[2] = getPTR(L_sp[-1])[3];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = getPTR(L_sp[-1])[2];
hp[7] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 8;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
F_fill_V_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_156;
  goto GC_COLLECT;
}
  GC_RET_156:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_157;
goto EVAL;
LABEL_157:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_lrd_V__V_);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-1])[3];
hp[4] = makeHDR(2);
hp[5] = makeFUN(&&F_fill_V_);
hp[6] = getPTR(L_sp[-1])[3];
hp[7] = makeHDR(3);
hp[8] = makeFUN(&&F_mapCons_V__V_);
hp[9] = getPTR(L_sp[-1])[2];
hp[10] = makePTR(hp+4);
hp[11] = makeHDR(3);
hp[12] = makeFUN(&&F_append_V__V_);
hp[13] = makePTR(hp+0);
hp[14] = makePTR(hp+7);
atom = makePTR(hp+11);
hp += 15;
L_POP(2);
L_PUSH(atom);
goto F_append_V__V_;
}
F_next___0_V_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_161;
  goto GC_COLLECT;
}
  GC_RET_161:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_162;
goto EVAL;
LABEL_162:
switch (res) {
case C_Cons:
atom = getPTR(L_sp[-1])[3];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
}
F_oneEq_V__V_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_163;
  goto GC_COLLECT;
}
  GC_RET_163:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_164;
goto EVAL;
LABEL_164:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
res = getINT(getPTR(L_sp[-2])[2])==getINT(getPTR(L_sp[-1])[2])? C_True : C_False;
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = makeCTR(C_Nil);
atom = makePTR(hp+0);
hp += 4;
L_POP(3);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
case C_False:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_oneEq_V__V_);
hp[2] = getPTR(L_sp[-3])[2];
hp[3] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+0);
hp += 4;
L_POP(3);
L_PUSH(atom);
goto F_oneEq_V__V_;
}
}
F_mapOneEq_V__V_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_165;
  goto GC_COLLECT;
}
  GC_RET_165:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_166;
goto EVAL;
LABEL_166:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_oneEq_V__V_);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_mapOneEq_V__V_);
hp[6] = getPTR(L_sp[-2])[2];
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
F_append_V__Q_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_169;
  goto GC_COLLECT;
}
  GC_RET_169:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_170;
goto EVAL;
LABEL_170:
switch (res) {
case C_Nil:
atom = getPTR(L_sp[-2])[3];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_append_V__Q_);
hp[2] = getPTR(L_sp[-1])[3];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = getPTR(L_sp[-1])[2];
hp[7] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 8;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
F_merge_V__Q_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_172;
  goto GC_COLLECT;
}
  GC_RET_172:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_173;
goto EVAL;
LABEL_173:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
atom = getPTR(L_sp[-2])[3];
getPTR(L_sp[-2])[3] = makeINT(0);
eval_ret_addr = &&LABEL_174;
goto EVAL;
LABEL_174:
switch (res) {
case C_Nil:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+0);
hp += 4;
L_POP(3);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_append_V__Q_);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_merge_V__Q_);
hp[6] = getPTR(L_sp[-2])[3];
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(3);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
}
F_append_Q__V_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_177;
  goto GC_COLLECT;
}
  GC_RET_177:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_178;
goto EVAL;
LABEL_178:
switch (res) {
case C_Nil:
atom = getPTR(L_sp[-2])[3];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_append_Q__V_);
hp[2] = getPTR(L_sp[-1])[3];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = getPTR(L_sp[-1])[2];
hp[7] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 8;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
F_merge_Q__V_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_180;
  goto GC_COLLECT;
}
  GC_RET_180:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_181;
goto EVAL;
LABEL_181:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
atom = getPTR(L_sp[-2])[3];
getPTR(L_sp[-2])[3] = makeINT(0);
eval_ret_addr = &&LABEL_182;
goto EVAL;
LABEL_182:
switch (res) {
case C_Nil:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+0);
hp += 4;
L_POP(3);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_append_Q__V_);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_merge_Q__V_);
hp[6] = getPTR(L_sp[-2])[3];
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(3);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
}
F_next_V_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_185;
  goto GC_COLLECT;
}
  GC_RET_185:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_mapOneEq_V__V_);
hp[2] = makeINT(2);
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(2);
hp[5] = makeFUN(&&F_next___0_V_);
hp[6] = getPTR(L_sp[-1])[2];
hp[7] = makeHDR(3);
hp[8] = makeFUN(&&F_mapOneEq_V__Q_);
hp[9] = makeINT(0);
hp[10] = makePTR(hp+4);
hp[11] = makeHDR(3);
hp[12] = makeFUN(&&F_merge_V__Q_);
hp[13] = makePTR(hp+0);
hp[14] = makePTR(hp+7);
hp[15] = makeHDR(3);
hp[16] = makeFUN(&&F_mapOneEq_V__V_);
hp[17] = makeINT(1);
hp[18] = getPTR(L_sp[-1])[2];
hp[19] = makeHDR(3);
hp[20] = makeCTR(C_Cons);
hp[21] = makeCTR(C_Nil);
hp[22] = makePTR(hp+15);
hp[23] = makeHDR(3);
hp[24] = makeFUN(&&F_merge_Q__V_);
hp[25] = makePTR(hp+11);
hp[26] = makePTR(hp+19);
atom = makePTR(hp+23);
hp += 27;
L_POP(1);
L_PUSH(atom);
goto F_merge_Q__V_;
F_lrd_Q__Q_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_192;
  goto GC_COLLECT;
}
  GC_RET_192:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_193;
goto EVAL;
LABEL_193:
switch (res) {
case C_Nil:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = makeINT(2);
hp[3] = makeCTR(C_Nil);
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = makeINT(1);
hp[7] = makePTR(hp+0);
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makeINT(0);
hp[11] = makePTR(hp+4);
hp[12] = makeHDR(3);
hp[13] = makeCTR(C_Cons);
hp[14] = makePTR(hp+8);
hp[15] = getPTR(L_sp[-2])[3];
hp[16] = makeHDR(3);
hp[17] = makeCTR(C_Cons);
hp[18] = makePTR(hp+12);
hp[19] = makeCTR(C_Nil);
atom = makePTR(hp+16);
hp += 20;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
case C_Cons:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
}
F_fill_Q_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_198;
  goto GC_COLLECT;
}
  GC_RET_198:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_199;
goto EVAL;
LABEL_199:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_lrd_Q__Q_);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-1])[3];
hp[4] = makeHDR(2);
hp[5] = makeFUN(&&F_fill_Q_);
hp[6] = getPTR(L_sp[-1])[3];
hp[7] = makeHDR(3);
hp[8] = makeFUN(&&F_mapCons_Q__Q_);
hp[9] = getPTR(L_sp[-1])[2];
hp[10] = makePTR(hp+4);
hp[11] = makeHDR(3);
hp[12] = makeFUN(&&F_append_Q__Q_);
hp[13] = makePTR(hp+0);
hp[14] = makePTR(hp+7);
atom = makePTR(hp+11);
hp += 15;
L_POP(2);
L_PUSH(atom);
goto F_append_Q__Q_;
}
F_next___0_Q_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_203;
  goto GC_COLLECT;
}
  GC_RET_203:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_204;
goto EVAL;
LABEL_204:
switch (res) {
case C_Cons:
atom = getPTR(L_sp[-1])[3];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
}
F_oneEq_V__Q_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_205;
  goto GC_COLLECT;
}
  GC_RET_205:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_206;
goto EVAL;
LABEL_206:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
atom = getPTR(L_sp[-2])[2];
eval_ret_addr = &&LABEL_207;
goto EVAL;
LABEL_207:
atom = getPTR(L_sp[-2])[2];
eval_ret_addr = &&LABEL_208;
goto EVAL;
LABEL_208:
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(1);
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = makeCTR(C_Nil);
atom = makePTR(hp+0);
hp += 4;
L_POP(3);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
case C_False:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_oneEq_V__Q_);
hp[2] = getPTR(L_sp[-3])[2];
hp[3] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+0);
hp += 4;
L_POP(3);
L_PUSH(atom);
goto F_oneEq_V__Q_;
}
}
F_mapOneEq_V__Q_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_209;
  goto GC_COLLECT;
}
  GC_RET_209:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_210;
goto EVAL;
LABEL_210:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_oneEq_V__Q_);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_mapOneEq_V__Q_);
hp[6] = getPTR(L_sp[-2])[2];
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
F_merge_Q__Q_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_213;
  goto GC_COLLECT;
}
  GC_RET_213:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_214;
goto EVAL;
LABEL_214:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
atom = getPTR(L_sp[-2])[3];
getPTR(L_sp[-2])[3] = makeINT(0);
eval_ret_addr = &&LABEL_215;
goto EVAL;
LABEL_215:
switch (res) {
case C_Nil:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+0);
hp += 4;
L_POP(3);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_append_Q__Q_);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_merge_Q__Q_);
hp[6] = getPTR(L_sp[-2])[3];
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(3);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
}
F_next_Q_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_218;
  goto GC_COLLECT;
}
  GC_RET_218:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_mapOneEq_V__Q_);
hp[2] = makeINT(2);
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(2);
hp[5] = makeFUN(&&F_next___0_Q_);
hp[6] = getPTR(L_sp[-1])[2];
hp[7] = makeHDR(3);
hp[8] = makeFUN(&&F_mapOneEq_V__Q_);
hp[9] = makeINT(0);
hp[10] = makePTR(hp+4);
hp[11] = makeHDR(3);
hp[12] = makeFUN(&&F_merge_Q__Q_);
hp[13] = makePTR(hp+0);
hp[14] = makePTR(hp+7);
hp[15] = makeHDR(3);
hp[16] = makeFUN(&&F_mapOneEq_V__Q_);
hp[17] = makeINT(1);
hp[18] = getPTR(L_sp[-1])[2];
hp[19] = makeHDR(3);
hp[20] = makeCTR(C_Cons);
hp[21] = makeCTR(C_Nil);
hp[22] = makePTR(hp+15);
hp[23] = makeHDR(3);
hp[24] = makeFUN(&&F_merge_Q__Q_);
hp[25] = makePTR(hp+11);
hp[26] = makePTR(hp+19);
atom = makePTR(hp+23);
hp += 27;
L_POP(1);
L_PUSH(atom);
goto F_merge_Q__Q_;
F_mapCons_Q__Q_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_225;
  goto GC_COLLECT;
}
  GC_RET_225:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_226;
goto EVAL;
LABEL_226:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_mapCons_Q__Q_);
hp[6] = getPTR(L_sp[-2])[2];
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
F_sol_V__Q_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_229;
  goto GC_COLLECT;
}
  GC_RET_229:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_next_Q_);
hp[2] = getPTR(L_sp[-1])[3];
hp[3] = makeHDR(3);
hp[4] = makeFUN(&&F_solve_V__Q_);
hp[5] = getPTR(L_sp[-1])[2];
hp[6] = makePTR(hp+0);
hp[7] = makeHDR(3);
hp[8] = makeFUN(&&F_mapCons_Q__Q_);
hp[9] = getPTR(L_sp[-1])[3];
hp[10] = makePTR(hp+3);
atom = makePTR(hp+7);
hp += 11;
L_POP(1);
L_PUSH(atom);
goto F_mapCons_Q__Q_;
F_concatMapSol_V__Q_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_232;
  goto GC_COLLECT;
}
  GC_RET_232:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_233;
goto EVAL;
LABEL_233:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_sol_V__Q_);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_concatMapSol_V__Q_);
hp[6] = getPTR(L_sp[-2])[2];
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(3);
hp[9] = makeFUN(&&F_append_Q__Q_);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(2);
L_PUSH(atom);
goto F_append_Q__Q_;
}
F_solve_V__Q_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_236;
  goto GC_COLLECT;
}
  GC_RET_236:
res = getINT(getPTR(L_sp[-1])[2])==0? C_True : C_False;
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = makeCTR(C_Nil);
hp[3] = makeCTR(C_Nil);
atom = makePTR(hp+0);
hp += 4;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
case C_False:
hp[0] = makeINT(getINT(getPTR(L_sp[-2])[2])-1);
hp[1] = makeHDR(2);
hp[2] = makeFUN(&&F_fill_Q_);
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_concatMapSol_V__Q_);
hp[6] = hp[0];
hp[7] = makePTR(hp+1);
atom = makePTR(hp+4);
hp += 8;
L_POP(2);
L_PUSH(atom);
goto F_concatMapSol_V__Q_;
}
F_mapCons_V__Q_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_239;
  goto GC_COLLECT;
}
  GC_RET_239:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_240;
goto EVAL;
LABEL_240:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_mapCons_V__Q_);
hp[6] = getPTR(L_sp[-2])[2];
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
F_sol_V__V_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_243;
  goto GC_COLLECT;
}
  GC_RET_243:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_next_V_);
hp[2] = getPTR(L_sp[-1])[3];
hp[3] = makeHDR(3);
hp[4] = makeFUN(&&F_solve_V__Q_);
hp[5] = getPTR(L_sp[-1])[2];
hp[6] = makePTR(hp+0);
hp[7] = makeHDR(3);
hp[8] = makeFUN(&&F_mapCons_V__Q_);
hp[9] = getPTR(L_sp[-1])[3];
hp[10] = makePTR(hp+3);
atom = makePTR(hp+7);
hp += 11;
L_POP(1);
L_PUSH(atom);
goto F_mapCons_V__Q_;
F_append_Q__Q_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_246;
  goto GC_COLLECT;
}
  GC_RET_246:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_247;
goto EVAL;
LABEL_247:
switch (res) {
case C_Nil:
atom = getPTR(L_sp[-2])[3];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_append_Q__Q_);
hp[2] = getPTR(L_sp[-1])[3];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = getPTR(L_sp[-1])[2];
hp[7] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 8;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
F_concatMapSol_V__V_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_249;
  goto GC_COLLECT;
}
  GC_RET_249:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_250;
goto EVAL;
LABEL_250:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_sol_V__V_);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_concatMapSol_V__V_);
hp[6] = getPTR(L_sp[-2])[2];
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(3);
hp[9] = makeFUN(&&F_append_Q__Q_);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(2);
L_PUSH(atom);
goto F_append_Q__Q_;
}
F_solve_V__V_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_253;
  goto GC_COLLECT;
}
  GC_RET_253:
res = getINT(getPTR(L_sp[-1])[2])==0? C_True : C_False;
L_PUSH(makeCTR(res));
switch (res) {
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = makeCTR(C_Nil);
hp[3] = makeCTR(C_Nil);
atom = makePTR(hp+0);
hp += 4;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
case C_False:
hp[0] = makeINT(getINT(getPTR(L_sp[-2])[2])-1);
hp[1] = makeHDR(2);
hp[2] = makeFUN(&&F_fill_V_);
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_concatMapSol_V__V_);
hp[6] = hp[0];
hp[7] = makePTR(hp+1);
atom = makePTR(hp+4);
hp += 8;
L_POP(2);
L_PUSH(atom);
goto F_concatMapSol_V__V_;
}
F_lengthAcc_V__Q_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_256;
  goto GC_COLLECT;
}
  GC_RET_256:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_257;
goto EVAL;
LABEL_257:
switch (res) {
case C_Nil:
atom = getPTR(L_sp[-2])[2];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
case C_Cons:
hp[0] = makeINT(1+getINT(getPTR(L_sp[-2])[2]));
hp[1] = makeHDR(3);
hp[2] = makeFUN(&&F_lengthAcc_V__Q_);
hp[3] = hp[0];
hp[4] = getPTR(L_sp[-1])[3];
atom = makePTR(hp+1);
hp += 5;
L_POP(2);
L_PUSH(atom);
goto F_lengthAcc_V__Q_;
}
F_nqueens_V_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_259;
  goto GC_COLLECT;
}
  GC_RET_259:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_replicate_V__V_);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = makeCTR(C_Nil);
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_solve_V__V_);
hp[6] = getPTR(L_sp[-1])[2];
hp[7] = makePTR(hp+0);
hp[8] = makeHDR(3);
hp[9] = makeFUN(&&F_lengthAcc_V__Q_);
hp[10] = makeINT(0);
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(1);
L_PUSH(atom);
goto F_lengthAcc_V__Q_;
F_main:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_262;
  goto GC_COLLECT;
}
  GC_RET_262:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_nqueens_V_);
hp[2] = makeINT(11);
atom = makePTR(hp+0);
hp += 3;
L_POP(1);
L_PUSH(atom);
goto F_nqueens_V_;
P_ADD:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_263;
  goto GC_COLLECT;
}
  GC_RET_263:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_264;
goto EVAL;
LABEL_264:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_265;
goto EVAL;
LABEL_265:
L_POP(1);
res = getINT(L_top) + res;
L_POP(2);
L_PUSH(makeINT(res));
goto EVAL_RET;
P_SUB:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_266;
  goto GC_COLLECT;
}
  GC_RET_266:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_267;
goto EVAL;
LABEL_267:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_268;
goto EVAL;
LABEL_268:
L_POP(1);
res = getINT(L_top) - res;
L_POP(2);
L_PUSH(makeINT(res));
goto EVAL_RET;
P_EQ:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_269;
  goto GC_COLLECT;
}
  GC_RET_269:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_270;
goto EVAL;
LABEL_270:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_271;
goto EVAL;
LABEL_271:
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(2);
L_PUSH(makeCTR(res));
goto EVAL_RET;
P_NEQ:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_272;
  goto GC_COLLECT;
}
  GC_RET_272:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_273;
goto EVAL;
LABEL_273:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_274;
goto EVAL;
LABEL_274:
L_POP(1);
res = getINT(L_top) != res ? C_True : C_False;
L_POP(2);
L_PUSH(makeCTR(res));
goto EVAL_RET;
P_LEQ:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_275;
  goto GC_COLLECT;
}
  GC_RET_275:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_276;
goto EVAL;
LABEL_276:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_277;
goto EVAL;
LABEL_277:
L_POP(1);
res = getINT(L_top) <= res ? C_True : C_False;
L_POP(2);
L_PUSH(makeCTR(res));
goto EVAL_RET;
GC_COPY:
if (from[0] == VISITED) {
  atom = from[1];
  goto *gc_copy_ret;
}
if (isPTR(from[1])) { from = getPTR(from[1]); goto GC_COPY; }
if (size(from[0]) == 1) { atom = from[1]; }
else {
  n = size(from[0]) + 1;
  //printf("Copy (%i);\n", n-1);
  atom = makePTR(free);
  for (i = 0; i < n; i++)
    { *free = from[i]; free++; }
  from[0] = VISITED;
  from[1] = atom;
}
goto *gc_copy_ret;
GC_COLLECT:
//printf("GC invoked (%i);\n", hp - fromSpace);
scan = toSpace;
free = toSpace;
for (p = L_base; p < L_sp; p++) {
  if (isPTR(*p)) {
    from = getPTR(*p);
    gc_copy_ret = &&GC_COPY_RET1; goto GC_COPY; GC_COPY_RET1:
    *p = atom;
  }
}
while (scan < free) {
  m = size(*scan); scan++;
  //printf("Scan (%i);\n", m);
  for (j = 0; j < m; j++) {
    if (isPTR(*scan)) {
      from = getPTR(*scan);
      gc_copy_ret = &&GC_COPY_RET2; goto GC_COPY; GC_COPY_RET2:
      *scan = atom;
    }
    scan++;
  }
}
for (frame = R_base; frame > R_sp; frame--) {
  p = frame->current;
  frame->current = 0;
  while (p && p[0] != VISITED && isPTR(p[1])) p = getPTR(p[1]);
  if (p && p[0] == VISITED) {
    if (isPTR(p[1])) frame->current = getPTR(p[1]);
  }
}
hp = free;
p = fromSpace; fromSpace = toSpace; toSpace = p;
p = fromSpaceEnd; fromSpaceEnd = toSpaceEnd; toSpaceEnd = p;
heapEnd = fromSpaceEnd;
L_top = L_sp[-1];
R_top_returnAddress = R_sp[1].returnAddress;
R_top_current = R_sp[1].current;
//printf("GC finished (%i);\n", hp - fromSpace);
goto *gc_ret;
}



