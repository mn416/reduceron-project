#include <stdio.h>
#include <stdlib.h>
typedef unsigned int Atom;
#define isPTR(a)   (((a)&3) == 0)
#define isCTR(a)   (((a)&3) == 1)
#define isINT(a)   (((a)&3) == 2)
#define isFUN(a)   (((a)&3) == 3)
#define getPTR(a)  ((Atom*) (a))
#define getCTR(a)  ((a) >> 2)
#define getINT(a)  ((int) (((int) (a)) >> 2))
#define getFUN(a)  ((void*) (((unsigned int) (a)) & (~3)))
#define makePTR(x) ((Atom) (x))
#define makeCTR(x) ((Atom) (((x) << 2) | 1))
#define makeINT(x) ((Atom) ((((unsigned int) (x)) << 2) | 2))
#define makeFUN(x) ((Atom) (((unsigned int) (x)) | 3))
#define HEAP_SIZE 22000
#define STACK_SIZE 3000
typedef struct {
  Atom* current;
  void* returnAddress;
} Frame;
#define L_POP(n) L_sp-=n; L_top = L_sp[-1];
#define L_PUSH(a) L_top = a; L_sp[0] = L_top; L_sp++;
#define R_POP \
  R_sp++;\
  R_top_returnAddress = R_sp[1].returnAddress;\
  R_top_current = R_sp[1].current;
#define R_PUSH(ra, cur) \
  R_top_returnAddress = R_sp[0].returnAddress = ra; \
  R_top_current = R_sp[0].current = cur; \
  R_sp--;
#define makeHDR(x)        ((x) << 1)
#define VISITED           1
#define size(x)           ((x) >> 1)
#define C_False 0
#define C_True 1
#define C_Cons 0
#define C_Nil 1


int main() {
register Atom* L_sp;
Atom* L_base;
register Atom L_top;
register Frame* R_sp;
Frame* R_base;
register void* R_top_returnAddress;
register Atom* R_top_current;
register Atom* hp;
register Atom* heapEnd;
register Atom atom;
register Atom* app;
register int res;
Atom* fromSpace;
Atom* toSpace;
Atom* fromSpaceEnd;
Atom* toSpaceEnd;
Atom* scan;
Atom* free;
Atom* p;
Atom* from;
Frame* frame;
void* gc_copy_ret;
void* gc_ret;
void* eval_ret_addr;
int i;
int j;
int n;
int m;
L_base = L_sp = malloc(sizeof(Atom) * STACK_SIZE);
R_base = R_sp = (Frame*) &L_sp[STACK_SIZE-1];
fromSpace = hp = malloc(sizeof(Atom) * HEAP_SIZE);
heapEnd = fromSpaceEnd = &fromSpace[HEAP_SIZE-1000];
toSpace = malloc(sizeof(Atom) * HEAP_SIZE);
toSpaceEnd = &toSpace[HEAP_SIZE-1000];
print("S");
atom = makePTR(hp);
*hp++ = makeHDR(1); *hp++ =  makeFUN(&&F_main);
L_PUSH(atom);
eval_ret_addr = &&LABEL_111;
goto EVAL;
LABEL_111:
putnum(getINT(L_top));
return 0;
EVAL:
if (isPTR(atom)) {
  app = getPTR(atom);
  EVAL_APP:
  if (isFUN(app[1])) {
    L_PUSH(makePTR(app));
    R_PUSH(eval_ret_addr, app);
    goto *getFUN(app[1]);
    EVAL_RET:
    if (R_top_current) {
      R_top_current[0] = makeHDR(1);
      R_top_current[1] = L_top;
    }
    eval_ret_addr = R_top_returnAddress;
    R_POP;
    goto *eval_ret_addr;
  }
  else if (isCTR(app[1])) {
    L_PUSH(makePTR(app)); res = getCTR(app[1]);
    goto *eval_ret_addr;
  }
  else if (isPTR(app[1])) {
    app = getPTR(app[1]);
    goto EVAL_APP;
  }
  else {
    L_PUSH(app[1]); res = getINT(app[1]);
    goto *eval_ret_addr;
  }
} else {
  L_PUSH(atom);
  res = getINT(atom);
  goto *eval_ret_addr;
}
TAIL_EVAL:
if (isPTR(atom)) {
  app = getPTR(atom);
  TAIL_EVAL_APP:
  if (isFUN(app[1])) {
    L_PUSH(makePTR(app));
    if (R_top_current) {
      R_top_current[0] = makeHDR(1);
      R_top_current[1] = makePTR(app);
    }
    R_top_current = R_sp[1].current = app;
    goto *getFUN(app[1]);
  }
  else if (isPTR(app[1])) {
    app = getPTR(app[1]);
    goto TAIL_EVAL_APP;
  }
  else if (isINT(app[1])) {
    L_PUSH(app[1]); res = getINT(app[1]);
    goto EVAL_RET;
  }
  else {
    L_PUSH(makePTR(app)); res = getCTR(app[1]);
    goto EVAL_RET;
  }
} else {
  L_PUSH(atom);
  res = getINT(atom);
  goto EVAL_RET;
}
F_mapCons_V__V_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_112;
  goto GC_COLLECT;
}
  GC_RET_112:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_113;
goto EVAL;
LABEL_113:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_mapCons_V__V_);
hp[6] = getPTR(L_sp[-2])[2];
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
F_place_V__V_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_116;
  goto GC_COLLECT;
}
  GC_RET_116:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_117;
goto EVAL;
LABEL_117:
switch (res) {
case C_Nil:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = makeCTR(C_Nil);
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = makePTR(hp+0);
hp[7] = makeCTR(C_Nil);
atom = makePTR(hp+4);
hp += 8;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = getPTR(L_sp[-1])[2];
hp[3] = getPTR(L_sp[-1])[3];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = getPTR(L_sp[-2])[2];
hp[7] = makePTR(hp+0);
hp[8] = makeHDR(3);
hp[9] = makeFUN(&&F_place_V__V_);
hp[10] = getPTR(L_sp[-2])[2];
hp[11] = getPTR(L_sp[-1])[3];
hp[12] = makeHDR(3);
hp[13] = makeFUN(&&F_mapCons_V__V_);
hp[14] = getPTR(L_sp[-1])[2];
hp[15] = makePTR(hp+8);
hp[16] = makeHDR(3);
hp[17] = makeCTR(C_Cons);
hp[18] = makePTR(hp+4);
hp[19] = makePTR(hp+12);
atom = makePTR(hp+16);
hp += 20;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
F_append_V__V_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_123;
  goto GC_COLLECT;
}
  GC_RET_123:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_124;
goto EVAL;
LABEL_124:
switch (res) {
case C_Nil:
atom = getPTR(L_sp[-2])[3];
L_POP(2);
goto TAIL_EVAL;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_append_V__V_);
hp[2] = getPTR(L_sp[-1])[3];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = getPTR(L_sp[-1])[2];
hp[7] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 8;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
}
F_concatMapPlace_V__V_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_126;
  goto GC_COLLECT;
}
  GC_RET_126:
atom = getPTR(L_sp[-1])[3];
getPTR(L_sp[-1])[3] = makeINT(0);
eval_ret_addr = &&LABEL_127;
goto EVAL;
LABEL_127:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(3);
hp[1] = makeFUN(&&F_place_V__V_);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-1])[2];
hp[4] = makeHDR(3);
hp[5] = makeFUN(&&F_concatMapPlace_V__V_);
hp[6] = getPTR(L_sp[-2])[2];
hp[7] = getPTR(L_sp[-1])[3];
hp[8] = makeHDR(3);
hp[9] = makeFUN(&&F_append_V__V_);
hp[10] = makePTR(hp+0);
hp[11] = makePTR(hp+4);
atom = makePTR(hp+8);
hp += 12;
L_POP(2);
L_PUSH(atom);
goto F_append_V__V_;
}
F_perm_V_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_130;
  goto GC_COLLECT;
}
  GC_RET_130:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_131;
goto EVAL;
LABEL_131:
switch (res) {
case C_Nil:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = makeCTR(C_Nil);
hp[3] = makeCTR(C_Nil);
atom = makePTR(hp+0);
hp += 4;
L_POP(2);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_perm_V_);
hp[2] = getPTR(L_sp[-1])[3];
hp[3] = makeHDR(3);
hp[4] = makeFUN(&&F_concatMapPlace_V__V_);
hp[5] = getPTR(L_sp[-1])[2];
hp[6] = makePTR(hp+0);
atom = makePTR(hp+3);
hp += 7;
L_POP(2);
L_PUSH(atom);
goto F_concatMapPlace_V__V_;
}
F_ord_V_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_133;
  goto GC_COLLECT;
}
  GC_RET_133:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_134;
goto EVAL;
LABEL_134:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
case C_Cons:
atom = getPTR(L_sp[-1])[3];
eval_ret_addr = &&LABEL_135;
goto EVAL;
LABEL_135:
switch (res) {
case C_Nil:
L_POP(3);
L_PUSH(makeCTR(C_True));
res = C_True;
goto EVAL_RET;
case C_Cons:
res = getINT(getPTR(L_sp[-2])[2])<=getINT(getPTR(L_sp[-1])[2])? C_True : C_False;
L_PUSH(makeCTR(res));
switch (res) {
case C_False:
L_POP(4);
L_PUSH(makeCTR(C_False));
res = C_False;
goto EVAL_RET;
case C_True:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = getPTR(L_sp[-2])[2];
hp[3] = getPTR(L_sp[-2])[3];
hp[4] = makeHDR(2);
hp[5] = makeFUN(&&F_ord_V_);
hp[6] = makePTR(hp+0);
atom = makePTR(hp+4);
hp += 7;
L_POP(4);
L_PUSH(atom);
goto F_ord_V_;
}
}
}
F_filterOrd_V_:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_137;
  goto GC_COLLECT;
}
  GC_RET_137:
atom = getPTR(L_sp[-1])[2];
getPTR(L_sp[-1])[2] = makeINT(0);
eval_ret_addr = &&LABEL_138;
goto EVAL;
LABEL_138:
switch (res) {
case C_Nil:
L_POP(2);
L_PUSH(makeCTR(C_Nil));
res = C_Nil;
goto EVAL_RET;
case C_Cons:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_ord_V_);
hp[2] = getPTR(L_sp[-1])[2];
atom = makePTR(hp+0);
hp += 3;
eval_ret_addr = &&LABEL_139;
goto EVAL;
LABEL_139:
switch (res) {
case C_True:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_filterOrd_V_);
hp[2] = getPTR(L_sp[-2])[3];
hp[3] = makeHDR(3);
hp[4] = makeCTR(C_Cons);
hp[5] = getPTR(L_sp[-2])[2];
hp[6] = makePTR(hp+0);
atom = makePTR(hp+3);
hp += 7;
L_POP(3);
L_PUSH(atom);
res = C_Cons;
goto EVAL_RET;
case C_False:
hp[0] = makeHDR(2);
hp[1] = makeFUN(&&F_filterOrd_V_);
hp[2] = getPTR(L_sp[-2])[3];
atom = makePTR(hp+0);
hp += 3;
L_POP(3);
L_PUSH(atom);
goto F_filterOrd_V_;
}
}
F_main:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_141;
  goto GC_COLLECT;
}
  GC_RET_141:
hp[0] = makeHDR(3);
hp[1] = makeCTR(C_Cons);
hp[2] = makeINT(1);
hp[3] = makeCTR(C_Nil);
hp[4] = makeHDR(3);
hp[5] = makeCTR(C_Cons);
hp[6] = makeINT(2);
hp[7] = makePTR(hp+0);
hp[8] = makeHDR(3);
hp[9] = makeCTR(C_Cons);
hp[10] = makeINT(3);
hp[11] = makePTR(hp+4);
hp[12] = makeHDR(3);
hp[13] = makeCTR(C_Cons);
hp[14] = makeINT(4);
hp[15] = makePTR(hp+8);
hp[16] = makeHDR(3);
hp[17] = makeCTR(C_Cons);
hp[18] = makeINT(5);
hp[19] = makePTR(hp+12);
hp[20] = makeHDR(3);
hp[21] = makeCTR(C_Cons);
hp[22] = makeINT(6);
hp[23] = makePTR(hp+16);
hp[24] = makeHDR(3);
hp[25] = makeCTR(C_Cons);
hp[26] = makeINT(7);
hp[27] = makePTR(hp+20);
hp[28] = makeHDR(3);
hp[29] = makeCTR(C_Cons);
hp[30] = makeINT(8);
hp[31] = makePTR(hp+24);
hp[32] = makeHDR(3);
hp[33] = makeCTR(C_Cons);
hp[34] = makeINT(9);
hp[35] = makePTR(hp+28);
hp[36] = makeHDR(3);
hp[37] = makeCTR(C_Cons);
hp[38] = makeINT(10);
hp[39] = makePTR(hp+32);
hp[40] = makeHDR(2);
hp[41] = makeFUN(&&F_perm_V_);
hp[42] = makePTR(hp+36);
hp[43] = makeHDR(2);
hp[44] = makeFUN(&&F_filterOrd_V_);
hp[45] = makePTR(hp+40);
atom = makePTR(hp+43);
hp += 46;
eval_ret_addr = &&LABEL_153;
goto EVAL;
LABEL_153:
switch (res) {
case C_Cons:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_154;
goto EVAL;
LABEL_154:
switch (res) {
case C_Cons:
atom = getPTR(L_sp[-1])[2];
L_POP(3);
goto TAIL_EVAL;
goto EVAL_RET;
}
}
P_ADD:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_155;
  goto GC_COLLECT;
}
  GC_RET_155:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_156;
goto EVAL;
LABEL_156:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_157;
goto EVAL;
LABEL_157:
L_POP(1);
res = getINT(L_top) + res;
L_POP(2);
L_PUSH(makeINT(res));
goto EVAL_RET;
P_SUB:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_158;
  goto GC_COLLECT;
}
  GC_RET_158:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_159;
goto EVAL;
LABEL_159:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_160;
goto EVAL;
LABEL_160:
L_POP(1);
res = getINT(L_top) - res;
L_POP(2);
L_PUSH(makeINT(res));
goto EVAL_RET;
P_EQ:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_161;
  goto GC_COLLECT;
}
  GC_RET_161:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_162;
goto EVAL;
LABEL_162:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_163;
goto EVAL;
LABEL_163:
L_POP(1);
res = getINT(L_top) == res ? C_True : C_False;
L_POP(2);
L_PUSH(makeCTR(res));
goto EVAL_RET;
P_NEQ:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_164;
  goto GC_COLLECT;
}
  GC_RET_164:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_165;
goto EVAL;
LABEL_165:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_166;
goto EVAL;
LABEL_166:
L_POP(1);
res = getINT(L_top) != res ? C_True : C_False;
L_POP(2);
L_PUSH(makeCTR(res));
goto EVAL_RET;
P_LEQ:
if (hp > heapEnd) {
  gc_ret = &&GC_RET_167;
  goto GC_COLLECT;
}
  GC_RET_167:
atom = getPTR(L_sp[-1])[2];
eval_ret_addr = &&LABEL_168;
goto EVAL;
LABEL_168:
atom = getPTR(L_sp[-2])[3];
eval_ret_addr = &&LABEL_169;
goto EVAL;
LABEL_169:
L_POP(1);
res = getINT(L_top) <= res ? C_True : C_False;
L_POP(2);
L_PUSH(makeCTR(res));
goto EVAL_RET;
GC_COPY:
if (from[0] == VISITED) {
  atom = from[1];
  goto *gc_copy_ret;
}
if (isPTR(from[1])) { from = getPTR(from[1]); goto GC_COPY; }
if (size(from[0]) == 1) { atom = from[1]; }
else {
  n = size(from[0]) + 1;
  //printf("Copy (%i);\n", n-1);
  atom = makePTR(free);
  for (i = 0; i < n; i++)
    { *free = from[i]; free++; }
  from[0] = VISITED;
  from[1] = atom;
}
goto *gc_copy_ret;
GC_COLLECT:
//printf("GC invoked (%i);\n", hp - fromSpace);
scan = toSpace;
free = toSpace;
for (p = L_base; p < L_sp; p++) {
  if (isPTR(*p)) {
    from = getPTR(*p);
    gc_copy_ret = &&GC_COPY_RET1; goto GC_COPY; GC_COPY_RET1:
    *p = atom;
  }
}
while (scan < free) {
  m = size(*scan); scan++;
  //printf("Scan (%i);\n", m);
  for (j = 0; j < m; j++) {
    if (isPTR(*scan)) {
      from = getPTR(*scan);
      gc_copy_ret = &&GC_COPY_RET2; goto GC_COPY; GC_COPY_RET2:
      *scan = atom;
    }
    scan++;
  }
}
for (frame = R_base; frame > R_sp; frame--) {
  p = frame->current;
  frame->current = 0;
  while (p && p[0] != VISITED && isPTR(p[1])) p = getPTR(p[1]);
  if (p && p[0] == VISITED) {
    if (isPTR(p[1])) frame->current = getPTR(p[1]);
  }
}
hp = free;
p = fromSpace; fromSpace = toSpace; toSpace = p;
p = fromSpaceEnd; fromSpaceEnd = toSpaceEnd; toSpaceEnd = p;
heapEnd = fromSpaceEnd;
L_top = L_sp[-1];
R_top_returnAddress = R_sp[1].returnAddress;
R_top_current = R_sp[1].current;
//printf("GC finished (%i);\n", hp - fromSpace);
goto *gc_ret;
}



