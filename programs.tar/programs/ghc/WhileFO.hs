module Main where {

import Prelude();
import Flite;
default(Int);

value (Cons (Pair x y) s) v =
  case (==) x v of { True -> y ; False -> value s v };

update Nil v i = Nil;
update (Cons (Pair x y) s) v i =
  case (==) x v of {
    True -> Cons (Pair v i) s;
    False -> Cons (Pair x y) (update s v i);
  };

not False = True;
not True = False;

and False x = False;
and True x = x;

data Val = N Int | V Int | Add Val Val | Sub Val Val;

aval (N n) s = n;
aval (V x) s = value s x;
aval (Add a1 a2) s = (+) (aval a1 s) (aval a2 s);
aval (Sub a1 a2) s = (-) (aval a1 s) (aval a2 s);

data BVal = TRUE | FALSE | Eq Val Val | Le Val Val | Neg BVal | And BVal BVal;

bval TRUE s = True;
bval FALSE s = False;
bval (Eq a1 a2) s = (==) (aval a1 s) (aval a2 s);
bval (Le a1 a2) s = (<=) (aval a1 s) (aval a2 s);
bval (Neg b) s = not (bval b s);
bval (And a1 a2) s = and (bval a1 s) (bval a2 s);

data Stm = Ass Int Val | Skip | Comp Stm Stm
  | If BVal Stm Stm | While BVal Stm;

sosstm (Ass x a) s =
  let { r = aval a s } in
    case (==) r 0 of { True -> Final (update s x 0)
                     ; False -> Final (update s x r) };
sosstm Skip s = Final s;
sosstm (Comp ss1 ss2) s =
  case sosstm ss1 s of {
    Inter ss10 s0 -> Inter (Comp ss10 ss2) s0;
    Final s0 -> Inter ss2 s0;
  };
sosstm (If b ss1 ss2) s =
  case bval b s of {
    True -> Inter ss1 s;
    False -> Inter ss2 s;
  };
sosstm (While b ss) s =
  Inter (If b (Comp ss (While b ss)) Skip) s;

data State s = Inter Stm s | Final s;

run (Inter ss s) = run (sosstm ss s);
run (Final s) = s;

ssos ss s = run (Inter ss s);

example = 
  let {
    divide = While (Le (V 1) (V 0))
               (Comp (Ass 0 (Sub (V 0) (V 1)))
                     (Ass 2 (Add (V 2) (N 1))));

    callDivide = Comp (Comp (Ass 0 (V 3))
                            (Ass 1 (V 4)))
                      divide;

    ndivs = Comp (Ass 4 (V 3))
             (While (Neg (Eq (V 4) (N 0))) (
               Comp (Comp callDivide
                          (If (Eq (V 0) (N 0)) (Ass 5 (Add (V 5) (N 1))) Skip))
                    (Ass 4 (Sub (V 4) (N 1)))
             ));

    sinit = Cons (Pair 0 0) (
             Cons (Pair 1 0) (
             Cons (Pair 2 0) (
             Cons (Pair 3 14000) (
             Cons (Pair 4 0) (
             Cons (Pair 5 0) Nil)))));

    } in value (ssos ndivs sinit) 5;

main = print example;

}
